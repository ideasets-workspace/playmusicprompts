# Standards ledger

- Governing product source: the current generated Music Studio contract defines one conductor endpoint, four planner-owned routes, 34 parameters, honest binding classes and measured refusal/capability behavior.
- Governing research result: `../2026-08-18-playmusicprompts-music-os-frontier.md`.
- Claim and contradiction controls: `../_ledgers/2026-08-18-playmusicprompts-claim-verification-ledger.md` and `../_ledgers/2026-08-18-playmusicprompts-contradiction-risk-ledger.md`.
- Architecture status: proposed vNext contract, not a claim that every described capability is deployed.
- Evidence notation: `[Axx]`, `[Pxx]`, `[Sxx]` resolve through the source register. `INFERENCE` marks product design derived from evidence.

# 1. Committed product boundary

PlayMusicPrompts is a **Living Music Engine**. Its primary durable object is a versioned `MusicProject`, not a prompt, generation job or audio file.

The system converts multimodal human intent into an editable `MusicIntentGraph`, executes typed `EditTransaction` objects, renders through model-independent adapters, evaluates each candidate, preserves human decisions and rights, and delivers static or adaptive music packages.

The existing `/generate-music-hybrid-model` endpoint remains the first production renderer/conductor adapter. vNext adds project, edit, evaluation, version, rights and runtime services around it rather than discarding the working backend.

# 2. Non-negotiable architecture laws

1. **Prompt is input, never source of truth.** The source of truth is the project graph.
2. **Every change is a transaction.** No hidden mutation.
3. **Every control declares its binding.** `typed`, `compiled`, `enforced`, `measured`, `prose`, `client_side`, `response_field`, `refused`, or `requested_unverified`.
4. **Every preserved property declares its verifier.** A decorative lock is forbidden.
5. **Every generated asset declares origin.** Native, conditioned, symbolic-rendered, separated, DSP-derived or human-uploaded.
6. **Every model route declares exact identity/version and reason.** “BT-Music” may be a product alias; the response exposes what actually ran.
7. **Every project operation is reversible.** Branch before destructive work; immutable media by default.
8. **Every evaluator separates measurement from judgment.** Hard facts, probabilistic features and subjective preferences are different layers.
9. **Every identity requires authority.** Voice/artist/brand/culture assets carry controller, consent, scope, expiry and revocation.
10. **Every export is portable.** No disappearance of the creator's project because a vendor/model/policy changes.
11. **Every AI disclosure is granular.** No false binary or invented human/AI percentage.
12. **Every “real-time” claim is measured end-to-end.** Latency, jitter, dropout and recovery are part of the contract.

# 3. Experience modes

| Mode | User promise | Primary surface | Default agency | Renderer behavior |
|---|---|---|---|---|
| `spark` | “Tell me what should exist.” | One multimodal intent field + three meaningful directions | Guided | Fast project plan, strategic previews, full render only when useful |
| `direct` | “Create with me.” | AI Producer + Living Score + contextual inspector + Audition Deck | Collaborative | Typed graph edits, branch/compare/commit |
| `deep` | “Give me complete production control.” | Existing advanced Studio as contextual Deep Inspector | User-directed | Full 34-control surface plus vNext graph/eval/rights fields |
| `perform` | “Play with me now.” | Live role, latency, gesture/MIDI/audio and state controls | Negotiated live | Persistent stream, causal accompaniment, adaptive runtime |

# 4. System topology

```text
Multimodal Intent Intake
        │
        ▼
Intent Compiler ───────► Ambiguity / Conflict / Rights Preflight
        │                              │
        │                         ask / refuse / sketch
        ▼                              │
Music Intent Graph ◄──── Project Memory / Taste Constitution
        │
        ▼
Edit Transaction Compiler
        │
        ▼
Constraint + Rights Solver
        │
        ├──► NoRender Preflight
        └──► Planner / Conductor
                   │
                   ├── current hybrid full-song route
                   ├── preview route
                   ├── local edit / inpainting route
                   ├── native multitrack route
                   ├── vocal score renderer
                   ├── DSP / mix / master stages
                   ├── private / local route
                   └── real-time route
                              │
                              ▼
                     Candidate Asset Set
                              │
                              ▼
                     PMP-Eval Council
                              │
               hard reject / rerank / explain / repair
                              │
                              ▼
                 Audition + Human Decision
                              │
                              ▼
                      Version Commit DAG
                              │
                ┌─────────────┴─────────────┐
                ▼                           ▼
       Delivery Package              Adaptive Runtime
```

# 5. Canonical object model

## 5.1 Object hierarchy

```text
MusicUniverse
  └── MusicProject
        ├── MusicIntentGraph
        │     ├── GlobalIntent
        │     ├── SectionGraph
        │     ├── MotifGraph
        │     ├── HarmonyMap
        │     ├── RhythmMap
        │     ├── LyricGraph
        │     ├── VocalScore
        │     ├── TrackGraph
        │     ├── MixGraph
        │     ├── NarrativeGraph
        │     ├── CultureGrammarBindings
        │     ├── RightsGraph
        │     └── ConstraintGraph
        ├── TasteConstitution
        ├── IdentityObjects
        ├── EditTransactions
        ├── CandidateSets
        ├── EvaluationReports
        ├── VersionDAG
        ├── HumanContributionPassport
        ├── DeliveryPackages
        └── RuntimeSessions
```

## 5.2 `MusicProject`

```json
{
  "schema": "pmp.music-project/v0.1",
  "project_id": "pmp_prj_01J...",
  "name": "Odyssey Trailer Theme",
  "owner": {"type": "user", "id": "usr_..."},
  "workspace_id": "wrk_...",
  "created_at": "2026-08-18T12:00:00Z",
  "updated_at": "2026-08-18T12:00:00Z",
  "current_branch": "main",
  "current_commit": "cmt_...",
  "experience_mode": "direct",
  "intent_graph_ref": "graph_...",
  "taste_constitution_ref": "taste_...",
  "rights_state": "preflight_passed",
  "release_state": "working",
  "default_agency_mode": "direct",
  "default_surprise_budget": 0.35,
  "renderer_policy": "planner_decides",
  "data_policy": {
    "training_use": "never_without_explicit_opt_in",
    "retention": "workspace_policy",
    "private_routes_required": false
  }
}
```

## 5.3 `MusicIntentGraph`

The graph is renderer-independent and versioned. A renderer receives a compiled projection; it never becomes the project authority.

```json
{
  "schema": "pmp.music-intent-graph/v0.1",
  "graph_id": "graph_...",
  "project_id": "pmp_prj_...",
  "clock": {
    "tempo_map": [{"at_bar": 1, "bpm": 128.0, "curve": "step"}],
    "meter_map": [{"at_bar": 1, "signature": "4/4"}],
    "tuning": {"system": "12tet", "reference_hz": 440.0},
    "duration_target_seconds": 135,
    "duration_tolerance_seconds": 2
  },
  "global_intent": {
    "purpose": "cinematic trailer theme",
    "audience": ["global theatrical audience"],
    "listener_effect": ["anticipation", "scale", "earned uplift"],
    "narrative": "solitude transforms into collective resolve",
    "use_context": ["film trailer", "social cutdowns"],
    "avoid": ["generic trailer braams", "sentimental piano cliché"],
    "agency_mode": "direct",
    "surprise_budget": 0.35
  },
  "sections": [
    {
      "section_id": "sec_chorus_01",
      "role": "chorus",
      "bars": {"start": 33, "end": 48},
      "narrative_function": "first full release",
      "energy_target": 0.82,
      "motif_refs": ["motif_hero"],
      "track_roles": ["strings", "brass", "hybrid_drums", "choir"],
      "locks": ["lock_vocal_identity", "lock_main_melody"],
      "candidate_policy": {"count": 8, "diversity": 0.55}
    }
  ],
  "motifs": [
    {
      "motif_id": "motif_hero",
      "source": "human_hummed",
      "representation": {"midi_ref": "asset_midi_..."},
      "identity_tolerance": {"pitch_class": 1.0, "rhythm": 0.92},
      "allowed_transforms": ["transpose", "augment", "orchestrate", "invert_once"],
      "forbidden_transforms": ["replace_core_interval_shape"]
    }
  ],
  "culture_bindings": [],
  "constraint_refs": ["lock_main_melody", "lock_vocal_identity"],
  "rights_refs": ["rights_user_hum", "rights_generated_assets"]
}
```

# 6. Musical identity model

## 6.1 Three identity layers

| Layer | Canonical content | Typical locks | Typical rights |
|---|---|---|---|
| `composition_identity` | form, motif, melody, harmony, lyrics, rhythmic grammar | motif shape, lyric text, chord function, section order | writer/composer/publisher interests |
| `performance_identity` | performer/voice, phrasing, timing, articulation, dynamics, improvisation | voice embedding, note timing, pronunciation, expressive contour | performer consent, voice/digital-replica license |
| `production_identity` | instrumentation, timbre, sound design, spatial field, mix/master relationships | instrument identity, stem balance, spectral profile, loudness | master/recording, sample and brand-sonic permissions |

## 6.2 `IdentityObject`

```json
{
  "schema": "pmp.identity-object/v0.1",
  "identity_id": "idn_...",
  "type": "licensed_voice",
  "display_name": "Authorized Artist Voice",
  "controller": {"entity_id": "ent_...", "verification": "verified"},
  "consent": {
    "status": "active",
    "evidence_ref": "doc_...",
    "granted_at": "2026-08-18T00:00:00Z",
    "expires_at": "2027-08-18T00:00:00Z",
    "revocable": true
  },
  "scope": {
    "territories": ["GLOBAL"],
    "media": ["music", "video", "game"],
    "uses": ["original_song", "authorized_cover"],
    "forbidden": ["political_endorsement", "adult_content"],
    "commercial": true
  },
  "compensation": {"model": "revenue_share", "terms_ref": "terms_..."},
  "model_assets": [{"adapter_ref": "voice_adapter_...", "version": "1.0"}],
  "revocation_policy": "blocks_new_renders_preserves_audit_history"
}
```

# 7. Taste Constitution

A user-visible, portable and revocable preference object. It contains what the creator rejects, not only what they repeatedly accept.

```json
{
  "schema": "pmp.taste-constitution/v0.1",
  "taste_id": "taste_...",
  "owner_id": "usr_...",
  "scope": "user",
  "positive_rules": [
    {
      "rule_id": "tp_01",
      "feature": "harmonic_tension",
      "preference": "borrowed_chords_before_major_release",
      "weight": 0.62,
      "confidence": 0.71,
      "evidence": ["decision_123", "decision_221"]
    }
  ],
  "negative_rules": [
    {
      "rule_id": "tn_01",
      "feature": "trailer_cliche",
      "preference": "avoid_generic_braam_every_8_bars",
      "weight": 0.91,
      "confidence": 0.88,
      "evidence": ["rejection_401", "rejection_509"],
      "expires_at": null
    }
  ],
  "cultural_context": ["turkish", "global_cinematic"],
  "project_exceptions": [],
  "privacy": {"storage": "account_encrypted", "training_use": "no"},
  "controls": {"editable": true, "exportable": true, "deletable": true}
}
```

# 8. Edit Transaction contract

## 8.1 Typed operation set

- `replace_region`
- `insert_section`
- `delete_section`
- `extend_section`
- `shorten_section`
- `reharmonize`
- `recompose_melody`
- `transform_motif`
- `reorchestrate`
- `regroove`
- `revoice`
- `rewrite_lyrics`
- `realign_lyrics`
- `reperform`
- `remix`
- `remaster`
- `local_repair`
- `derive_version`
- `adapt_runtime_state`

## 8.2 `EditTransaction`

```json
{
  "schema": "pmp.edit-transaction/v0.1",
  "transaction_id": "edt_...",
  "project_id": "pmp_prj_...",
  "parent_commit": "cmt_...",
  "request": {
    "natural_language": "Make the second chorus twice as powerful without changing the singer, lyrics, melody or anything outside 1:12–1:28.",
    "submitted_by": "usr_..."
  },
  "selection": {
    "time": {"start_seconds": 72.0, "end_seconds": 88.0},
    "sections": ["sec_chorus_02"],
    "tracks": ["brass", "strings", "drums"],
    "graph_nodes": ["sec_chorus_02", "motif_hero"]
  },
  "operations": [
    {
      "type": "reorchestrate",
      "target": "sec_chorus_02",
      "direction": "increase perceived power through register, density and contrast; avoid generic trailer clichés"
    }
  ],
  "hard_invariants": [
    "exact_audio_outside_transition_collar",
    "performance_identity:vocal_01",
    "lyrics:sec_chorus_02",
    "melody:motif_hero",
    "tempo_map"
  ],
  "soft_invariants": [
    {"feature": "mix_loudness", "tolerance": {"lufs": 0.8}},
    {"feature": "section_duration", "tolerance_seconds": 0.25}
  ],
  "transition_collar": {"before_seconds": 0.25, "after_seconds": 0.35},
  "variation_budget": {
    "composition": 0.05,
    "performance": 0.0,
    "production": 0.55,
    "surprise": 0.25
  },
  "candidate_policy": {
    "preview_count": 12,
    "finalist_count": 4,
    "diversity_floor": 0.35,
    "blind_pairwise": true
  },
  "commit_policy": "user_confirmed",
  "status": "compiled"
}
```

## 8.3 Preflight response

```json
{
  "understood": "Increase the perceived power of chorus 2 through production and orchestration only.",
  "will_change": ["brass voicing", "string register", "drum density", "pre-chorus contrast if explicitly approved"],
  "will_not_change": ["vocal identity", "lyrics", "main melody", "tempo", "audio outside collar"],
  "conflicts": [
    {
      "type": "causal_dependency",
      "message": "The largest contrast gain would require reducing the preceding two bars, which are currently outside the selection.",
      "choices": ["keep strict selection", "extend collar by 2 bars"]
    }
  ],
  "binding_report": {
    "exact_audio_outside_transition_collar": "enforced_and_measured",
    "performance_identity:vocal_01": "feature_lock_measured",
    "lyrics:sec_chorus_02": "phoneme_lock_measured",
    "perceived_power": "meaning_lock_requested_unverified"
  },
  "recommended_action": "ask_one_question"
}
```

# 9. Conservation Locks

## 9.1 Lock classes

| Class | Definition | Verification | UI state |
|---|---|---|---|
| `exact` | Sample/byte identity outside permitted change area | direct sample/hash comparison after alignment | green only at zero/declared tolerance |
| `feature` | Measurable musical/acoustic property within tolerance | dedicated estimator + confidence + threshold | green/yellow/red with evidence |
| `meaning` | Narrative, emotional, cultural or brand function | evaluator council and/or human expert | never shown as objectively proven unless a validated test exists |

## 9.2 Exact locality metric

For original waveform `x`, edited waveform `x'`, protected region `Ωᶜ` after sample alignment:

```text
L_exact = max_{t ∈ Ωᶜ} |x'(t) - x(t)|
```

- Bit-exact preservation: `L_exact = 0`.
- Tolerant preservation is permitted only when the lock explicitly declares a numeric threshold and reason.
- A transition collar is excluded from `Ωᶜ` only when shown to the user before rendering.

## 9.3 Feature preservation score

For feature extractor `φ_k`, distance `d_k` normalized to `[0,1]`:

```text
P_k = 1 - d_k(φ_k(x'), φ_k(x))
```

The lock passes only when:

```text
P_k ≥ τ_k  AND  estimator_confidence ≥ κ_k
```

Every `τ_k`, `κ_k`, estimator version and calibration dataset is stored in the evaluation report.

## 9.4 Example lock registry

| Lock key | Class | Estimator/test | Default pass contract |
|---|---|---|---|
| `audio_exact` | exact | aligned PCM delta/hash | `L_exact = 0` outside collar |
| `tempo_map` | feature | beat/downbeat tracker + plan comparison | section BPM error ≤ project tolerance |
| `meter` | feature | meter estimator + symbolic plan | exact planned meter where measurable |
| `key_harmony` | feature | chord/key recognizer | weighted chord-function similarity ≥ threshold |
| `main_melody` | feature | melody transcription / MIDI comparison | pitch/rhythm identity thresholds |
| `groove` | feature | onset/microtiming descriptor | distance ≤ calibrated threshold |
| `lyrics_text` | feature | vocal stem ASR/phoneme alignment | token/phoneme error below language threshold |
| `vocal_identity` | feature + rights | consented identity model/embedding | similarity band + anti-spoof + active license |
| `instrument_identity` | feature | source/instrument classifier | calibrated class/embedding threshold |
| `mix_balance` | feature | stem loudness/spectral relationships | vector distance ≤ target tolerance |
| `emotion_function` | meaning | multi-model + human preference | evidence/confidence, never hard truth by default |
| `culture_grammar` | meaning + rules | executable grammar + expert panel | all hard rules + expert pass for release tier |

# 10. Musical Causal Contract

High-level requests are compiled into alternative causal plans instead of one direct slider mutation.

```json
{
  "schema": "pmp.musical-causal-contract/v0.1",
  "effect": "chorus feels more powerful",
  "context": {"section": "sec_chorus_02", "listener_state_before": "contained anticipation"},
  "candidate_causes": [
    {
      "plan_id": "cause_contrast",
      "hypothesis": "reduce pre-chorus density to increase relative impact",
      "interventions": ["thin strings bars 31-32", "delay sub-bass entrance"],
      "collateral_risk": ["pre-chorus becomes too empty"],
      "proof": ["section contrast delta", "pairwise listener preference"]
    },
    {
      "plan_id": "cause_orchestration",
      "hypothesis": "increase register span and transient density without changing composition",
      "interventions": ["raise brass voicing", "add octave strings", "increase drum subdivisions"],
      "collateral_risk": ["mask vocal consonants"],
      "proof": ["spectral/register delta", "vocal intelligibility pass"]
    }
  ]
}
```

# 11. NoRender Preflight

## 11.1 Allowed decisions

- `render_full`
- `render_preview`
- `render_micro_audition`
- `ask_one_question`
- `show_plan_only`
- `resolve_conflict`
- `refuse_rights`
- `refuse_capability`
- `wait_for_asset`

## 11.2 Decision objective

The conductor estimates:

```text
EV(render) = E[creative_utility] - render_cost - review_cost - lock_failure_risk - rights_risk
EV(question) = expected_entropy_reduction - interaction_friction
```

It asks only when `EV(question) > EV(render)` by a versioned policy margin. These are operational estimates, not claims of objective artistic value.

## 11.3 High-value question example

Instead of asking “Can you clarify?”, ask:

> When you say “darker,” which consequence matters more: harmonic instability, lower/rougher timbre, or a more threatening performance? I can preserve the melody in all three.

# 12. Candidate search and Audition Intelligence

## 12.1 Candidate objective vector

For candidate `c`:

```text
F(c) = [
  I(c),  instruction/intent adherence,
  Q(c),  audio/musical quality,
  P(c),  preservation/lock success,
  V(c),  vocal/lyric success,
  C(c),  cultural fidelity,
  N(c),  novelty,
  D(c),  diversity contribution,
 -R(c),  rights/similarity/release risk,
 -K(c),  compute and human review cost,
 -T(c)   latency
]
```

Hard-gate candidates are removed before ranking. Remaining candidates form a Pareto set; the product never collapses all dimensions into a fake universal score.

## 12.2 Pairwise preference model

For latent utility `u(c)`:

```text
P(c_i ≻ c_j) = σ(u(c_i) - u(c_j))
```

The user can choose blind comparison. Every choice updates project preference first; user-level memory updates only when allowed by the Taste Constitution policy.

## 12.3 Information-efficient audition

The next comparison maximizes expected uncertainty reduction while avoiding repetitive examples:

```text
q* = argmax_q [H(U | history) - E(H(U | history, answer_q))] / interaction_cost(q)
```

## 12.4 Audition card fields

- exact changed bars/tracks/nodes;
- passed/failed locks;
- causal plan used;
- differences from current commit;
- originality/similarity warnings;
- route/model/version/cost/latency;
- confidence and evaluator disagreement;
- “why this candidate exists” statement;
- add-to-comp, branch, reject and explain controls.

# 13. PMP-Eval Council

## 13.1 Evaluation layers

| Layer | Examples | Decision force |
|---|---|---|
| deterministic | decode, duration, sample locality, checksum, file format | hard gate |
| symbolic/structural | bar count, section order, MIDI/score identity | hard/soft gate |
| acoustic feature | BPM, key, chords, melody, stem activity, loudness | calibrated gate |
| vocal/language | phoneme error, lyric alignment, singer identity, breath | calibrated gate + rights |
| perceptual quality | artifacts, musicality, arrangement, mix, memorability | diagnostic / preference |
| cultural | tuning, seyir, usul, articulation, language | rules + expert panel |
| originality/rights | similarity, attribution, identity permission, asset provenance | warning/block/review |
| human preference | project pairwise choice, expert review | ranking/commit authority |

## 13.2 Evaluator profile

```json
{
  "evaluator_id": "eval_lyric_tr_v1",
  "version": "1.0.0",
  "purpose": "Turkish sung-lyric phoneme preservation",
  "input_contract": ["vocal_stem", "target_lyrics", "language=tr"],
  "outputs": ["token_error", "phoneme_error", "timing_alignment", "confidence"],
  "calibration_dataset": "pmp_tr_singing_eval_v1",
  "thresholds": {"preview": 0.18, "release": 0.08},
  "known_limits": ["ornamented melisma", "extreme distortion"],
  "binding": "measured"
}
```

## 13.3 `FailureTrace`

```json
{
  "schema": "pmp.failure-trace/v0.1",
  "candidate_id": "cand_...",
  "failed_requirement": "lyrics_text:bars_25_28",
  "symptom": {"phoneme_error_rate": 0.21, "release_threshold": 0.08},
  "likely_causes": [
    {"cause": "four syllables compressed onto two short notes", "confidence": 0.82},
    {"cause": "cymbal masking at consonant onsets", "confidence": 0.67}
  ],
  "minimum_repair": {
    "operation": "realign_lyrics",
    "preserve": ["voice_identity", "words", "harmony", "section_duration"],
    "secondary_operation": "duck_cymbal_at_consonant_onsets"
  },
  "collateral_risk": ["melodic contour changes within tolerance"],
  "proof_after_repair": ["phoneme_error_rate", "melody_lock", "duration_lock"]
}
```

# 14. Version and contribution graph

## 14.1 Version DAG

Every render/edit creates a branch asset before commit.

```text
c0 initial plan
 ├─ c1 first render
 │   ├─ c2 chorus edit A
 │   │   └─ c5 final comp
 │   └─ c3 chorus edit B ─┘
 └─ c4 acoustic branch
```

Merge conflicts are musical objects, not text-line conflicts:

- same section changed in both branches;
- same motif transformed incompatibly;
- rights scope differs;
- identity version expired;
- lock/evaluator profile changed;
- renderer migration changed semantics.

## 14.2 Human Contribution Passport

```json
{
  "schema": "pmp.human-contribution-passport/v0.1",
  "project_id": "pmp_prj_...",
  "release_commit": "cmt_final",
  "events": [
    {
      "event_id": "evt_01",
      "actor": {"type": "human", "id": "usr_..."},
      "role": "composer",
      "action": "recorded_hummed_motif",
      "object": "motif_hero",
      "asset_ref": "audio_hum_..."
    },
    {
      "event_id": "evt_02",
      "actor": {"type": "model", "id": "intent_compiler_v1"},
      "role": "proposal",
      "action": "proposed_section_plan",
      "object": "section_graph",
      "accepted_by": "usr_..."
    },
    {
      "event_id": "evt_03",
      "actor": {"type": "human", "id": "usr_..."},
      "role": "editor",
      "action": "comped_candidates",
      "inputs": ["cand_A_bars_1_4", "cand_C_bars_5_8"],
      "output": "sec_chorus_02_final"
    }
  ],
  "summary": {
    "human_originated_objects": ["global_brief", "motif_hero", "custom_lyrics"],
    "human_decision_events": 27,
    "model_proposal_events": 41,
    "automatic_technical_events": 8
  },
  "legal_interpretation": "not_provided"
}
```

No AI/human percentage is emitted as authorship truth.

# 15. Rights and provenance graph

## 15.1 Independent states

```json
{
  "commercial_use_contract": "allowed_under_vendor_and_workspace_terms",
  "human_authorship_evidence": "passport_available",
  "copyright_warranty": false,
  "identity_permissions": "passed",
  "source_asset_permissions": "passed",
  "similarity_review": "warning_none_above_threshold",
  "training_data_attribution": "not_available_for_renderer",
  "c2pa": "signed_and_verified_after_render",
  "ddex_ai_credit": "written",
  "legal_review": "not_requested"
}
```

## 15.2 Provenance survival

Every transformation records whether prior credentials survived, were re-signed or became detached. A green C2PA mark requires cryptographic read-back after all render/master/transcode stages.

# 16. Culture Grammar contract

A Culture Grammar is not a genre chip. It is a governed executable package.

```json
{
  "schema": "pmp.culture-grammar/v0.1",
  "grammar_id": "culture_tr_makam_v1",
  "name": "Turkish Makam and Usul Grammar",
  "governance": {
    "expert_council": ["verified_expert_ids"],
    "community_review": "required_for_major_version",
    "compensation_policy_ref": "policy_..."
  },
  "theory": {
    "pitch_system": "microtonal_turkish_music",
    "makam": ["selected_versioned_definitions"],
    "seyir_rules": ["rule_refs"],
    "usul": ["aksak_and_other_patterns"],
    "modulation_rules": ["rule_refs"]
  },
  "performance": {
    "instrument_articulations": ["baglama", "ney", "kanun", "kemenche", "percussion"],
    "ornamentation": ["rule_refs"],
    "vocal_language": "tr"
  },
  "evaluators": ["eval_tuning_tr_v1", "eval_seyir_v1", "eval_usul_v1", "expert_panel_tr_v1"],
  "rights": {"training_assets": "documented", "expert_compensation": "active"},
  "known_limits": ["regional traditions require separate profiles"]
}
```

# 17. Renderer adapter contract

## 17.1 Adapter interface

```json
{
  "adapter_id": "adapter_lyria3pro_v1",
  "capabilities": {
    "full_song": true,
    "vocals": true,
    "max_duration_seconds": 184,
    "typed_seed": false,
    "local_edit": false,
    "native_stems": false,
    "real_time": false
  },
  "compile": {
    "input": "MusicIntentGraphProjection",
    "output": "VendorRequest + BindingReport"
  },
  "render": {
    "output": "AssetSet + RouteEvidence"
  },
  "verify": {
    "required_evaluators": ["decode", "duration", "lyrics_if_present", "provenance"]
  }
}
```

## 17.2 Current hybrid adapter

The current endpoint becomes `adapter_current_hybrid_v1` and retains:

- route planner ownership;
- actual model/worker/reason in response;
- 34-parameter source-generated capability surface;
- binding taxonomy;
- duration conform, mastering, stems and lyric verification stages;
- measured live HTTP/direct invocation and refusal path.

The vNext service compiles graph state into the existing request shape, then stores the current response as one candidate/render event.

# 18. API surface

## 18.1 Projects

```text
POST   /v1/music/projects
GET    /v1/music/projects/{project_id}
PATCH  /v1/music/projects/{project_id}
POST   /v1/music/projects/{project_id}/import
POST   /v1/music/projects/{project_id}/export
```

## 18.2 Intent and graph

```text
POST   /v1/music/projects/{project_id}/intent/compile
GET    /v1/music/projects/{project_id}/graph
POST   /v1/music/projects/{project_id}/graph/diff
POST   /v1/music/projects/{project_id}/graph/validate
```

## 18.3 Edits and candidates

```text
POST   /v1/music/projects/{project_id}/edits/preflight
POST   /v1/music/projects/{project_id}/edits
GET    /v1/music/projects/{project_id}/edits/{transaction_id}
POST   /v1/music/projects/{project_id}/candidates/search
POST   /v1/music/projects/{project_id}/candidates/compare
POST   /v1/music/projects/{project_id}/candidates/comp
```

## 18.4 Render and evaluation

```text
POST   /v1/music/projects/{project_id}/renders
GET    /v1/music/renders/{render_id}
POST   /v1/music/renders/{render_id}/evaluate
GET    /v1/music/renders/{render_id}/evaluation
POST   /v1/music/renders/{render_id}/repair
```

## 18.5 Versions

```text
GET    /v1/music/projects/{project_id}/versions
POST   /v1/music/projects/{project_id}/branches
POST   /v1/music/projects/{project_id}/commits
POST   /v1/music/projects/{project_id}/merge
POST   /v1/music/projects/{project_id}/revert
```

## 18.6 Identity, rights and contribution

```text
POST   /v1/music/identities
POST   /v1/music/identities/{identity_id}/verify
POST   /v1/music/identities/{identity_id}/revoke
POST   /v1/music/projects/{project_id}/rights/preflight
GET    /v1/music/projects/{project_id}/contribution-passport
GET    /v1/music/projects/{project_id}/provenance
```

## 18.7 Runtime

```text
POST   /v1/music/projects/{project_id}/runtime/packages
POST   /v1/music/runtime/sessions
WS     /v1/music/runtime/sessions/{session_id}/stream
POST   /v1/music/runtime/sessions/{session_id}/state
```

# 19. Event model

All services emit append-only events:

- `project.created`
- `intent.compiled`
- `ambiguity.detected`
- `rights.preflight_failed`
- `edit.compiled`
- `edit.conflict_detected`
- `render.planned`
- `render.started`
- `render.completed`
- `render.refused`
- `evaluation.completed`
- `lock.failed`
- `repair.proposed`
- `candidate.rejected`
- `candidate.selected`
- `candidate.comped`
- `branch.created`
- `commit.created`
- `merge.completed`
- `identity.revoked`
- `delivery.exported`
- `runtime.state_changed`

Each event includes actor, project, branch, parent, model/adapter version, source assets, timestamp, idempotency key and provenance receipt.

# 20. Open `.pmp` project package

```text
project.pmp/
  manifest.json
  graph/
    music-intent-graph.json
    taste-constitution.json
    identities.json
    rights-graph.json
  versions/
    commits.jsonl
    branches.json
    edit-transactions.jsonl
  assets/
    audio/
    stems/
    midi/
    scores/
    lyrics/
    references/
  evaluations/
    reports/
    failure-traces/
    calibration-manifest.json
  provenance/
    c2pa/
    ddex/
    contribution-passport.json
    receipts.jsonl
  adapters/
    render-history.jsonl
    model-capabilities.json
  delivery/
    packages.json
  checksums.sha256
```

## 20.1 Format guarantees

- UTF-8 JSON/JSONL plus ordinary media assets.
- Semantic versioning and migration records.
- Stable IDs; no vendor-only opaque dependency for core meaning.
- Integrity manifest and content hashes.
- Unknown extension fields preserved during round-trip.
- Rights-sensitive assets may be references with authorized retrieval, never silently omitted.
- A public validator verifies schema, hashes, graph references, version ancestry and required provenance fields.

# 21. UI information architecture

## 21.1 Global navigation

- Home
- Create
- Projects
- Music Worlds
- Identity & Voices
- Culture Grammars
- Rights Exchange
- Library
- Collaborate
- Releases
- Developer
- Settings

## 21.2 Direct workspace

### Top bar

- project / branch / commit;
- mode: Spark / Direct / Deep / Perform;
- Agency Mode;
- Intent Integrity;
- locks passing/failing;
- rights/provenance state;
- audition/render budget;
- Generate / Preview / Ask / Commit.

### Left: AI Producer

- conversation with typed action receipts;
- current project memory;
- unresolved ambiguity/conflict;
- causal plans;
- suggested minimum repairs;
- no-render explanation;
- collaborator decisions.

### Center: Living Score

Layers:

- sections and bars;
- waveform and native tracks;
- motif recurrence/transformation;
- harmony/key/modulation;
- energy and causal contrast;
- lyrics/phonemes/notes/breath;
- narrative/scene/game events;
- locks and contribution ownership;
- evaluator failures/confidence;
- culture grammar overlays.

### Right: Contextual Inspector

Shows only controls relevant to the selected object. Every field includes:

- current value;
- binding class;
- source of value;
- hard/soft/meaning status;
- affected graph nodes;
- evaluator;
- last changed by;
- version history;
- “why this matters.”

### Bottom: Audition Deck

- candidate clusters;
- blind A/B;
- Pareto map;
- difference explanation;
- bar-level comp lane;
- rejection reason chips;
- branch/commit/revert.

# 22. Mapping the current 34 parameters into vNext

| Current parameter | Current role/binding | vNext canonical location | vNext change |
|---|---|---|---|
| `client_side_echo` | collaboration/client-side | `CollaborationThread` | Move outside render request; event-linked comments/annotations. |
| `project` | metadata/client-side | `MusicProject` | Stable project/branch/commit IDs and release state. |
| `creative_goal` | prose | `GlobalIntent.listener_effect/purpose` | Compile to explicit causal/perceptual goals. |
| `prompt` | typed | `IntentSubmission.raw` | Preserve raw request, but graph becomes authority. |
| `prompt_enhance` | not compiled | `intent/compile` graph-diff proposal | Replace rewrite toggle with inspectable diff and ambiguity report. |
| `negative_prompt` | typed/prose by route | `GlobalIntent.avoid` + `TasteConstitution.negative_rules` | Separate project avoid list from learned long-term negatives. |
| `genres` | prose | `StyleDescriptor` / optional Culture Grammar | Never treat genre as cultural fidelity. |
| `moods` | prose | `GlobalIntent.listener_effect` | Map to time-varying emotional/narrative targets. |
| `prompt_blocks` | prose | reusable `IntentModule` | Typed role, scope, weight, dependencies and evaluator. |
| `tempo_bpm` | prose + measured | `Clock.tempo_map` | Support changes, ramps and per-section tolerances. |
| `key` | prose | `HarmonyMap` / tuning | Add modulation, chord function and microtonal systems. |
| `time_signature` | prose | `Clock.meter_map` | Add additive grouping/usul, not only label. |
| `duration` | enforced | `Clock.duration_contract` | Section-aware conform; no musically blind trim. |
| `structure` | compiled | `SectionGraph` | Persistent nodes/edges, narrative roles, transitions and reuse. |
| `arrangement_ai` | not compiled | `ArrangementAdvisor` | Typed applyable diffs with causal explanation. |
| `energy_curve` | compiled stepwise | `NarrativeGraph.energy/contrast` | Link perceived energy to causal variables and evaluate realization. |
| `instruments` | prose | `TrackGraph.roles/identity` | Distinguish role, performance, sound and native/separated origin. |
| `sonic_tags` | prose | `ProductionIdentity` descriptors | Versioned ontology and measurable features where possible. |
| `mood_orbit` | compiled | `NarrativeGraph.emotion_trajectory` | Time-varying vector with uncertainty, not static decorative radar. |
| `vocal` | prose/typed instrumental | `VocalScore` + `IdentityObject` | Explicit singer authority, range, articulation and language contract. |
| `lyrics` | typed | `LyricGraph` + `VocalScore` | Syllable/phoneme/note/breath alignment and per-section locks. |
| `references` | compiled/refused | `ReferenceObject` + `RightsGraph` | Authorized analysis descriptors; similarity and identity safeguards. |
| `output_package` | our stage | `DeliveryPackage` | Project/versions/runtime packages, not only track/variations/stems. |
| `route` | typed | `RendererPolicy` | Planner remains authority; pin adapter/model/version per commit. |
| `quality` | our stage | `RenderTier` + evaluator profile | Define tests, candidate count and stages, not a vendor quality fiction. |
| `controls` | compiled graded prose | `MusicalCausalContract` | Keep advanced values, add explicit causal plans and realization proof. |
| `mastering` | enforced | `MixGraph.delivery_target` | Versioned, stem-aware, context-specific measured target. |
| `export` | enforced | `DeliveryPackage.formats` | Open project, DAW, score, runtime and provenance exports. |
| `stems` | our stage | `TrackGraph` / asset origin | Return native/separated/rendered origin and sync/bleed evidence. |
| `rights` | response-only | `RightsGraph` | Separate contract, authorship evidence, identity permission and warranty. |
| `compliance` | response-only | `ProvenanceGraph` | Read-back after each transform; DDEX/C2PA contribution granularity. |
| `seed` | typed | `RenderEvent.provenance` | Label deterministic only if rerender test passes per route/version. |
| `webhook_url` | our stage | job/event subscription | Signed event delivery, idempotency and retry policy. |
| `analysis_outputs` | response-only | `EvaluationReport` | Multi-evaluator values with estimator, confidence, threshold and status. |

# 23. New vNext capability matrix

| Capability | Now: existing backend/UI | Phase A: 0–90 days | Phase B: 3–9 months | Phase C: 9–18 months |
|---|---|---|---|---|
| Persistent project graph | absent | graph v0 over current requests | mature motif/track/vocal graph | universe/album/runtime graph |
| Typed edits | full-song request only | assembly/section transactions | local inpainting + comp/merge | live/adaptive transactions |
| Exact locks | no universal guarantee | outside-region assembly tests | model-integrated local preservation | cross-route certified locks |
| Feature locks | partial measurement | BPM/key/duration/lyrics/locality | melody/groove/voice/stem/mix | culture/brand/runtime profiles |
| Meaning locks | descriptive | visible unverified/evaluator evidence | expert panels and project models | culture/world-specific governance |
| Candidate intelligence | variations | 8–12 preview clustering/A-B | active learning/Pareto search | long-horizon world search |
| Version graph | versions list | branch/commit/revert | merge/comp/migration | distributed collaboration/runtime |
| Native tracks | separated/generated mix | origin labels | native/conditioned adapter | arbitrary adaptive track graph |
| VocalScore | lyrics/vocal fields | lyric/phoneme graph | score-native renderer/identity locks | multilingual/culture-specific performance |
| Arrangement advisor | toggle not compiled | typed diffs | causal debugger/repair | autonomous-but-governed producer roles |
| Contribution passport | absent | event graph v0 | C2PA/DDEX integration | marketplace/release ecosystem |
| Open `.pmp` | absent | internal portable archive v0 | public schema/validator/SDK | partner ecosystem/standardization |
| Culture Grammar | tags/aksak seeds | Turkish ontology/eval design | Turkish grammar v1/expert council | global governed grammar marketplace |
| Rights Exchange | absent | IdentityObject/verification | limited licensed voices/instruments | catalog/remix/artist marketplace |
| Adaptive runtime | absent | data model only | video/game package prototype | live/co-performance production |

# 24. Phase A implementation sequence on the current backend

## Sprint 1 — Project substrate

1. Create project/branch/commit persistence.
2. Wrap every current request/response as immutable render events.
3. Compile current 34 fields into `MusicIntentGraph v0`.
4. Preserve raw prompt and exact binding report.
5. Add `.pmp` internal export with checksums.

## Sprint 2 — Direct workspace

1. Spark/Direct/Deep mode shell.
2. Living Score section graph over current structure/energy data.
3. contextual inspector reading the existing capabilities endpoint.
4. What I understood / changes / locks preflight.
5. typed ArrangementAdvisor diffs replacing the inert toggle.

## Sprint 3 — Transactions and versions

1. `EditTransaction v0` for assembly-level section replacement/extension.
2. branch/commit/revert.
3. exact locality proof for unaffected assembled regions.
4. duration/BPM/key/lyrics feature-lock reports.
5. candidate provenance and cost/latency receipts.

## Sprint 4 — Audition Intelligence

1. preview candidate generation.
2. embeddings/features and near-duplicate clustering.
3. hard-failure removal.
4. blind A/B and rejection reasons.
5. bar/section-level comp where current assets permit.
6. project-level pairwise preference memory.

## Sprint 5 — Contribution and release evidence

1. Human Contribution Passport v0.
2. rights/reference preflight.
3. stem-origin labels.
4. C2PA/DDEX read-back state in delivery package.
5. release-readiness screen with no copyright warranty.

# 25. Acceptance tests

## 25.1 Project and honesty

- The UI renders the same 34 current parameters from the capabilities source; no manually divergent list.
- Every current and vNext control has a binding class.
- An unsupported operation is refused with reason before paid rendering.
- Route/model/worker/version/reason are stored per candidate.

## 25.2 Edit locality

- Edit bars 33–48 with a 0.35-second collar.
- Verify zero sample delta outside the protected assembled region for assembly-based route.
- If a generative local-edit route cannot pass, label the lock failed; never auto-commit.
- Repeat five edits and confirm no cumulative drift outside authorized collars.

## 25.3 Feature locks

- Tempo, duration, key/harmony, melody, lyrics and vocal identity each have a named evaluator/version.
- Thresholds are calibrated and environment-specific.
- Low-confidence measurements show `not_proven`, not pass.

## 25.4 Audition

- Generate at least eight candidates with a declared diversity floor.
- Cluster near-duplicates and explain differences.
- Measure time to final commit against a sequential-listening baseline.
- Preserve rejected/reverted decisions as preference evidence only under user policy.

## 25.5 Contribution and rights

- Every human/model/automatic event has actor, action, object and branch.
- Revoked IdentityObject blocks new renders.
- Unauthorized named identity/reference is refused.
- C2PA is read back after final transcode/master; missing credentials are visible.
- Delivery never says “copyright guaranteed.”

## 25.6 Portability

- Export `.pmp`, delete server-side project copy in a test workspace, re-import and reconstruct graph/version/assets.
- Unknown extension fields survive round-trip.
- Model adapters can be unavailable without corrupting project meaning.

# 26. Key service-level indicators

| SLI | Definition | Product reason |
|---|---|---|
| `idea_to_owned_release_rate` | completed, approved, editable, provenance-complete exports / started projects | North star |
| `first_delight_seconds` | intent submission to first user-kept musical moment | Preserve magic |
| `local_edit_success_rate` | edits passing all declared hard locks / attempted local edits | Category promise |
| `hard_lock_violation_rate` | committed candidates later found violating a hard lock | Must approach zero |
| `audition_to_commit_seconds` | first candidate ready to final commit | Selection efficiency |
| `candidate_waste_rate` | paid full renders never auditioned or automatically rejected late | Cost/UX discipline |
| `meaningful_human_decisions` | accepted/rejected/locked/performed/comped events per completed project | Agency evidence, not vanity |
| `project_return_rate` | projects reopened after 7/30 days | Persistent value |
| `portable_export_success` | valid re-importable `.pmp` exports / export attempts | Trust |
| `provenance_completeness` | required provenance fields present and verified | Release readiness |
| `identity_incident_rate` | unauthorized/misattributed identity events | Safety/business survival |
| `culture_expert_pass_rate` | release-tier outputs passing governed expert evaluation | Cultural depth |

# 27. Data moat without exploitation

The defensible dataset is not a scrape of more songs. It is the authorized, structured revision trail:

- initial intent;
- ambiguity resolution;
- causal plan chosen;
- locks set;
- candidates heard;
- accepted/rejected/reverted decisions;
- comp operations;
- human performance inputs;
- failure traces and repairs;
- final release context;
- user-owned preference rules.

Training use is opt-in, purpose-bound and revocable. Aggregate learning must preserve cultural and creator diversity rather than optimize toward one average taste.

# 28. Security, privacy and abuse controls

- encrypted asset/object storage and workspace isolation;
- signed upload URLs and media-type validation;
- malware/package scanning for project imports/plugins;
- identity verification and anti-spoof checks;
- consent evidence and revocation propagation;
- reference similarity and named-identity refusal;
- rate and bulk-release abuse controls;
- provenance-key protection and rotation;
- least-privilege renderer adapters;
- private/on-device route for sensitive unreleased work;
- no training use by default;
- audit log with user-visible access/export/delete controls;
- adversarial tests for watermark stripping, metadata loss, collusion and profile impersonation.

# 29. What is deliberately not claimed

- No universal hit predictor.
- No guarantee that every meaning lock is machine-verifiable.
- No claim that separated stems are native.
- No claim that a seed guarantees identical rerender.
- No claim that C2PA, DDEX, watermark or attribution proves ownership/non-infringement.
- No claim that one model route is permanently best.
- No claim that Turkish or any culture can be captured by a static tag list.
- No claim that the entire architecture is deployed today.

# 30. One committed build decision

Build **Music Intent Graph v0 + EditTransaction v0 + version DAG + Audition Deck** directly over the existing hybrid endpoint before investing in a larger legacy-DAW surface.

That sequence proves the category promise with the backend already completed:

> The system remembers what the human meant, changes only what was authorized, proves what it preserved, and turns every generation into a continuing musical project.
