# Standards ledger

- Contradictions are preserved rather than averaged away.
- “Resolution” means the product design can accommodate both truths; it does not mean the underlying scientific, legal or market disagreement has disappeared.
- Source IDs resolve through `../_sources/2026-08-18-playmusicprompts-source-register.md`.

# Contradiction and risk ledger

| ID | Tension / contradiction | Evidence for side A | Evidence for side B | Resolution for PlayMusicPrompts | Residual status |
|---|---|---|---|---|---|
| X01 | **More automation reduces effort** vs **more automation can reduce agency and ownership** | A17 reports lower task load; one-prompt products demonstrate demand for speed [P01, P08, P12] | A17, A05, A20 show agency/ownership risks, stronger among experts | Separate Spark simplicity from Direct/Deep control; expose Agency Mode and reversible diffs | OPEN: optimal defaults require product experiments by user type. |
| X02 | **One-prompt magic** vs **professional precision** | Consumer generators optimize immediate output [P01, P08, P12] | Producers request exact BPM/key/loop/edit/DAW integration [A06, A18] | Same project, progressive disclosure: Spark → Direct → Deep, not separate crippled products | RESOLVED BY ARCHITECTURE; usability still untested. |
| X03 | **Exact preservation** vs **seamless musical transitions** | MusicWeaver exact outside-mask preservation [A01] | Good inpainting may need a transition collar; generic products do not promise sample identity [P20, A13] | Exact lock outside an explicit collar; collar is visible, minimal and user-adjustable | OPEN: collar size/quality is route dependent. |
| X04 | **Native all-at-once multistem generation** vs **sequential stem blending** | Stemphonic/SyncTrack favor shared synchronized generation [A22, A28] | A34 argues for sequential arbitrary-stem blending analogous to human mixing | Support both adapters; choose by dependency graph, latency and edit goal; always label origin | OPEN: comparative production benchmark required. |
| X05 | **Source separation is practical now** vs **separation is not true independent creation** | Ableton, RipX, current tools and current backend make separated stems available [P31, P33] | Native-track research treats synchronization/editability as a separate model problem [A21, A22, A28] | Keep separation as utility path; never market it as native; build native route in Phase B | RESOLVED SEMANTICALLY; quality gap remains route-specific. |
| X06 | **One universal reward model is efficient** vs **music preference is plural/cultural/project-specific** | CMI/MuQ/SongBench show specialist reward models can improve selection [A25, A36, A44] | MusicRL, cross-cultural and homogenization evidence show incomplete/flattening preferences [A11, A14, A31, A37] | Hard gates + profile-specific multi-objective scores + diverse Pareto set; no global “best” | OPEN: preference calibration and bias audits. |
| X07 | **Personalization increases relevance** vs **personalization can become a creative cage** | Private tuning and preference learning [P10, A37] | Homogenization, cultural bias and authorial agency risks [A11, A14, A20, A31] | User-owned Taste Constitution with negative preferences, confidence, exceptions, delete/export | OPEN: evidence needed on long-term novelty and user autonomy. |
| X08 | **Cultural models increase fidelity** vs **culture packs can stereotype or extract communities** | A31, A42, A43 show domain-specific need | A14/A45 and justice framing warn control/representation is social, not only technical | Expert governance, provenance, revenue share, living grammar versions, refusal of costume-level imitation | OPEN: governance and compensation model. |
| X09 | **Open weights/local models maximize control/privacy** vs **closed models may lead quality/support** | ACE-Step/Stable Audio open routes [A03, P20] | Google/Eleven/Suno offer managed frontier surfaces [P01, P08, P12] | Model-independent conductor; local/private/managed routes measured through same eval contract | RESOLVED ARCHITECTURALLY; quality/cost changes over time. |
| X10 | **Chat makes creation natural** vs **chat can hide non-deterministic or non-operative behavior** | Suno/ProducerAI/DAW assistants show demand [P01, P14, P34] | Current backend already exposes accepted-but-not-compiled risks; HCI studies demand local control [A05, A06] | Chat may only emit typed graph diffs, tool calls or explicit questions; no unbound prose magic | RESOLVED AS PRODUCT LAW. |
| X11 | **Immediate generation produces delight** vs **rendering uncertainty creates waste** | Consumer expectations reward low time-to-first-output [P01, P08] | Selection burden and mismatch evidence [A06, A07, A19] | NoRender Preflight only when expected information value exceeds friction; otherwise generate | OPEN: threshold requires controlled experiments. |
| X12 | **Provenance increases trust** vs **provenance can over-disclose, be attacked or be mistaken for truth** | C2PA/DDEX and platform credits [S01-S04, S08] | C2PA security/privacy caveats; watermark attacks/attribution limits [S03, A29, A30] | Progressive disclosure, minimum necessary metadata, cryptographic validation, separate legal status | RESOLVED IN UX; attacks and legal interpretation remain open. |
| X13 | **Watermark every output** vs **post-processing/adversarial transformation can weaken detection** | MusicMark reports robustness across attacks [A29] | No watermark is universal legal proof; transformations and cover attacks remain threats [A29, S01] | Layer watermark + C2PA + project provenance + server receipt; report survival tests | OPEN: red-team suite required per route/export. |
| X14 | **Artist identity enables personalization and fandom** vs **identity synthesis risks impersonation** | Licensed voices and artist-first remix agreements [P24, P38] | Spotify/USCO require authorization/protect replicas [S05, S08, P40] | IdentityObject requires verified controller, scope, expiry, territory, uses, compensation and revocation | RESOLVED POLICY-WISE; jurisdiction and enforcement remain open. |
| X15 | **AI disclosure supports trust** vs **disclosure may reduce appreciation/willingness to pay** | Spotify/C2PA/DDEX push granular transparency [S01, S04, S08, P40] | A50 reports negative valuation effects from AI disclosure | Do not hide AI use; explain meaningful human decisions and quality rather than binary stigma | OPEN: consumer framing effects and platform norms evolve. |
| X16 | **Open export builds trust** vs **platform lock-in can improve retention/revenue** | P07/P39 reveal export as a product lever | Producer workflows and standards require portability [A06, S10-S12] | Compete on understanding, continuity and ecosystem—not captivity; monetize finished value/services | COMMITTED TRADE-OFF: trust over artificial lock-in. |
| X17 | **Generation volume drives engagement** vs **mass output creates spam, discovery and royalty-pool harm** | Low marginal generation cost and creator experimentation | Spotify spam/AI persona policies [S08, P40] | North star is Idea-to-Owned-Release; cap/review bulk release; provenance and quality gates | RESOLVED AS PRODUCT/GROWTH LAW. |
| X18 | **Seed implies reproducibility** vs **stochastic vendor routes may not rerender identically** | Current API exposes seed/provenance fields | Current measured contract reports same request can differ materially; vendor semantics vary | Label seed as provenance unless deterministic replay is experimentally proven per route/version | RESOLVED HONESTLY. |
| X19 | **A finished song is the output** vs **music increasingly behaves as a versioned/adaptive runtime** | Existing distribution still centers masters/stems | Real-time, video, game and remix evidence [P35, A33, A35, P38] | Deliver master packages now while making MusicWorld/runtime a first-class future object | RESOLVED BY PHASING. |
| X20 | **Copyright/commercial-use badge simplifies buying** vs **copyrightability and infringement remain fact/jurisdiction specific** | Vendors offer commercial-use terms [P03, P08, P23] | USCO/UK/C2PA evidence separates contract, authorship, provenance and infringement [S01, S05, S13] | UI has separate `commercial_use_contract`, `authorship_evidence`, `similarity_review`, `legal_review` | RESOLVED SEMANTICALLY; counsel remains required. |
| X21 | **Human contribution can be quantified** vs **authorship is qualitative, role- and fact-specific** | Platforms may seek simple labels/scores | HAIM, A20, USCO show granular/fact-specific contribution [A10, A20, S05] | Record an event graph, never an AI/human percentage as legal truth | RESOLVED AS DATA MODEL. |
| X22 | **Music model should imitate requested references closely** vs **similarity and style/identity imitation create rights and originality risk** | Users naturally request references; products accept audio/style inputs [P05, P08] | Platform/legal policy and attribution research raise identity/similarity risk [S05, S08, A30] | Analyze authorized audio into descriptors; refuse named unauthorized identity; run similarity report | OPEN: thresholds and legal review vary. |
| X23 | **Real-time generation needs minimal latency** vs **musical anticipation/coherence needs look-ahead** | A35/A49 demonstrate causal/live systems | A35 shows latency–look-ahead–quality trade-off; A15 adds communication/ecosystem dimensions | Publish latency modes and musical role contracts; never claim “real-time” without measured end-to-end figures | OPEN: device/network/model-specific. |
| X24 | **Model upgrades improve quality** vs **upgrades can silently alter identity and reproducibility** | Rapid vendor/model progress [P12, P16, P20] | Project continuity requires stable semantics and known route/version [P07, current backend] | Pin adapter/model/version; store plan/assets; migration renders are branches, never silent replacements | RESOLVED BY VERSION CONTRACT. |

# Highest-risk unknowns before production commitment

1. **Exact edit locality on the deployed hybrid routes.** MusicWeaver proves a method, not current-route integration.
2. **Native multistem quality advantage.** Must be tested against separated stems on real producer tasks.
3. **Vocal identity and lyric/phoneme preservation.** Requires language-specific ground truth and consent-safe identity tests.
4. **Meaning-lock evaluation.** Cultural/emotional/narrative fidelity cannot be reduced to a green badge without expert validation.
5. **Long-term personalization.** Must measure novelty, diversity and user agency, not only short-term acceptance.
6. **Open project ecosystem adoption.** The `.pmp` protocol must create value before partner/network effects exist.
7. **Rights Exchange supply.** Opt-in identities/catalogs require verification, enforcement and economically attractive compensation.
8. **Platform policy volatility.** Distribution, disclosure and recommendation rules can change rapidly.

# Product laws derived from unresolved contradictions

- No silent change.
- No accepted-but-ignored control.
- No “native stem” label for separated audio.
- No AI/human percentage presented as authorship truth.
- No provenance badge presented as legal clearance.
- No named-artist/voice identity without verified permission.
- No culture label without an executable grammar and expert test.
- No model upgrade without a versioned migration branch.
- No bulk-release growth loop that rewards spam.
- No “real-time” claim without measured end-to-end latency and stability.
