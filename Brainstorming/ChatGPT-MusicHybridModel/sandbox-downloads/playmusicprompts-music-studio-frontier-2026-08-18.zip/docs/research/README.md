# PlayMusicPrompts Music Studio Frontier Research Index

**Research date:** 2026-08-18  
**Project:** `playmusicprompts.com` / BeforeTomorrow Music Studio  
**Decision served:** define the product, interaction, model-control, provenance, runtime, growth and build architecture that can move the current hybrid prompt-to-music backend beyond a generator or legacy DAW into a category-defining Living Music Engine.

## Standards and completion state

- Governing owner covenant: current-first, primary-first, discovery-first, source-to-claim traceability, contradiction preservation, six mandatory frontier axes, and deterministic completion evidence.
- Planned artifact graph: **19 artifacts**.
- Research records: **105 source records**, **82 independent provenance families**, **52 academic/research records**, **12 academic `[FULL]` records**, and **59 primary `[FULL]` records**.
- Claim ledger: **22** load-bearing claims supported by three or more independent evidence families or explicitly marked supported inference, **2** visible single-source/local claims, and **3** visible unverified/not-found-in-scope claims.
- Status language: the artifact graph and numerical floors are complete for the enumerated research universe. This is not a claim of mathematical or open-web infinity. Dynamic vendor pricing, private model internals, unavailable training corpora, unpublished usage telemetry, and implementation feasibility that requires prototype measurement remain dated or explicitly unresolved.

## Committed product decision

PlayMusicPrompts should not be positioned as a prompt marketplace, a model selector, an AI DAW clone, or a faster song generator. It should become a **Living Music Engine / Music Creation Operating System** whose persistent project object is a **Music Intent Graph / Living Score** rather than an audio file or transient prompt.

The first category proof should be built on the existing conductor and should demonstrate all of the following in one falsifiable workflow:

1. Interpret a natural-language revision as a typed `EditTransaction`.
2. Declare exactly what may change and what must remain invariant.
3. Generate several local alternatives without silently replacing the rest of the work.
4. Compare, branch, comp, commit and roll back non-destructively.
5. Verify lock preservation and expose any failure through a causal `FailureTrace`.
6. Preserve contribution, rights, identity, model-route and provenance records.
7. Export a portable project package, not only a rendered waveform.

## Artifact index

### Decision, scope and synthesis

1. [Scope plan](./2026-08-18-playmusicprompts-music-studio-scope-plan.md) — exact decision, project state, falsifiers, universes, hard-law mapping and the planned 19-artifact graph.
2. [Main frontier report](./2026-08-18-playmusicprompts-music-os-frontier.md) — outcome-first synthesis, 25 hidden truths, impossible demo, system/experience architecture, build sequence and committed recommendation.
3. [vNext capability matrix and schema](./architecture/2026-08-18-playmusicprompts-vnext-capability-matrix-and-schema.md) — Music Intent Graph, identity/taste objects, edit transactions, locks, candidate search, evaluation, version DAG, provenance, adapters, API/events, portable `.pmp` package and acceptance tests.

### Six mandatory frontier axes

4. [Competitor pricing and access](./competitors/2026-08-18-ai-music-platform-pricing-and-access.md) — dated plan economics, access restrictions, export policy and cost-design implications.
5. [Competitor functions and services](./competitors/2026-08-18-ai-music-platform-functions-and-services.md) — parity map, differentiated gaps and capabilities that are no longer sufficient for category leadership.
6. [Competitor business models](./competitors/2026-08-18-ai-music-platform-business-model.md) — incentives, licensing, creator/platform alignment and the recommended value architecture.
7. [Competitor UI and menus](./competitors/2026-08-18-ai-music-platform-ui-and-menus.md) — current interface patterns, failure modes and the Spark/Direct/Deep/Perform interaction architecture.
8. [Scientific and technical frontier](./sota/2026-08-18-playmusicprompts-music-generation-sota.md) — full-song planning, local editing, multitrack generation, vocal control, preference alignment, evaluation, real-time systems and unresolved problems.
9. [Model and workflow APIs](./apis/2026-08-18-ai-music-model-and-workflow-apis.md) — vendor surfaces, native versus compiled controls, portability standards, adapter boundaries and API architecture.
10. [Creator and customer expectations](./customer-expectations/2026-08-18-ai-music-creator-expectations.md) — novice, musician, producer, media, brand, collaboration, accessibility, trust and switching needs.
11. [Future needs](./future-needs/2026-08-18-ai-music-future-needs.md) — rights, identity, provenance, cultural depth, live/adaptive music, user-owned personalization and living-update requirements.
12. [Growth and organic loops](./growth/2026-08-18-playmusicprompts-growth-and-organic-loops.md) — creation, collaboration, release, remix, rights-marketplace, template/grammar, developer and ecosystem loops without generation-spam incentives.

### Evidence and audit ledgers

13. [Source register](./_sources/2026-08-18-playmusicprompts-source-register.md) — source identity, dates/versions, read status, provenance family, primary locator, run evidence and bounded application.
14. [Query and action ledger](./_ledgers/2026-08-18-playmusicprompts-query-action-ledger.md) — exact discovery queries, primary opens, local inspection, screening fate, saturation and access gaps.
15. [Claim verification ledger](./_ledgers/2026-08-18-playmusicprompts-claim-verification-ledger.md) — claim type, independent evidence families, entailment, contradiction state, freshness and decision impact.
16. [Contradiction and risk ledger](./_ledgers/2026-08-18-playmusicprompts-contradiction-risk-ledger.md) — unresolved tensions, failure modes, product controls and falsification tests.
17. [Completion manifest](./_runs/2026-08-18-playmusicprompts-music-studio-frontier.json) — machine-readable hashes, read-back state, counts, frontier-axis state, validation results and known gaps.
18. [Research index](./README.md) — this navigation and status file.

### Portable bundle

19. `playmusicprompts-music-studio-frontier-2026-08-18.zip` at the project root — portable archive of the research documents and ledgers. The bundle intentionally excludes itself. Its exact SHA-256 and content list are recorded in the completion manifest.

## Applied build order

**First:** persistent project state, `MusicIntentGraph v0`, `EditTransaction v0`, hard/soft conservation locks, version DAG and an Audition Deck over the existing endpoint.  
**Then:** native multitrack routes, vocal composition/performance contracts, causal evaluation and failure traces, contribution/rights passport, portable `.pmp` packages and user-owned Taste Constitutions.  
**Later:** scene/game/live runtime, culture-governed grammar packs, licensed identity/remix marketplace, album/universe continuity and a self-evolving MusicWorld.

## Known gaps and surveillance triggers

- Reopen vendor pricing, plans, output rights, download rules, API limits and deprecations immediately before purchase, release or commercial commitment.
- Public sources do not expose complete training corpora, private safety systems, undisclosed product telemetry or proprietary model internals.
- Some 2026 academic works were available only as partial primary text or metadata and are marked `[PARTIAL]`; they do not independently carry the committed recommendation.
- No independent subagent/delegation runtime was available in this execution environment, so the research was completed inline and the absence is preserved rather than disguised as parallel verification.
- Region-exact preservation, native track identity, Turkish phoneme quality, live latency, portable-project round-trip fidelity and evaluator calibration remain engineering hypotheses until measured against the acceptance tests in the architecture artifact.
