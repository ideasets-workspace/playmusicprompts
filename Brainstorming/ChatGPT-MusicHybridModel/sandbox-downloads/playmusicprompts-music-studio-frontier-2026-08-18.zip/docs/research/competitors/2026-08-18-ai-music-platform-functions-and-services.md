# Standards ledger

- Scope: documented product capabilities that define current parity and the space beyond it.
- Evidence: official product/docs first; academic records are used where product marketing does not establish technical guarantees.
- Symbols: `Y` documented; `P` partial/bounded; `—` not established in the reviewed official source; `X` explicitly unavailable or disabled.
- A check mark is not a quality judgment. It means only that a capability is documented.

# Outcome first

By August 2026, prompt-to-song, lyrics/vocals, section editing, reference uploads, stems, MIDI, chat, effects, custom voices/models and real-time generation all exist somewhere. **No single reviewed product combines them with persistent intent, executable preservation locks, verified local edits, native multitrack causality, plural evaluation, human-contribution tracking, cultural grammar, open project portability and adaptive runtime.** That integration—not one more generation button—is the opportunity.

# Capability matrix

| Platform | Full song | Vocals / lyrics | Section edit / inpaint | Audio / image / MIDI reference | Tracks / stems | MIDI / score | DAW-like workspace | Real-time | Private identity / custom model | API | Provenance / rights surface | Portability state |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| Suno v5.5 + Studio 2.0 | Y | Y | Y | Audio Y; MIDI Y in Studio | Separated stems Y | MIDI Y | Y | — | Voices/custom models Y | No official public API established | Commercial rights by paid plan; no copyright warranty | Downloads limited by plan from 2026-09-03; Studio exception [P01-P03, P39] |
| Udio | Y | Y | Y | Audio/styles Y | Stem capability existed; downloads X | — | Sessions P | — | Voices/styles P | No official public API established | Ownership attestation for uploads | Audio/video/stem download disabled [P04-P07] |
| Eleven Music v2 | Y, 3 sec–10 min UI; API 5 min | Y, multilingual | Y, improved inpainting, section build | Audio Reference Y | API/stem surface Y | — | Section composer, not full DAW | Streaming API Y | Private finetunes Y | Y | Broad commercial licensing claim; references screened | Download/API output available subject to plan [P08-P11] |
| Google Lyria 3/3.5/Pro | Y, up to ~3 min family | Y | Section-aware prompting; local edit not established | Text/image Y | — | — | Flow Music / ProducerAI P | Lyria RealTime Y | — | Y | SynthID/C2PA-related provenance in current product family; avoid-artist-mimic positioning | Output route-dependent [P12-P17, P35, P36] |
| Stable Audio 3 | Y, >6 min Medium/Large family | Vocals/lyrics not established here | Single/multi inpainting and continuation Y | Audio-to-audio / text P | — | — | App/workflow, not full DAW | — | LoRA/customization Y | Y + open weights | Licensed-data and enterprise-indemnification claims | Strong self-host/open-weight portability [P20] |
| Adobe Firefly Music | Instrumental/custom-duration Y | No vocal-song claim in reviewed surface | Regeneration/variants P | Video context Y | — | — | Integrated creative-suite workflow | — | Brand/context P | Product/API status must be rechecked | “Commercially safe” vendor positioning | Adobe ecosystem export [P18, P19] |
| Mureka | Y | Y | P | Reference/customization P | Stems Y | — | Song creation workspace | — | Customization Y | Current API not fully verified here | Commercial-rights claim by vendor | Downloads/stems [P23] |
| ACE Studio | Not primarily one-prompt full-song | Score-driven singing Y | Phrase/voice editing Y | MIDI + lyrics + voice input Y | Vocal tracks Y | MIDI/score Y | Vocal production workstation | — | Voice cloning/licensed performers Y | Enterprise possibilities; current public API not established | Licensed-performer catalogue and consent are core | DAW-oriented export [P24] |
| AIVA | Instrumental Y | — | Arrangement/edit P | Audio/MIDI influence Y | Instrumental tracks/MIDI P | MIDI Y | Composer/editor Y | — | Custom style models Y | Enterprise P | Plan-specific rights/copyright claims | MP3/MIDI/WAV by plan [P27] |
| Jen | Y | Not established | Refill/structure/extend Y | Reference P | Stems Y | — | Structured editor P | — | Style filters/custom P | Enterprise P | Vendor positions licensed model | WAV/stems by plan [P26] |
| SOUNDRAW | Instrumental Y | — | Bar-level intensity/mute/solo Y | — | Stems Y | — | Arrangement editor P | — | — | Enterprise P | Self-produced catalogue claim | Download/stems by plan [P28] |
| Loudly | Instrumental/song tools Y | P | Remix/customize/master Y | SongDNA/reference P | Stems Y | — | Web studio P | — | Brand customization P | API/enterprise P | Royalty/licensing package | Downloads/distribution [P29] |
| Mubert | Long/adaptive music Y | — | Adaptive intensity P | Text/image Y | — | — | API/dashboard | Streaming Y | — | Y | Royalty-free vendor claim | Runtime stream/output terms route-dependent [P37] |
| Meta AudioCraft / MusicGen | Research full/clip generation P | Melody conditioning; song vocals not core | Research editing varies | Text/melody Y | Research branches | — | No product DAW | — | Fine-tuning possible | Open research code | Research license/model-card constraints | Code/weights route dependent [P21, P22] |
| PlayMusicPrompts current backend | Y through planner-selected Lyria routes | Y on proven routes; lyric verification planned | Whole-generation/compiled structure; guaranteed local edit not yet proven | User audio/MIDI analyzed to descriptors; named commercial reference refused | Separated/generated/rendered origins planned | MIDI descriptors; exact note conditioning not promised | Current advanced Studio UI | Not yet | Not yet | One conductor endpoint | C2PA/DDEX response contracts and honest rights fields | Master/stems/export routes under product control |

# What is now table stakes

1. One-prompt song creation with instrumental and vocal modes.
2. Custom or AI-written lyrics.
3. Section-aware structure and extension.
4. Replace/add/inpaint a region.
5. Audio references or uploads with rights attestation.
6. Multiple versions and alternates.
7. Stem delivery or separation.
8. WAV/MP3 export.
9. Commercial-use terms for paid users.
10. Mobile or browser creation.
11. Personal voices or customization.
12. Chat assistance.
13. MIDI and effects in the professional tier.
14. API or enterprise access for platform use.

A product that stops here can be excellent, but it is no longer category-defining [P01, P08, P12, P20].

# Frontier gaps nobody reviewed closes as one system

## 1. Persistent, renderer-independent project intelligence

Competitors retain projects, but the reviewed public surfaces do not expose a typed, portable `MusicIntentGraph` that can be rendered by multiple model families while preserving section, motif, lyric, track, rights and evaluation semantics [A01, A08, A21, A23].

## 2. Verifiable Conservation Locks

Products offer “keep” or “edit” workflows, but no reviewed product exposes exact-audio, feature and meaning locks with preflight conflicts and post-render proof. MusicWeaver demonstrates a research path for exact outside-mask preservation, not a deployed market-wide guarantee [A01, A13].

## 3. Native, synchronized and causally editable tracks

Most consumer products provide separated stems. Current research treats synchronized native tracks as a different model problem [A21, A22, A28, A34, A38, A39].

## 4. Audition intelligence

Competitors generate alternatives; they do not publicly establish active preference learning, duplicate clustering, Pareto trade-offs and bar-level comp as one low-listening-burden flow [A07, A19, A36, A37].

## 5. Score-native vocal contract

Current products can sing. The missing product abstraction is an editable vocal score with phoneme/note/duration/breath/identity/consent semantics and independent verification [A24, P24].

## 6. Plural, visible evaluation

Quality, musicality, arrangement, lyrics, vocal identity, cultural fidelity, locality and media fit need separate measurements. SongBench, CMI-RM, MuQ-Eval and MusicRL show why one generic score is inadequate [A25, A36, A37, A44].

## 7. Human contribution and authorship evidence

C2PA and DDEX can carry provenance/disclosure, but role/segment-level human decisions and causal edit history need a product-native contribution passport [A10, S01-S05].

## 8. Executable cultural grammar

Current products advertise genres/languages. Evidence shows non-Western underrepresentation and representation bias below the prompt layer [A14, A31, A32, A42, A43].

## 9. Open project portability

Audio, stems and MIDI are necessary but insufficient. The missing unit is an open semantic project with media, graph, provenance, evaluation and rights. MIDI 2.0, ARA and CLAP provide interoperability ingredients [S10-S12].

## 10. Music runtime

Real-time streams exist, but the larger product is a stateful runtime that adapts motifs, intensity and arrangement to live input, film scenes, games and audience state while preserving world identity [A15, A33, A35, P35, P37].

# PlayMusicPrompts parity-and-beyond checklist

## Must ship for parity

- full song, vocals, custom/AI lyrics;
- structured sections, extend/replace/inpaint;
- user audio/image/MIDI/hum reference intake;
- versions, stems with origin labels, WAV/FLAC/MP3;
- commercial permission and transparent limitations;
- API, webhook, status and cost reporting;
- mobile-friendly Spark experience and professional Deep controls.

## Must ship to exceed

- persistent Music Intent Graph;
- typed reversible Edit Transactions;
- executable locks with proof;
- intelligent audition/comp;
- project-specific evaluator council;
- role/segment contribution passport;
- open `.pmp` archive;
- private artist/brand/culture world models;
- native multitrack and score-native vocal routes;
- scene/game/live runtime.

NOT TO COPY — UNDERSTAND WHAT LIES FAR BEYOND AND BUILD IT
