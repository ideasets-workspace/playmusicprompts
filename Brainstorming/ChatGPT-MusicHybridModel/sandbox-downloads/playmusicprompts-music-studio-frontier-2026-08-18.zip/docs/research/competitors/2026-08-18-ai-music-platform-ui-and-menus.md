# Standards ledger

- Scope: current competitor interaction patterns, the supplied BeforeTomorrow Music Studio screen, and the information architecture required to exceed both.
- The supplied screen is treated as design evidence, not as a feature checklist to copy.
- Current backend parameters and binding states come from the generated 34-parameter contract.
- Competitor UI claims are bounded to official product/help/release surfaces [P01, P04-P06, P08, P14, P18, P24, P27, P31-P34].

# Outcome first

The current white Music Studio is visually clean and unusually honest, but structurally it is still a **three-column parameter cockpit**. Its center of gravity is configuration before generation. The frontier product must move the center of gravity to **the music project itself**: what exists, what it means, what changed, what is locked, which alternatives differ, who contributed and whether the result passed.

Do not add a fourth column or fifty more permanent controls. Preserve the current screen as **Deep Inspector**, then introduce a new object-centered workspace with four agency modes: Spark, Direct, Deep and Perform.

# Current screen audit

## What is strong

- Clear three-stage flow: Creative Brief → Composition Workspace → Generation & Output.
- High information density without a dark generic-AI aesthetic.
- Structure, energy curve, instrument palette, vocal/lyrics, references, stems, rights and versions are visible in one composition.
- The backend contract distinguishes typed, compiled, enforced, prose, refused, response-only and client-side controls instead of pretending every slider is a native model parameter.
- Parameter source-of-truth is generated from the same specification used by runtime validation.

## What limits the experience

1. **Form-first rather than object-first.** Users edit fields, not motifs, phrases, tracks, performances or intentions.
2. **Too many simultaneous decisions for novices.** One-prompt simplicity is visually present but psychologically buried.
3. **Timeline is an overview, not the primary creative canvas.** The user cannot select a musical object and issue a typed local transformation.
4. **No preservation contract.** “Keep everything else” is not represented or verified.
5. **Alternatives are versions, not an audition/comp system.** Differences are not explained.
6. **AI suggestions are side cards.** The product needs causal diffs, not generic recommendations.
7. **Provenance/rights are static badges.** They do not reveal contribution by segment/role or current release blockers.
8. **The waveform is treated as the work.** Structural, lyrical, symbolic, rights and media-state layers are not co-visible.
9. **Collaboration is comment-oriented.** Branches, approvals, protected locks and merge conflicts are missing.
10. **Advanced parameters remain global.** The same control should be contextual to song, section, track, phrase, voice or delivery target.

# Competitor interaction patterns

## Suno Studio 2.0

Documented surface includes multitrack timeline, MIDI recording/editing, built-in synth, effects, automation, musical typing and Studio Chat capable of generating musical/audio/plugin assets [P01]. This establishes a generative-DAW baseline.

**Gap to exploit:** a chat-controlled DAW is still a DAW. PlayMusicPrompts should make chat compile into inspectable project transactions and prove invariants.

## Udio Sessions / editor

Documented flows include upload, extend/remix/style, section editing and voices/styles [P04-P06].

**Gap to exploit:** session editing without guaranteed portable output is not a durable creator workspace [P07].

## Eleven Music

The interface supports section-by-section building, lyrics, transitions, audio references and inpainting, with durations from 3 seconds to 10 minutes in the product UI [P08].

**Gap to exploit:** powerful sections still need persistent motif/track/rights/evaluation relationships and an audition/comp layer.

## Google Flow Music / ProducerAI

Google emphasizes simple direction plus structured control, including tempo, timed lyrics, images and section-aware composition [P12-P16].

**Gap to exploit:** integrate the model into a longer-lived project intelligence and cross-media operating system.

## ACE Studio / AIVA / RipX / conventional DAWs

These products demonstrate score/MIDI/vocal control, arrangement editing and deep audio manipulation [P24, P27, P31-P34].

**Gap to exploit:** professional depth usually assumes domain expertise. PlayMusicPrompts must preserve that depth while translating natural intent into contextual objects and reversible changes.

# New product information architecture

## Global navigation

1. **Home** — continue, review, collaborate, release blockers.
2. **Create** — text, voice, hum, MIDI, audio, image, video, script or game-state intake.
3. **Projects** — songs, cues, albums, branches, shared work.
4. **Worlds** — artist, album, film, game, brand and audience musical memory.
5. **Voices & Instruments** — owned/licensed identities, permissions and training state.
6. **Culture Lab** — grammars, tunings, rhythmic systems, experts and validation.
7. **Live** — Perform sessions and adaptive runtimes.
8. **Library** — prompts, motifs, lyrics, stems, scores, references and exports.
9. **Marketplace** — licensed voices, instruments, producers, culture packs and remix rights.
10. **Teams** — members, roles, approvals, clients and usage.
11. **Developer** — API keys, SDKs, webhooks, schemas, runtime telemetry.
12. **Rights & Provenance** — contribution, consent, C2PA/DDEX, similarity and release status.

# Four experience modes

## Spark — “What should exist?”

### Primary canvas

- One intent field.
- Speak, hum, play, upload or drag media.
- A minimal `Direction Card` summarizing story, energy and use.
- Three differentiated musical directions, not a wall of generations.

### System behavior

- Ask only high-value clarification questions selected by expected information gain.
- Show why each question matters.
- Create a project graph automatically.
- Offer immediate actions: “make it mine,” “change this moment,” “add my voice,” “fit my video.”

## Direct — the core Living Score

### Layout

- **Left:** AI Producer conversation, active intent and unresolved decisions.
- **Center:** Living Score with sections, motif lanes, tracks, lyrics, emotion/story and media events.
- **Right:** contextual inspector for the selected object.
- **Bottom:** Audition Deck, comp lane and version/branch graph.
- **Top:** Agency Mode, branch, Intent Integrity, rights state, cost and render status.

### Selection model

A user can select:

- time range or bars;
- semantic section;
- motif;
- lyric line/word/phoneme;
- track/stem;
- singer/performance;
- mix/spatial object;
- video scene/game state;
- contribution or rights item.

The command bar then proposes operations valid for that object.

## Deep — current Studio becomes contextual

The existing 34 controls remain, but they appear under contextual groups:

- **Project intent:** project, creative goal, prompt, avoid, genres, moods, prompt blocks.
- **Composition map:** tempo, key/tuning, meter, duration, structure, energy, mood orbit.
- **Arrangement:** instruments, sonic tags, harmony/rhythm/polish, track roles.
- **Voice & lyrics:** vocal mode, language, lyric mode, phoneme/score controls.
- **Reference & identity:** owned audio, MIDI, descriptors, rights state.
- **Render & delivery:** route, quality, mastering, format, stems, compliance, seed.
- **Audit:** binding report, measured output, cost, evaluator, provenance and refusal reasons.

No control is always visible merely because it exists.

## Perform — live musical relationship

- role: follow, lead, trade, mirror, challenge, underscore;
- latency/look-ahead indicator;
- live intensity, density, harmony and instrumentation steering;
- freeze/capture a moment into the project graph;
- explicit human-versus-agent contribution timeline.

# Signature interactions

## 1. What I understood / What changes / What remains locked

Before every material edit, show three concise cards and a conflict state. This is the trust contract.

## 2. Difference Lens

For every candidate:

- changed bars/tracks highlighted;
- harmonic/melodic/rhythmic/lyric differences summarized;
- lock scores and failed gates;
- expected cost and render route;
- blind A/B option.

## 3. Audition Map

Candidates appear in a two- or three-dimensional map based on project-relevant differences—fidelity/surprise, intimate/epic, acoustic/electronic—not random thumbnails. Near-duplicates collapse into clusters.

## 4. Bar-level comp

Drag the best phrase, performance or track region from Candidate B into the active branch. The system resolves boundaries and reruns only required tests.

## 5. Intent Integrity

A small top-bar indicator expands to show:

- satisfied constraints;
- unresolved ambiguity;
- soft drift;
- hard violations;
- rights blockers;
- what the model could not prove.

## 6. Contribution Lens

Toggle colors by contributor and generation source across lyric, melody, performance, arrangement, production and selection. This is evidence, not a moral score.

## 7. Time travel with semantic history

Versions are named by decisions—“chorus vocal locked,” “makam grammar applied,” “client-safe 30s cut”—not `v17` alone. Branches can be compared and merged.

# Menu detail inside a project

1. **Intent** — purpose, audience, story, references, negative space and success criteria.
2. **Score** — form, motifs, harmony, rhythm, melody, lyrics and notation.
3. **Tracks** — native/separated/rendered origins, activity, routing and dependencies.
4. **Voice** — identity, consent, score, phonemes, performance and comp takes.
5. **Sound** — instruments, timbre, synthesis, effects, mix and spatial.
6. **Scenes** — video, film, game and live-event synchronization.
7. **Auditions** — candidates, clusters, A/B, pairwise preference and comp.
8. **Evaluate** — hard gates, diagnostics, expert review and uncertainty.
9. **Versions** — commits, branches, merges, approvals and restore.
10. **Deliver** — masters, stems, MIDI, score, social cuts, runtime package and release metadata.
11. **Rights** — identity permissions, sources, similarity, contribution and disclosures.
12. **Inspector** — current 34-parameter and future advanced surface.

# Visual-design DNA

- White, warm and editorial rather than sterile SaaS.
- Music objects use restrained spectral texture, not neon AI gradients.
- The selected musical object is always visually primary.
- Controls appear only when causally relevant.
- Every AI action has an undoable diff and source identity.
- Confidence uses language plus evidence, not decorative percentages.
- The waveform is one layer among score, lyrics, motifs, tracks and story.
- Accessibility includes keyboard-first operation, screen-reader labels, reduced motion, high contrast and non-audio difference descriptions.

# First redesign milestone

Build one Direct-mode screen around a generated project:

- Living Score center;
- Producer left;
- contextual inspector right;
- Audition/versions bottom;
- preflight cards for change/lock;
- visible binding and evaluator report.

This single screen will prove the category more strongly than adding another hundred controls to the current layout.

NOT TO COPY — UNDERSTAND WHAT LIES FAR BEYOND AND BUILD IT
