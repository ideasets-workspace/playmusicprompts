# Standards ledger

- Scope: how current AI-music companies capture value, which incentives their models create, and where PlayMusicPrompts can build a structurally different business.
- Current commercial facts use official pricing, policy and partnership sources [P02, P07, P10, P15, P20, P26, P27, P38, P39].
- Proposed models below are recommendations/inferences and are labelled accordingly.

# Outcome first

The raw generation model is heading toward commodity economics: published full-song inference can cost cents, open weights are improving, and multiple providers expose APIs. The durable business is therefore not “sell more generations.” It is to own the **project state, revision intelligence, creator preference, licensed identity graph, collaboration workflow, evaluator evidence, portability standard and adaptive runtime**.

The strongest position is a two-sided creative infrastructure business:

1. creators and teams pay for a persistent Music OS;
2. rights holders, performers, instrument makers and culture experts license authenticated creative capabilities;
3. media and application developers pay for runtime/API delivery;
4. every party receives transparent contribution and usage evidence.

# Current business-model archetypes

## 1. Credit factory

**Examples:** Suno, Jen and many consumer generators [P02, P26].

- Revenue unit: monthly credits/generations.
- Strength: simple, viral, easy to meter.
- Structural weakness: encourages high attempt volume; can make failed generations profitable to the vendor and frustrating to the creator.
- Likely evolution: credits become render classes—preview, full, stem, edit—while subscriptions anchor retention.

## 2. Generative workstation subscription

**Examples:** Suno Studio, ACE Studio, AIVA, emerging generative DAWs [P01, P24, P27].

- Revenue unit: premium seat/month.
- Strength: higher willingness to pay and workflow retention.
- Weakness: legacy-DAW complexity and proprietary project lock-in.
- Opportunity: PlayMusicPrompts can be AI-native rather than a DAW with a chat panel.

## 3. API utility

**Examples:** Google Lyria, Eleven Music, Mubert, Stability AI [P09, P15, P20, P35-P37].

- Revenue unit: count, generated minute, active stream/session or negotiated enterprise volume.
- Strength: distribution through other products.
- Weakness: provider switching and thin differentiation if the API is the whole product.
- PlayMusicPrompts role: make providers replaceable render adapters under a stable project/evaluation contract.

## 4. Enterprise customization / private model

**Examples:** Eleven finetunes, Stable Audio LoRA/enterprise, Suno custom models, brand/artist tools [P02, P10, P20].

- Revenue unit: setup/training fee, annual license, private inference and support.
- Strength: high-value proprietary data and identity continuity.
- Risk: consent, leakage, revocation and unclear ownership of the resulting model.
- PlayMusicPrompts opportunity: a versioned, revocable `IdentityObject` with asset-level permissions and usage ledger.

## 5. Rights-gated creator plan

**Examples:** AIVA plan tiers and most paid commercial-use packages [P03, P27].

- Revenue unit: premium rights/monetization entitlement.
- Strength: makes licensing legible.
- Risk: marketing can blur commercial permission, ownership, copyrightability and indemnity.
- Required response: separate every declaration and never sell a false “copyright guaranteed” badge.

## 6. Open weights + commercial enterprise license

**Example:** Stable Audio 3 [P20].

- Revenue unit: enterprise licensing, managed API, customization/support.
- Strength: ecosystem and private deployment.
- Weakness: downstream fragmentation and infrastructure burden.
- PlayMusicPrompts opportunity: support open routes without making users manage model operations.

## 7. Licensed remix / identity ecosystem

**Emerging evidence:** Spotify–UMG fan-made cover/remix agreement and label/model partnerships [P38].

- Revenue unit: paid add-on, rights-holder revenue share, identity/track license.
- Strength: converts conflict into opt-in participation.
- Risk: catalogue fragmentation, territory/term restrictions and opaque royalty accounting.
- PlayMusicPrompts opportunity: rights-aware remix transactions with machine-readable allowed transformations and automatic split reporting.

## 8. Distribution ecosystem

**Examples:** Adobe suite integration, Loudly distribution and future streaming-platform creation tools [P18, P19, P29, P38].

- Revenue unit: suite retention, add-on, distribution services or downstream monetization.
- Strength: creation is embedded where content is delivered.
- Risk: closed ecosystem controls discovery and ownership.
- Ideasets advantage: connect BeforeTomorrow, FutureMovies, games, ads and social creation through one music intelligence layer without making one distribution platform the source of truth.

# The hidden incentive problem

When the product is paid per generation, three harmful incentives appear:

1. poor controllability can increase paid retries;
2. the product celebrates volume rather than creator completion;
3. spam catalogues can look like growth until distribution platforms reject them.

Spotify's official policy explicitly targets spam, unauthorized impersonation and incomplete AI disclosure [S08]. Suno's new download policy shows that access to the artifact itself can become a monetization lever [P39]. Udio shows that partnerships can remove export after users have built workflows [P07].

**Committed business doctrine:** PlayMusicPrompts must align revenue with **Idea-to-Owned-Release**, not with failed generations.

# Proposed PlayMusicPrompts revenue stack

## Layer A — Music OS subscription

Pays for persistent projects, Living Score, revisions, versioning, collaboration, evaluation and open export. This is the recurring core.

## Layer B — Transparent render units

Heavy actions consume clearly named units:

- preview;
- full render;
- local edit;
- native track pass;
- vocal-score render;
- high-resolution master;
- live runtime minute;
- private-model inference.

The user sees expected cost before commit. Cheap deterministic graph/DSP operations do not masquerade as model generations.

## Layer C — Private World Models

Artists, labels, agencies, games and brands pay for:

- authorized catalogue ingestion;
- preferences and rejection boundaries;
- motif/arrangement/voice/instrument identities;
- private deployment and retention controls;
- periodic evaluation and drift audits.

## Layer D — Licensed Identity and Culture Marketplace

Supply-side participants:

- singers and performers;
- producers/mix engineers;
- instrumentalists and instrument makers;
- labels/publishers;
- cultural experts and ensembles;
- sample/library owners.

Each item is an authenticated object with allowed uses, prohibited transformations, territory, term, price/split, attribution and revocation policy. PlayMusicPrompts takes a disclosed marketplace fee.

## Layer E — Media Runtime

Games, apps, wellness, live experiences and interactive stories pay by active session/minute, concurrency, audience scale or enterprise commitment. The deliverable is a stateful musical world, not a static track.

## Layer F — Enterprise evidence and control

- regional/private/on-prem routes;
- SLA, audit logs and SSO;
- legal/rights policy engine;
- custom evaluator panels;
- release approval workflows;
- model/provider routing and spend controls.

# Defensibility map

| Asset | Why it compounds | Why a raw model cannot easily copy it |
|---|---|---|
| Music Intent Graph history | Captures what a creator meant across revisions | Requires long-lived product interaction, not only training audio |
| Edit decision dataset | Records preserve/change/reject/comp/revert behavior | High-value labels arise only during real creative work |
| Creator preference boundary | Learns both attraction and avoidance | Generic RLHF averages across people and cultures |
| Licensed identity graph | Rights, consent, allowed transformations and usage | Requires relationships, contracts and transaction evidence |
| Culture grammars | Encodes theory, practice, language and expert evaluation | Cannot be reduced to a genre token or scraped playlist |
| Evaluator council | Measures project-specific success and hard invariants | Requires proprietary tests and failure data |
| Open `.pmp` ecosystem | Makes the project durable across renderers/tools | A model endpoint cannot create a standard alone |
| Adaptive runtime | Links music state to games/video/live contexts | Depends on orchestration, state and integrations |

# Business risks and countermeasures

| Risk | Countermeasure |
|---|---|
| Model quality leap by a competitor | Provider-independent graph and evaluation; route the new model rather than rebuild the product. |
| Price race to zero | Monetize projects, identities, teams and runtime instead of raw inference margin. |
| Rights litigation / policy change | Consent-first identity objects, provenance, similarity review, provider reversibility and jurisdiction policy adapters. |
| Creator distrust | Export guarantee, deletion controls, no default training on private projects, visible bindings and usage logs. |
| Spam growth | Completion/ownership metrics; rate and release-quality gates; no rewards for bulk low-value uploads. |
| Marketplace imbalance | Transparent minimums, opt-in transformation rights, revocation windows and auditable splits. |
| Cultural extraction | Co-governed packs, expert approval, compensation and context restrictions. |

# One committed recommendation

Build PlayMusicPrompts as a **Music OS + licensed capability network + runtime platform**. Keep raw model generation a replaceable cost center. Guarantee open export. Make every revenue line strengthen creator ownership, controllability or authorized participation.

NOT TO COPY — UNDERSTAND WHAT LIES FAR BEYOND AND BUILD IT
