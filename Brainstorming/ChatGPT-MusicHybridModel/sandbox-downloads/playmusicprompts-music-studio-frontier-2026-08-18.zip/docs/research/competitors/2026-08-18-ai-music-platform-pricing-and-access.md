# Standards ledger

- Scope: current public access and pricing surfaces relevant to PlayMusicPrompts as of 2026-08-18.
- Evidence rule: exact prices are dated single-authority facts from official pricing/policy pages and must be reopened before purchase or launch.
- Source IDs resolve through `../_sources/2026-08-18-playmusicprompts-source-register.md`.
- This report compares incentives and access architecture; it does not treat a cheap nominal generation price as total production cost.

# Outcome first

The market still prices **attempts**—credits, songs, minutes or generations—rather than successful creative outcomes. That incentive becomes increasingly misaligned as generation gets cheap and review/revision becomes the scarce work. PlayMusicPrompts should charge primarily for persistent projects, professional rendering capacity, private identities/world models, collaboration and runtime delivery—not for every failed experiment.

The second hidden finding is that **portability has become a monetized privilege and, in one major case, disappeared entirely**. Suno is introducing plan-level download limits while exempting Studio users; Udio currently disables audio, video and stem downloads. The strategic response should be the opposite: make export and project ownership a permanent creator contract, then monetize intelligence and service above portability [P07, P39].

# Dated competitor access matrix

| Product / route | Public price or access state, 2026-08-18 | Meter | Material entitlements / constraints | Strategic reading |
|---|---|---|---|---|
| Suno Free | $0 | 50 daily credits / about 10 songs | v4.5-all, no commercial use, no monthly downloads from 2026-09-03, no stems | Acquisition loop; output rights and portability create upgrade pressure [P02, P39]. |
| Suno Pro | $8/month when billed annually | 2,500 monthly credits / up to 500 songs | Commercial use for newly made songs; advanced editing; 2 stem-separation types; 20 downloads/month from 2026-09-03 | Very low apparent cost per attempt; generation volume is the value unit [P02, P39]. |
| Suno Premier | $24/month when billed annually | 10,000 monthly credits / up to 2,000 songs | Studio 2.0, 3 stem-separation types, custom voice/model features; 60 song downloads/month, but Studio outputs exempt from download limits | Studio access—not raw generation—is the premium anchor [P01-P03, P39]. |
| Eleven Music API | $0.15/generated minute | Per output minute | 5-minute API limit, commercial licensing on Starter+; current API pricing page lists $1.50 per music finetune | Developer-friendly variable cost; four-minute output is a $0.60 raw-generation line item before retries and downstream processing [P09-P11]. |
| Google Lyria 3 | $0.04 per count | 30-second clip | Text/image input; high-fidelity clip | Excellent preview/routing substrate; 12 previews have a $0.48 published model-cost floor [P13, P15, P36]. |
| Google Lyria 3 Pro | $0.08 per count | Full-song generation | Text/image input; full-song route, published up-to-three-minute family capability | Very low published generation floor; orchestration, evaluation, storage and post-production dominate real cost [P12-P16]. |
| Google Lyria 2 | $0.06 per count | Instrumental generation | Text prompt; current GA instrumental route | Useful fallback where typed seed/negative controls are required in the current backend [P13, P15]. |
| Jen Free | $0 | 20 monthly credits/tracks | Downloadable tracks; limited extensions; no stem download | Freemium entry [P26]. |
| Jen Dabbler | $9.99/month | 300 credits/tracks | Trim, refill/structure tools, WAV and stem download | Editing is bundled unusually low; exact quality and rights are outside this pricing comparison [P26]. |
| Jen Soloist | $24.99/month | 1,000 credits/tracks | Advanced structure/reimagine tools, stems, up to five concurrent generations | Creator tier [P26]. |
| Jen Pro | $249.99/month | 10,000 credits/tracks | Bulk download, custom folders, up to 25 concurrent generations | Explicit professional/enterprise concurrency anchor [P26]. |
| AIVA Free | €0 | 3 downloads/month | Non-commercial, credit required, AIVA-owned copyright claim, up to three minutes, MP3/MIDI | Rights restrictions are the upgrade mechanism [P27]. |
| AIVA Standard annual | €11/month + VAT | 15 downloads/month | Limited social-platform monetization, up to five minutes, MP3/MIDI | Context-limited rights package [P27]. |
| AIVA Pro annual | €33/month + VAT | 300 downloads/month | User copyright claim, unrestricted monetization, up to 5:30, all formats and WAV | Rights/ownership is the premium promise [P27]. |
| Stable Audio 3 | Open weights for Small/Medium; Large via API; Enterprise license for qualifying organizations | Self-hosted compute, API or negotiated license | Small on-device, Medium open-weight full music, Large managed; LoRA/customization and inpainting | Open/customizable deployment is the differentiator; total cost becomes infrastructure and governance [P20]. |
| Udio | Current exact pricing not revalidated in this run | Subscription credits | Standard/Pro credit limits increased after UMG deal; audio/video/stem downloads disabled | A warning that product rights/partnerships can break creator portability [P04-P07]. |
| Adobe Firefly Music | Included through current Adobe/Firefly access; exact music-specific unit price not established here | Subscription/generative credits | Video-aware instrumental generation and duration fit | Cross-suite distribution is the moat, not a music-only subscription [P18, P19]. |
| Mubert API | Official page exposes API/streaming; exact public enterprise price not established here | Negotiated/API usage | Text/image generation, adaptive streaming and long-form use cases claimed by vendor | Runtime/adaptive B2B orientation rather than song-production depth [P37]. |
| Mureka / ACE Studio / Soundraw / Loudly | Current exact prices intentionally not asserted without a verified pricing capture in this run | Subscription/enterprise varies | Relevant feature evidence is covered in functions report | Reopen official pricing before procurement [P23, P24, P28, P29]. |
| Open-weight route | No subscription price | GPU/CPU/QPU infrastructure, engineering and licensing | Model weights, adapters, private deployment, reproducibility and maintenance | Nominally “free” weights are not free production; they buy control, privacy and reversibility [A03, P20-P22]. |

# Raw published-cost thought experiments

These are lower-bound calculations from official model prices, not total unit economics.

## Audition-first flow on Lyria

- Twelve 30-second previews: `12 × $0.04 = $0.48`.
- Two full-song finalist renders: `2 × $0.08 = $0.16`.
- Published model-generation floor: **$0.64**.

This does not include intent compilation, embeddings, candidate evaluation, storage, stems, vocal verification, mastering, retries or support. It demonstrates why PlayMusicPrompts can afford to spend more compute on intelligent search while still pricing for creative value rather than raw calls.

## Four-minute Eleven Music output

- `4 × $0.15 = $0.60` per generated output minute path.
- Eight unstructured full attempts would therefore imply a $4.80 raw-generation floor before post-production.

The product implication is not “avoid Eleven”; it is to use preview/search and local editing so expensive full renders are reserved for candidates with high expected utility.

# Business-model gaps the market leaves open

1. **No creator-success meter.** Credit models reward generation volume, not finished project rate.
2. **No guarantee against output hostage.** Download and export can be restricted by plan or partnership.
3. **No persistent open project value.** Most subscriptions own the interface, not a portable music-state object.
4. **No transparent cost of revision.** Users cannot see whether an edit invokes a whole song, a local region, a stem or a deterministic DSP stage.
5. **No clear separation of rights claims.** Commercial-use permission, copyrightability, ownership assignment, provenance and indemnity are often blended in marketing language.
6. **Private identity is emerging as a premium layer.** Suno custom models/voices, Eleven finetunes and Stable Audio LoRA point toward personalized model economics [P02, P10, P20].
7. **Runtime music has a different meter.** Games, wellness, live tools and adaptive media need sessions, active minutes and concurrency—not songs [P35, P37].

# Proposed PlayMusicPrompts commercial architecture

The following is a product hypothesis to validate, not a market fact.

## Free — Spark

- Three active projects.
- Low-cost previews and one finished personal-use render per month.
- Full Music Intent Graph and project history remain exportable in `.pmp`.
- No artificial lock on the user's own prompt, lyrics, MIDI or uploaded assets.

## Creator — proposed $19/month test

- Larger active-project allowance.
- Commercial-use generation under the applicable model route.
- Direct mode, local editing, version branches, common stems, WAV and open project export.
- Monthly compute budget expressed in **render units**, with preview/local/full actions clearly priced.

## Pro — proposed $49–79/month test

- Deep and Perform modes.
- Native-track routes when available, advanced comping, score/MIDI, DAW bridges, higher concurrency, private preference memory and release-readiness package.
- No download cap on user-owned projects.

## Studio / Team — proposed $149–299/month test

- Shared worlds, review/approval, branch protection, client portals, brand/artist models, larger storage and seats.
- Usage-based heavy rendering above a generous included pool.

## Enterprise / Runtime

- API, SLA, regional/private deployment, on-prem/open-weight adapters, adaptive sessions, game/media concurrency and custom rights terms.
- Licensed identity and culture-pack marketplace fees are passed through transparently with a platform take rate.

# Pricing doctrine

- Charge for **persistent value**: projects, worlds, collaboration, private models, runtime and delivery.
- Make compute legible: preview, local edit, full render, native stems, vocal pass, master and evaluation each return a cost estimate.
- Never expire creator-owned project exports.
- Do not hide portability behind the highest tier.
- Do not promise copyright; state commercial permissions, contribution evidence and jurisdictional uncertainty separately.
- Use paid generation only after candidate search reduces waste.
- Reopen every vendor price, plan, limit and term at execution time.

NOT TO COPY — UNDERSTAND WHAT LIES FAR BEYOND AND BUILD IT
