# Standards ledger

- Governing owner research covenant: `/mnt/data/SKILL(20260818-090213).md`, SHA-256 `f19f5cb14319e09ec73fdf42feef2d3067ec8a5949a34657ed9e5c1104d5f9eb`.
- Existing generated Music Studio contract: `/mnt/data/Yapıştırılan markdown(20260818-090450).md`, SHA-256 `29a5b83e5cb69a773ae885cd8f1e0960035e883740a1a85c8334b1a5f7a07a1d`.
- Existing UI reference: `/mnt/data/BeforeTomorrow_MusicStudio_white.png`, SHA-256 `5c63bed06c8ddd56d43982e91e4419e512a1cb7071018d20b068716c581028a9`.
- Scope plan: `2026-08-18-playmusicprompts-music-studio-scope-plan.md`.
- Source register: `_sources/2026-08-18-playmusicprompts-source-register.md`.
- Evidence labels in this report refer to IDs in that register. Statements marked **INFERENCE** are product deductions rather than source claims.

# Scope plan / decision served / why / project context

## Decision served

Define the category, product architecture, interaction model, technical control plane, evaluation system, rights layer, economic model, and build sequence that can turn `playmusicprompts.com` and BeforeTomorrow Music Studio into the most advanced human-centered music creation system rather than another prompt-to-song generator or a cosmetic AI layer over a DAW.

## Project state

The current backend is already more honest than most commercial creative interfaces: one conductor validates a documented request surface, selects a route, reports the model that actually received each request, compiles or enforces controls where possible, and labels controls that are only prose, client-side, response-only, or refused. The present UI exposes 34 parameters across creative brief, composition, vocal/lyrics, and output. This research therefore treats the current Studio as a strong **Deep Inspector**, not as the final product category.

## Falsifiers

The recommendation would change if: (1) professional and novice users consistently preferred disposable one-shot outputs over persistent editable projects; (2) exact or feature-level preservation could not be measured or enforced; (3) native multistem and score-level render paths failed to outperform source-separated mixed audio for production use; (4) provenance and consent made personalization economically nonviable; or (5) a current competitor already combined persistent intent, typed local edits, true multitrack generation, user-specific preference learning, open portability, cultural depth, and granular contribution provenance in one product.

# Outcome first

## Committed decision

Build **PlayMusicPrompts as a Living Music Engine**: a renderer-independent Music Creation Operating System in which the durable object is not a prompt or an MP3, but a continuously editable **Music Intent Graph / Living Score**.

The model should first create and maintain a project-level representation of what the music is trying to do—form, motifs, lyrics, phonemes, performance, tracks, emotion, scene, culture, rights, and constraints—and only then render audio through the best available model route. Every subsequent request should become a typed, reversible **Edit Transaction** over that representation.

The first category-defining promise should be:

> Change exactly what I mean, preserve everything I love, show me the alternatives that matter, and give me a project I truly own and can continue anywhere.

## Why this is the frontier

The commercial frontier has already absorbed text-to-song, vocals, sections, reference audio, inpainting, stems, MIDI, effects, automation, chat, private tuning, and long-form generation. Those capabilities are required, but they no longer define the category [P01, P08, P10, P12, P16, P20, P32-P34, P35-P38]. Research converges on a deeper architecture: explicit planning before rendering, hierarchical representation, native track modeling, score-native vocals, typed edits, exact or measured preservation, multi-dimensional evaluation, and human agency [A01, A21-A28, A33-A35].

# The hidden truths

## Hidden truth 1 — The song is not the waveform

A waveform is one rendering of a musical world. It cannot by itself express why a chorus returns, which motif belongs to which character, which lyric syllable must land on which note, which instrument is allowed to change, what part of the output is human-authored, or which rights attach to a voice.

MusicWeaver, SketchSong, MusicLayout, MusiChat, and the emerging hierarchical world-model work all point toward intermediate representations that separate high-level musical intent from low-level sound [A01, A08, A21, A23, A26]. **INFERENCE:** the winning product should make that intermediate representation persistent, user-visible, editable, and model-independent rather than treating it as an internal disposable chain-of-thought.

### Product consequence

Create a `MusicIntentGraph` containing:

- global purpose, audience, use context, narrative and emotional contract;
- section graph, bar map, tempo/meter/tuning maps and transitions;
- motif objects with recurrence, transformation and ownership;
- harmony, rhythm, groove and instrumentation roles;
- lyric, language, syllable, phoneme, note and breath alignment;
- vocal identities and licensed identity objects;
- track/stem objects and cross-track dependencies;
- mix, mastering, spatial and delivery targets;
- hard and soft preservation constraints;
- media events, game states and live-performance states;
- contribution, source, consent, provenance and version history.

The prompt becomes an input language for the graph. It is not the project database.

## Hidden truth 2 — The scarce resource is no longer generation; it is trustworthy revision

When generation is cheap, creators accumulate options faster than they can evaluate them. VidTune and the ten-week novice study identify review, comparison, selection, collaging and refinement as the new bottleneck [A07, A19]. Producer research finds that generated ideas often fail when the creator needs to integrate a specific intention into an existing work [A06].

### Product consequence

Do not make the user listen to 20 unstructured full songs. Build an **Audition Intelligence Engine** that:

1. creates inexpensive, strategically diverse previews;
2. clusters near-duplicates;
3. removes candidates that violate hard constraints;
4. shows a Pareto frontier rather than one opaque score;
5. highlights the exact musical differences;
6. asks the user the smallest number of pairwise questions needed to learn preference;
7. permits bar-level comping across candidates;
8. learns from accepted, rejected and reverted decisions.

The interface should say, for example:

- Candidate A preserves the vocal identity most strongly.
- Candidate B changes the harmonic tension but not the melody.
- Candidate C has the largest surprise budget and the weakest reference match.
- Candidate D is the only version passing all lyric-pronunciation and mix thresholds.

## Hidden truth 3 — “Regenerate” is the wrong primitive

The dominant interaction today is to ask again and hope. MusicWeaver instead formalizes edits as typed operations and uses projected inpainting to preserve audio outside the edit span by construction [A01]. Stable Audio 3 adds single- and multi-segment inpainting, but product documentation does not establish MusicWeaver's exact repeated-revision guarantee [P20].

### Product consequence

Every edit must compile to an `EditTransaction`:

- `selection`: bars, seconds, semantic sections, stems and graph nodes;
- `operations`: replace, insert, delete, extend, reharmonize, re-orchestrate, re-voice, re-lyric, remix, restyle, re-perform;
- `hard_invariants`: properties that may not change;
- `soft_invariants`: properties that may move within tolerance;
- `transition_collar`: the smallest boundary region allowed to change for smooth joins;
- `variation_budget`: where surprise is permitted;
- `candidate_policy`: count, diversity and preview quality;
- `evaluation_plan`: tests that must pass;
- `commit_policy`: automatic, user-confirmed or branch-only;
- `rollback`: parent version and source assets.

No edit is committed before the system shows **What I understood / What changes / What remains locked**.

## Hidden truth 4 — A lock must be executable, not decorative

“Keep the singer” can mean identical waveform, same voice identity, same vocal melody, same lyrics, same prosody, or merely a similar performance. These are different constraints.

### Product consequence

Build three lock classes:

1. **Exact locks** — sample-identical audio outside the allowed region; verified by sample/hash comparison.
2. **Feature locks** — melody, chords, groove, tempo, singer identity, lyric phonemes, instrument identity, loudness, spatial position; verified by dedicated estimators and thresholds.
3. **Meaning locks** — emotion, narrative function, cultural grammar, brand identity; evaluated by a council of models plus human or expert review where objective measurement is insufficient.

A lock that cannot be verified must be shown as `requested_unverified`, not green.

## Hidden truth 5 — Separated stems are not generated tracks

Source separation gives useful outputs, but those outputs inherit bleed, artifacts and entanglement from a mixed master. Stemphonic, SyncTrack, MusicGen-Stem, JEN-1 Composer and SketchSong all treat native multitrack generation or refinement as a distinct problem [A21, A22, A28, A38, A39]. Stemphonic reports variable synchronized stems in one pass and 25–50% faster full-mix generation than sequential baselines; SyncTrack explicitly targets common rhythm and cross-track synchronization [A22, A28].

### Product consequence

Every delivered stem should declare its origin:

- `generated_native`;
- `generated_conditioned`;
- `rendered_symbolic`;
- `separated_from_mix`;
- `derived_dsp`;
- `human_uploaded`.

The long-term core should use a shared musical clock and shared latent context to generate coordinated, independently editable tracks. The master should be a render of the track graph, not the only source from which tracks are inferred.

## Hidden truth 6 — Vocals require a separate composition contract

A singer is not a timbre preset. Real vocal control couples language, phonemes, syllables, note values, pitch contours, duration, breath, register, articulation, emotion and consent. VocalRender's score-native architecture directly consumes lyrics, pitches, symbolic note values and tempo; it was trained on 2,300 hours and reports strong intelligibility, melody control and speaker similarity [A24].

### Product consequence

Create a dedicated `VocalScore` object and renderer pipeline:

- word → syllable → phoneme → note mapping;
- duration and melisma policy;
- stress, consonant timing and pronunciation dictionary;
- register, chest/head mix, breath, vibrato and ornamentation envelopes;
- performance direction per phrase;
- identity/consent object and permitted transformations;
- language-specific verification;
- alternate takes and comp lanes.

For Turkish, the system needs a real phoneme and prosody layer—not a `language: tr` label.

## Hidden truth 7 — The greatest proprietary dataset is the revision trail

Raw music corpora teach what music sounds like. They do not reveal, with sufficient density, what a particular creator intended to preserve, what they rejected, why they preferred one alternative, or how a rough idea became a finished work.

MusicRL shows that large-scale pairwise preference data can improve music generation beyond text-adherence and generic quality objectives [A37]. User studies show creators repeatedly select, reject, reframe and integrate outputs [A05-A07, A19].

### Product consequence

Build the **Edit Data Flywheel**. With explicit permission, capture:

- prompt/intent before and after clarification;
- graph state before and after each edit;
- hard/soft locks;
- candidate set and diversity metadata;
- pairwise decisions and rationale;
- accepted/rejected bars and stems;
- comp operations;
- revert events;
- final export context;
- user-specific preference boundaries;
- whether the change increased project completion.

**INFERENCE:** this data is more defensible than a generic scraped-song corpus because it teaches controllable transformation and preference, not only imitation.

## Hidden truth 8 — One universal reward model will flatten music

Preference is plural. MusicRL found that text alignment and generic quality explain only part of human preference [A37]. Cross-cultural research shows that prompt language differs from listening language and varies across linguistic/cultural cohorts [A14]. `Music for All` reports that only 5.7% of hours in surveyed music-generation datasets came from non-Western genres, and adaptation to Hindustani classical and Turkish makam remained non-trivial even with parameter-efficient fine-tuning [A31].

### Product consequence

Use a hierarchy of reward/evaluation models:

- universal technical quality;
- project intent;
- creator preference;
- audience/use-context preference;
- cultural grammar;
- label/brand constraints;
- novelty and anti-copying;
- accessibility and safety.

Never collapse them into a single “quality 92” badge. Expose trade-offs and preserve minority aesthetics.

## Hidden truth 9 — The interface must manage agency, not only complexity

A 2026 experiment with 162 participants found that higher automation reduced psychological ownership and sense of agency, with stronger effects among experts [A17]. Practising-musician research similarly highlights control over the amount, type and location of variation [A05].

### Product consequence

Add an **Agency Mode** that changes who makes which decisions:

- `Spark` — system proposes almost everything; the user gives intent and selects.
- `Co-create` — system proposes structured alternatives and the user shapes them.
- `Direct` — user specifies musical decisions; AI executes and verifies.
- `Perform` — user plays/sings/moves; AI follows and responds in real time.

Agency mode is not a cosmetic UI preset. It changes planning authority, clarification thresholds, candidate generation, auto-commit permissions and contribution records.

## Hidden truth 10 — Chat is useful only when it controls a deterministic project state

Suno Studio 2.0 already lets chat generate instruments/vocals, create synth presets and effects, and assist inside a MIDI/automation environment [P35]. Chat alone is therefore not differentiation.

### Product consequence

The PlayMusicPrompts Producer should never merely rewrite the master prompt. It must:

- read the selected graph context;
- produce a typed diff;
- explain conflicts;
- simulate likely effects;
- request clarification only when needed;
- offer reversible branches;
- report which controls were typed, compiled, enforced or only advisory;
- verify the delivered result.

The existing binding taxonomy becomes the foundation of the conversational contract.

## Hidden truth 11 — Evaluation is part of the product, not an offline benchmark

SongBench defines seven professional dimensions—Vocal, Instrument, Melody, Structure, Arrangement, Mixing and Musicality—and uses 11,717 expert-annotated samples [A25]. Current preference benchmarks add large pairwise datasets, while MusicWeaver introduces plan-faithfulness and edit-fidelity measures [A01, A36].

### Product consequence

Build **PMP-Eval Council**, with gates for:

- intent and section-plan adherence;
- long-range structure and motif recurrence;
- harmonic/rhythmic validity and desired complexity;
- lyric phoneme/word accuracy and phrase alignment;
- singer identity and performance consistency;
- track isolation, leakage and synchronization;
- edit locality and invariant preservation;
- artifacts, clipping, loudness, true peak, stereo/phase and codec integrity;
- cultural grammar fidelity;
- originality/similarity risk;
- rights and provenance completeness;
- user preference and project utility.

Bad candidates should be rejected before the user hears them. Metrics should appear only with estimator identity, confidence and scope.

## Hidden truth 12 — Attribution and originality must be built into generation

HAIM argues that binary “AI/not AI” classification is misaligned with hybrid production and proposes contribution tracking across components, stages and time [A10]. C2PA preserves signed change history; DDEX is developing AI-generated music metadata; Spotify says AI use is a spectrum and plans credit-level disclosure [S01-S04, S08]. MusicMark tests a generative watermark under 20 attacks, including music-specific cover-song attacks, while ARIA decomposes training-data attribution by musical aspect [A29, A30].

### Product consequence

Create three distinct systems and never conflate them:

1. **Content provenance** — what tools/actions produced this asset.
2. **Training influence evidence** — what training groups may have influenced an output and along which musical dimensions.
3. **Similarity/originality review** — whether an output is suspiciously close to existing material.

None alone proves legal clearance. Together they make risk visible and auditable.

## Hidden truth 13 — Rights can become the marketplace, not merely a compliance page

Streaming policy is moving toward authorization for vocal impersonation, granular AI disclosures and anti-spam enforcement [S08]. Creator organizations increasingly emphasize consent, control, credit and compensation. Commercial vendors are already offering private sonic finetunes or licensed-data positioning [P10, P20, P24].

### Product consequence

Build **Licensed Identity Objects**:

- artist, singer, instrumentalist, producer, songwriter, studio, brand and cultural-expert identities;
- explicit permitted inputs, outputs, territories, contexts and duration;
- prohibited uses and style-distance boundaries;
- revocation and versioning;
- attribution requirements;
- flat fee, usage fee, revenue share or hybrid compensation;
- output-level lineage and reporting.

A creator should be able to publish a licensable musical world without surrendering unrestricted identity rights.

## Hidden truth 14 — Cultural depth is a model architecture problem

The current contract already includes Turkish makam fusion, Anatolian folk, aksak meters, bağlama, ney and darbuka. That is an important seed, but most controls are currently represented as prose or fixed vocabulary. Cross-cultural evidence shows that non-Western music is underrepresented and that state-of-the-art audio models struggle with subtle cultural meaning [A14, A31, A32].

### Product consequence

Create executable **Culture Grammars**, starting with Turkish music:

- tuning and microtonal pitch representation;
- makam family, seyir, karar/güçlü and modulation rules;
- usul and additive meter grammar;
- ornamentation and instrument technique;
- form and phrase conventions;
- Turkish phoneme, stress and melisma rules;
- expert-curated examples and negative cases;
- culture-specific evaluators;
- contributor governance and compensation.

Culture must be encoded as constraints, transformations and performance practice—not as a genre chip.

## Hidden truth 15 — Portability is a trust promise and a competitive weapon

Udio disabled audio, video and stem downloads after its UMG partnership, demonstrating how a platform-level policy change can break a professional workflow [P07]. Professional users repeatedly ask for DAW integration and editable exports [A06]. MIDI 2.0, ARA and CLAP provide modern paths for expressive, project-aware and non-destructive integration [S10-S12].

### Product consequence

Publish an open, versioned `.pmp` project package containing:

- graph JSON/CBOR;
- audio masters and track/stem assets;
- MIDI 1/2 and notation representations;
- lyric/phoneme maps;
- automation and effect metadata;
- preview proxies;
- C2PA manifests and DDEX/RIN mappings;
- rights objects and contribution passport;
- model/seed/route/evaluator records;
- branch/commit history.

Offer ARA/VST3/CLAP adapters, Ableton/Logic/FL Studio export profiles and API-level project portability. The user’s work must survive the platform.

## Hidden truth 16 — The ultimate product is a music runtime, not an export button

Google's Lyria RealTime exposes a persistent bidirectional WebSocket for continuously steered instrumental generation [P17, P37]. Live-agent research reviews 184 systems and frames the challenge across interaction, technology and ecosystem rather than latency alone [A15]. Real-time accompaniment work shows the practical trade-off among latency, look-ahead and quality [A35]. Video-Robin and current multi-agent video work add intent-grounded audiovisual planning [A33].

### Product consequence

After static song creation, the same Living Score should compile to:

- loop-safe game states;
- intensity layers and transitions;
- character/brand motifs;
- dialogue-aware film cues;
- variable-duration social/video versions;
- live accompaniment policies;
- interactive installations;
- personalized listening sessions.

The runtime receives state events and renders a valid continuation while preserving identity and rights.

## Hidden truth 17 — The business should monetize finished value, not failed generations

Credit systems optimize revenue around repeated attempts. They may also reward poor first-pass alignment. **INFERENCE:** PlayMusicPrompts should meter expensive compute transparently but organize pricing around projects, private worlds, collaboration, rights and runtime value.

### Product consequence

Recommended product family:

- **Spark** — consumer ideation and finished-song creation.
- **Creator** — Living Score, local edits, stems, MIDI, versions and release package.
- **Studio** — collaboration, true multitrack, private preference memory, plugins and high-end render/eval.
- **Artist/Label** — licensed identity objects, private models, catalogue governance, attribution and royalty reporting.
- **Media/Game** — scene scoring and adaptive runtime SDK.
- **Enterprise/API** — isolated projects, custom evaluators, policy, audit, deployment and SLAs.
- **Marketplace** — voices, instruments, culture grammars, producer worlds and approved model adapters.


## Hidden truth 18 — The real control unit is musical causality, not a parameter

A creator rarely wants “more brass” or “energy = 8” in isolation. They want a perceptual consequence: the chorus should finally release tension, the lyric should feel inevitable, the trailer should reveal scale, or the drop should feel earned. That consequence emerges from interacting causes—register, density, harmonic expectation, rhythmic subdivision, lyric prosody, performance intensity, spectral contrast, dynamics and what came before. Explicit planning, typed editing, producer studies and multi-aspect evaluation all imply that isolated knobs cannot fully represent this causal structure [A01, A06, A23, A25].

### Product consequence

Represent every high-level direction as a `MusicalCausalContract`:

- desired listener effect;
- hypothesized musical causes;
- allowed interventions;
- protected dependencies;
- evidence the change worked;
- alternative causal paths when the first intervention fails.

For “make the chorus hit harder,” the system may propose three causally different plans rather than one generic intensity increase:

1. preserve melody and lyrics; widen register, double harmonic rhythm and delay the bass arrival;
2. preserve arrangement; increase vocal attack, phrase lift and pre-chorus tension;
3. preserve performance; reduce the previous section so the same chorus gains perceptual contrast.

The user chooses the musical logic, not merely a numeric value.

## Hidden truth 19 — The most intelligent generation is sometimes no generation

Current systems spend compute immediately because generation is the product event. But studies identify ambiguity, review burden and intention mismatch as major failures [A05-A07, A19]. **INFERENCE:** a system that renders before it knows what must remain stable converts uncertainty into expensive audio and then makes the user diagnose the mistake.

### Product consequence

Add a `NoRender Preflight` that may:

- resolve a contradictory brief;
- ask one maximum-information question;
- generate a two-bar micro-audition instead of a full song;
- compare three harmonic plans as MIDI/audio sketches;
- explain that a requested lock cannot coexist with the requested transformation;
- refuse an unauthorized identity or reference;
- delay high-cost rendering until the expected value of a candidate crosses a threshold.

This is not friction. It is musical judgment and cost discipline. “Generate” becomes one possible action of the conductor, not its reflex.

## Hidden truth 20 — A song has at least three separable identities

Today, “keep it the same” collapses different layers. A composition can stay identical while the singer, articulation and mix change. A singer can remain identical while melody and lyrics change. A production can preserve its timbral world while the composition changes. Score-native vocal work, multitrack research, licensed voice products and current authorship guidance make these distinctions operationally important [A21, A22, A24, P24, S05].

### Product consequence

Model and lock three identities independently:

- `CompositionIdentity`: form, motif, melody, harmony, lyrics and rhythmic grammar;
- `PerformanceIdentity`: performer/voice, timing, articulation, dynamics, phrasing, improvisation and expressive micro-variation;
- `ProductionIdentity`: instruments/sound design, spatial image, mix relationships, loudness, mastering and texture.

Rights, similarity, versions and edits should attach to the correct identity layer. This allows precise requests such as: “keep the composition and singer, replace only the production world,” or “license this performance identity for one campaign while the composition remains mine.”

## Hidden truth 21 — The Studio must become a causal debugger for music

A single quality score cannot tell a creator why an output failed. Current work increasingly separates song quality into multiple dimensions, learns specialist preference models and diagnoses attribution reliability rather than emitting one opaque judgment [A25, A30, A36, A44].

### Product consequence

Every failed candidate should produce an evidence-backed `Failure Trace`:

- failed requirement;
- measured symptom;
- likely upstream cause;
- confidence and alternative explanations;
- smallest repair transaction;
- collateral-change risk;
- tests that will prove the repair.

Example:

> Lyric intelligibility failed in bars 25–28. The likely cause is not the vocalist identity; it is a four-syllable phrase compressed onto two short notes under a dense cymbal layer. Proposed minimum repair: preserve voice, words, harmony and duration; redistribute the phrase over four notes and attenuate the cymbal stem only during the consonant onsets.

The system should debug the musical system it created instead of asking the human to regenerate blindly.

## Hidden truth 22 — Authorship is a graph of intentional decisions, not an “AI percentage”

Human contribution cannot be represented honestly by a binary label or a guessed percentage. HAIM tracks production roles and segments; agency research shows that selection, interpretation and control materially affect ownership; copyright guidance keeps human authorship fact-specific [A10, A17, A20, S05]. C2PA and DDEX can carry claims and history, but do not decide authorship by themselves [S01-S04].

### Product consequence

The `HumanContributionPassport` should record decision events:

- who originated the brief, melody, lyric, recording or reference;
- who set and defended each lock;
- which model proposed each candidate;
- which human selected, rejected, comped, rewrote or performed;
- which changes were automatic technical corrections;
- which assets and identities were licensed;
- the exact branch and evidence used for release.

The valuable proof is not “63% human.” It is a replayable causal history of human intention and responsibility.

## Hidden truth 23 — Personalization must be user-owned, editable and revocable

Private fine-tuning and sonic-identity services are emerging [P10]. At the same time, preference research and cross-cultural evidence show that one global optimum can flatten difference or misunderstand the language through which people describe music [A11, A12, A14, A31, A37]. **INFERENCE:** a hidden platform profile will eventually become both a creative cage and a trust liability.

### Product consequence

Create a portable `Taste Constitution` controlled by the user:

- positive preferences;
- negative preferences and overused clichés;
- tolerated and forbidden transformations;
- cultural and linguistic context;
- project-specific exceptions;
- confidence and evidence for each learned preference;
- expiry, delete, export and local-only controls.

Every learned preference must be inspectable and reversible. The system should be able to say: “I avoided this cadence because you rejected it in five prior projects; remove that rule?” Personalization becomes creative memory, not invisible behavioral capture.

## Hidden truth 24 — The format and runtime can become a stronger moat than any one checkpoint

Model quality will continue to leapfrog. Platform access and export policy can also change, as Udio's download shutdown and Suno's evolving download policy demonstrate [P07, P39]. Meanwhile MIDI 2.0, ARA and CLAP show the strategic value of open, high-resolution, host-aware interoperability [S10-S12].

### Product consequence

Treat `.pmp`—the PlayMusicPrompts Project—as a public, versioned creative protocol rather than an internal ZIP:

- renderer-independent Music Intent Graph;
- immutable media objects and native/separated origin labels;
- edit transactions, locks, evaluators and version DAG;
- contribution, rights and provenance manifests;
- model adapter contracts;
- DAW/plugin/runtime bindings;
- migration rules and backwards compatibility;
- reference implementation and validation suite.

The user can leave without losing the work. Partners can build renderers, instruments, culture grammars, evaluators and delivery adapters. PlayMusicPrompts remains the best operating environment because it understands the project most deeply—not because it traps the files.

## Hidden truth 25 — The endgame is a self-evolving musical world

A finished stereo file is only one state of music. Live-generation APIs, co-performance research, audiovisual planning and licensed participatory remixing point toward music that persists across contexts and changes while retaining identity [A26, A33, A35, P35, P38].

### Product consequence

A `MusicWorld` should be able to produce:

- album and artist continuity;
- film and character leitmotifs;
- game states and transition-safe adaptive stems;
- live accompaniment that negotiates with a performer;
- fan-authorized covers and remixes;
- localization across language and culture without identity collapse;
- campaign, social, spatial and broadcast variants;
- future renders from better models without losing authorship or history.

The deepest category is therefore not “AI music generation.” It is **persistent computational music**: a musical world with memory, identity, permissions, intelligence and the ability to become a new performance whenever its context changes.

# The product category

## Category name

**PlayMusicPrompts — Living Music Engine**

Alternative explanatory line:

> A Music Intelligence Operating System that turns intention into editable, ownable and living music.

“Prompt” remains the friendly doorway represented by the domain. It should not define the internal architecture.

# The impossible demo

The launch demo should be one uninterrupted creation story:

1. The user speaks: “A Turkish-English cinematic song about rebuilding after loss. Begin almost empty, let the chorus feel inevitable, and never become trailer cliché.”
2. The system asks at most two high-value questions, then shows the Living Score it inferred.
3. The user hums a six-second motif. The system anchors it to the motif graph and generates a full structured project.
4. The Audition Engine produces twelve diverse previews, clusters them into four musical directions and asks two pairwise questions.
5. The system renders the chosen project as native tracks plus a master.
6. The user says: “Make the second chorus twice as powerful. Keep this singer, exact lyrics, vocal melody, drum groove and every sample outside 1:12–1:28. Make brass heroic but not generic.”
7. The Producer shows the typed edit, locks, conflict analysis and eight local alternatives.
8. The user combines the first four bars of Candidate B with the final four of Candidate D.
9. The evaluator proves the outside region is unchanged, reports feature-lock scores and rejects one candidate for lyric degradation.
10. The user changes the project to Turkish makam-aware phrasing; the Culture Grammar updates tuning, ornamentation and prosody without turning the piece into a stereotype.
11. The project branches into radio, acoustic, live, 30-second social, film-cue and adaptive-game versions without losing motif identity.
12. Export delivers the master, true stems, MIDI/score, lyrics and phonemes, open `.pmp` project, C2PA/DDEX metadata, originality report, rights ledger and Human Contribution Passport.

This proves the category through controlled transformation, not through a lucky first generation.

# System architecture

## 1. Multimodal Intent Intake

Inputs: text, conversation, voice direction, humming, singing, MIDI, audio, image, video, script, storyboard, brand brief, game state graph and existing `.pmp` project.

## 2. Intent Compiler

Converts natural language and references into typed graph nodes. Produces ambiguity, conflict and confidence reports. It never silently treats a vague request as an exact musical fact.

## 3. Music World Model

Maintains hierarchical state at universe, album, song, section, phrase, bar, beat, event, track and performance levels. Predicts what should remain invariant and what transformations are musically plausible.

## 4. Constraint and Rights Solver

Checks hard locks, model capability, reference permissions, voice identity, culture-pack rights, similarity thresholds and delivery policy before rendering.

## 5. Planner / Conductor

Chooses among:

- current hybrid full-song routes;
- preview routes;
- symbolic planner/renderers;
- native multistem renderers;
- vocal renderer;
- local inpainting/edit adapters;
- real-time/live route;
- DSP/mix/master stages;
- private/on-device model routes.

Every decision returns route identity and reason.

## 6. Candidate Search

Generates a diversity-controlled candidate set over plan, performance and sound dimensions. Maintains a Pareto frontier and avoids collapsing exploration into one generic optimum.

## 7. PMP-Eval Council

Runs hard gates, diagnostic scores and project-specific preferences. A candidate failing a hard invariant is refused or regenerated.

## 8. Non-destructive Project Graph

Provides branch, commit, merge, compare, comp, revert and provenance. Audio is immutable by default; edits create new assets and graph commits.

## 9. Rights / Contribution / Provenance

Maintains identity objects, consent, training policy, attribution, human contribution, model route, C2PA, DDEX/RIN, similarity and release-readiness evidence.

## 10. Delivery and Runtime

Exports static packages, DAW projects and real-time/adaptive runtime bundles.

# User experience architecture

## Spark

One field: **What should exist?**

Supports typing, speaking, humming and media upload. The system creates the first project, not just a track. It shows three meaningful directions rather than dozens of undifferentiated generations.

## Direct

The core workspace:

- left: AI Producer and project memory;
- center: Living Score with sections, motifs, tracks, lyrics and emotional/narrative overlays;
- right: contextual inspector for the selected object;
- bottom: Audition Deck, comp lane and version graph;
- top: Agency Mode, Intent Integrity, rights state, current branch and render quality.

## Deep

The existing 34-control Studio evolves into the Deep Inspector. It remains available in full, but controls are grouped by selected graph object and their actual binding state is visible.

## Perform

Low-latency accompaniment and steering through voice, instrument, MIDI, gesture or live state.

# Current backend: what stays and what changes

## Preserve

- single conductor endpoint and planner-owned routing;
- model/worker identity and reason returned per call;
- typed/prose/enforced/compiled/refused/response/client-side binding taxonomy;
- source-generated parameter contract;
- measured delivery, refusal paths and capability endpoint;
- current 34 controls as a complete Deep-mode baseline.

## Upgrade first

1. `prompt_enhance` becomes a graph-diff proposer rather than a text rewrite.
2. `arrangement_ai` becomes an implemented suggestion service returning typed applyable diffs.
3. `structure`, `energy_curve`, `mood_orbit` and `controls` become graph fields with evaluator-backed realization.
4. references become rights-aware analysis objects rather than prompt prose.
5. versions become a true branch/commit graph.
6. stems return origin and synchronization evidence.
7. every generation returns `intent_adherence`, `lock_report`, `evaluation_report`, `contribution_passport` and `project_commit`.

# Build sequence

## Phase A — 0 to 90 days: category proof on the existing model

- Music Intent Graph v0.
- Spark / Direct / Deep modes.
- typed `EditTransaction` schema.
- What changes / what remains locked preflight.
- version branches and reversible commits.
- 8-candidate Audition Deck with clustering and pairwise preference.
- exact outside-region preservation for assembly-based edits where technically possible.
- feature-lock measurements for duration, BPM, key, lyrics, vocal identity and waveform locality.
- open project archive v0.
- honest arrangement suggestions as diffs.
- Human Contribution Passport v0.

## Phase B — 3 to 9 months: controllable production moat

- native/conditioned multistem adapter.
- score-native vocal path.
- bar-level comp and merge.
- user preference model with explicit memory controls.
- Artist/Brand World Models trained only from authorized assets.
- originality/similarity review and generative watermark.
- ARA/VST3/CLAP/DAW bridges.
- scene/video scoring and multi-version delivery.
- PMP-Eval benchmark suite and expert panels.

## Phase C — 9 to 18 months: category expansion

- Turkish Culture Grammar as the first deep non-Western system.
- licensed identity marketplace.
- album/universe composer.
- adaptive game/media runtime.
- real-time co-performance.
- private/on-device routes.
- training-data attribution research path.
- open `.pmp` specification and partner SDK.

# North-star metric and guardrails

## North star

**Idea-to-Owned-Release Rate**: the percentage of started ideas that become a creator-approved, editable, provenance-complete, exportable work.

## Supporting metrics

- time to first delight;
- first-generation keep rate;
- local-edit success rate;
- hard-lock violation rate;
- candidate audition-to-commit time;
- meaningful human decisions per completed project;
- branch/revert recovery rate;
- project export and DAW transfer rate;
- return-to-project rate;
- private identity continuity;
- cultural-expert pass rate;
- provenance completeness;
- release rejection or rights-incident rate.

## Anti-metrics

Do not optimize for raw number of songs, prompts or generations. Streaming platforms are strengthening spam and impersonation controls; quantity without ownership or intent can become liability rather than value [S08].

# ADOPT / BUILD / AVOID

## ADOPT

- hierarchical plans and layouts;
- persistent conversational project state;
- typed local edits and explicit masks;
- native track generation and score-native vocals;
- preference learning from pairwise choices;
- multi-dimensional evaluation;
- C2PA/DDEX/RIN-compatible provenance;
- modern interoperability standards;
- licensed and culturally governed personalization.

## BUILD

- Living Score / Music Intent Graph;
- Edit Transaction compiler;
- Conservation Locks;
- Audition Intelligence;
- PMP-Eval Council;
- Human Contribution Passport;
- Artist/Culture World Models;
- open `.pmp` project format;
- adaptive Music Runtime.

## AVOID

- adding more permanent sliders to the current screen;
- a generic DAW clone;
- chat that only rewrites prompts;
- accepted-but-ignored controls;
- a single fake quality or hit score;
- source-separated stems presented as native tracks;
- named-artist imitation without explicit licensed identity;
- cultural labels without executable musical grammar;
- platform lock-in and disappearing exports;
- generation-count growth loops that encourage spam;
- rights badges that imply copyright certainty.

# Contradictions, uncertainty and known limits

- Exact preservation is technically demonstrated by MusicWeaver's approach, but integrating an equivalent guarantee into the current deployed route is an engineering task, not a proven current capability [A01].
- Public product documentation does not reveal full training data, model internals or production reliability. Vendor feature claims are dated single-authority facts.
- Native stems, score-native vocals and live generation are active research/product directions; no single public model proves all desired qualities simultaneously.
- Copyright and authorship remain jurisdiction- and fact-specific. Provenance supports evidence; it is not a warranty.
- Training-data attribution, watermarking and similarity analysis remain imperfect and should be presented as evidence, not legal clearance [A29, A30].
- Cultural fidelity requires expert governance and evaluation; a dataset or fine-tune alone is insufficient [A31, A32].

# Committed recommendation

Do not rebuild the current screen as a larger form. Keep it as **Deep mode**, then place a new product layer above the existing backend:

1. persistent Music Intent Graph;
2. typed, reversible Edit Transactions;
3. executable Conservation Locks;
4. intelligent candidate audition and comping;
5. project-level evaluation, rights and provenance;
6. open portability;
7. later, native stems, culture grammars and adaptive runtime.

That combination is not present as one coherent product in the reviewed frontier. Its individual building blocks are now credible enough to engineer. The “impossible” is not one magic model; it is the disciplined integration of representation, control, evaluation, agency, rights and runtime into a music system that never forgets what the human meant.

# Artifact index

See `README.md` for the complete produced bundle, `architecture/2026-08-18-playmusicprompts-vnext-capability-matrix-and-schema.md` for the technical object/API design, and `_ledgers/` for claim and contradiction tracking.
