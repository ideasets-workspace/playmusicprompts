# Standards ledger

- Scope: provider APIs, open interoperability surfaces and the vNext PlayMusicPrompts service contract.
- Current project facts derive from the generated `generate-music-hybrid-model` contract supplied by Berk.
- Current provider facts derive from official API/product documentation [P09-P11, P13-P15, P20, P35-P37, S10-S12].
- Proposed endpoints and schemas are architecture recommendations, not claims about deployed behavior.
- Every provider is treated as a dated, replaceable adapter. Provider field availability must be runtime-discovered and reported.

# Outcome first

Do not keep expanding `POST /generate-music-hybrid-model` into a universal mega-request. Preserve it as a **render adapter/conductor**, then add a project API whose source of truth is the persistent Music Intent Graph. Natural-language commands should compile into typed, inspectable transactions before any expensive generation call.

The public product API should expose stable music-domain objects; provider-specific fields remain behind an adapter registry. That design lets PlayMusicPrompts adopt a future superior model without breaking projects, clients, evaluation or rights history.

# Current deployed contract — preserved baseline

## Endpoint

`POST /generate-music-hybrid-model`

## Current responsibilities

1. validate against the generated parameter specification;
2. plan route and compile the Lyria prompt;
3. return a per-control binding report;
4. delegate to the deployed Lyria worker;
5. measure the returned asset;
6. return a render plan for conform, master, stems and lyric verification.

## Current planner routes

- `auto`;
- `lyria-3-clip-preview`;
- `lyria-3-pro-preview`;
- `lyria-002`.

The response returns actual model/worker/delegate identity and `route.why`. This behavior must survive every vNext layer.

## Existing binding classes

- `typed`;
- `prose`;
- `enforced`;
- `compiled`;
- `refused`;
- `response_field`;
- `client_side`.

This taxonomy should become a universal capability contract. Add `measured`, `inferred_unverified`, `requested_unavailable` and `degraded_with_consent` only if their semantics are equally explicit.

# Provider/API landscape

| Provider / standard | Documented input/output surface | Best use in PlayMusicPrompts | Material limit / risk |
|---|---|---|---|
| Google Lyria 3 / Pro Interactions API | Text/image to 44.1 kHz stereo music; clip and full-song family; vocals/lyrics/structure on current routes | Default high-quality preview/full render adapter | Model fields and preview status can change; no public native-stem guarantee [P13-P16, P36]. |
| Google Lyria RealTime | Persistent bidirectional interactive generation/steering | `Perform` mode and adaptive prototype | Instrumental/live semantics differ from offline song generation; state and reconnect policy must be ours [P35]. |
| Eleven Music API | Text-to-music, streaming, timestamps, commercial licensing; current docs describe section/edit/reference/stem capabilities | Alternate song/vocal route, enterprise inpainting and streaming | $0.15/minute, five-minute API limit; provider-specific rights and reference screening [P08-P11]. |
| Stable Audio 3 API / open weights | Long variable-duration generation, continuation/inpainting, open Small/Medium, managed Large, LoRA | Private/on-device route, local editing experiments, enterprise custom model | Open-license and enterprise conditions; public docs do not prove every vocal/lyric requirement [P20]. |
| Mubert API | Text/image music and adaptive/streaming use cases | Long-running adaptive background music | Vendor claims on latency/duration remain single-source; song-production depth differs [P37]. |
| Meta AudioCraft / MusicGen | Research code for text/melody-conditioned audio | Research baseline, embeddings and controlled experiments | Research maturity/license/maintenance; not a production SLA [P21, P22]. |
| MIDI 2.0 | UMP, Profiles, 16-bit velocity, 32-bit controllers/pitch, per-note controls | High-resolution performance and open symbolic exchange | Host/device adoption is uneven; preserve fallback to MIDI 1/SMF [S10]. |
| ARA | Deep non-real-time audio access between host and plug-in | DAW round-trip, region/audio analysis/edit integration | Implement against tagged public releases; host-specific engineering [S11]. |
| CLAP | Modern plug-in/host API with per-note and non-destructive modulation | Instrument/effect integration and expressive automation | Ecosystem adoption is growing but not universal [S12]. |

# Architectural law — domain API outside, provider API inside

## Public objects

- `MusicProject`;
- `MusicIntentGraph`;
- `MusicWorld`;
- `Motif`;
- `Section`;
- `Track`;
- `VocalScore`;
- `IdentityObject`;
- `CultureGrammar`;
- `EditTransaction`;
- `CandidateSet`;
- `EvaluationReport`;
- `ContributionPassport`;
- `RightsLedger`;
- `DeliveryPackage`;
- `RuntimeSession`.

## Internal adapter objects

- `ProviderCapabilitySnapshot`;
- `ProviderRoutePlan`;
- `CompiledProviderRequest`;
- `ProviderResponseEvidence`;
- `BindingReport`;
- `CostEstimate`;
- `FallbackDecision`.

A public client asks to change a chorus, not to set a vendor's undocumented internal knob.

# Proposed vNext HTTP surface

## Projects

### `POST /v1/music-projects`

Creates an empty or intent-seeded project.

```json
{
  "name": "Rebuild After Loss",
  "agency_mode": "co_create",
  "intent": {
    "text": "A Turkish-English cinematic song about rebuilding after loss",
    "negative_space": ["trailer cliché", "generic empowerment lyric"]
  },
  "inputs": [
    {"kind": "hum", "asset_id": "asset_hum_01"},
    {"kind": "script", "asset_id": "asset_script_01"}
  ],
  "privacy": {"training_opt_in": false, "retention": "project_lifetime"}
}
```

### `GET /v1/music-projects/{project_id}`

Returns project metadata, active branch, graph version, rights blockers and latest evaluation—not every large media asset inline.

### `POST /v1/music-projects/{project_id}:compile-intent`

Compiles multimodal input into a proposed graph diff. It must not auto-commit ambiguous high-impact decisions.

Response includes:

- `understood`;
- `ambiguities`;
- `clarification_questions` with expected information gain;
- `proposed_graph_patch`;
- `unsupported_or_unverified`;
- `estimated_render_plan`.

## Transactions

### `POST /v1/music-projects/{project_id}/transactions:plan`

```json
{
  "selection": {
    "bars": {"start": 33, "end": 40},
    "section_ids": ["chorus_2"],
    "track_ids": ["brass", "strings"]
  },
  "instruction": "Make this chorus twice as powerful without becoming generic",
  "operations": ["re_orchestrate", "increase_energy"],
  "hard_locks": [
    {"type": "exact_audio_outside_selection"},
    {"type": "lyrics_exact", "target": "vocal_main"},
    {"type": "melody_feature", "target": "vocal_main", "threshold": 0.98},
    {"type": "groove_feature", "target": "drums", "threshold": 0.96}
  ],
  "soft_locks": [
    {"type": "vocal_identity", "target": "voice_01", "threshold": 0.92}
  ],
  "surprise_budget": {
    "harmony": 0.15,
    "orchestration": 0.55,
    "rhythm": 0.10,
    "sound_design": 0.35
  }
}
```

Response must show:

- `what_i_understood`;
- `what_will_change`;
- `what_remains_locked`;
- `conflicts`;
- `binding_plan`;
- `route_candidates`;
- `evaluation_plan`;
- `cost_range`;
- `transaction_id`.

### `POST /v1/music-projects/{project_id}/transactions/{transaction_id}:audition`

Creates a diversity-controlled candidate set without committing it.

```json
{
  "candidate_policy": {
    "preview_count": 12,
    "cluster_target": 4,
    "max_near_duplicate_rate": 0.15,
    "quality": "preview"
  },
  "preference_mode": "active_pairwise"
}
```

### `POST /v1/music-projects/{project_id}/transactions/{transaction_id}:commit`

Commits a candidate or a comp recipe only after hard gates pass.

### `POST /v1/music-projects/{project_id}/transactions/{transaction_id}:reject`

Stores rejection reason only with explicit user permission for preference learning.

## Versions and branches

- `POST /v1/music-projects/{id}/branches`;
- `GET /v1/music-projects/{id}/commits`;
- `POST /v1/music-projects/{id}/merge:plan`;
- `POST /v1/music-projects/{id}/merge:commit`;
- `POST /v1/music-projects/{id}/commits/{commit}:restore`.

A merge can conflict on audio, graph meaning, identity rights or contribution provenance. Each conflict type is explicit.

## Evaluation

### `POST /v1/music-projects/{id}:evaluate`

```json
{
  "scope": {"commit_id": "commit_0042"},
  "profiles": ["hard_locks", "song_quality", "lyrics_tr", "streaming_master", "culture_tr_makam"],
  "human_panels": ["owner", "culture_expert"]
}
```

Returns hard-pass state, per-axis metrics, estimator identity/version, confidence, evidence locators and `NOT_RUN` where no valid estimator exists.

## Delivery

### `POST /v1/music-projects/{id}:deliver`

Delivery target examples:

- `master_streaming`;
- `master_cinematic`;
- `stems_open`;
- `midi2_score_bundle`;
- `social_15_30_60`;
- `film_cue_package`;
- `game_runtime_package`;
- `pmp_open_project`;
- `release_readiness`.

## Capabilities

### `GET /v1/music-capabilities`

Returns the union of product capabilities, current provider routes, binding classes, cost classes, supported languages/cultures and degradation policies. The response is versioned and signed.

### `GET /v1/music-capabilities/providers/{provider}`

Returns current provider-specific snapshot and last probe evidence. Clients should rarely need this endpoint.

# Proposed real-time surface

## `WSS /v1/music-projects/{id}/live-sessions/{session_id}`

Message classes:

- `session.configure`;
- `performance.audio_chunk`;
- `performance.midi_ump`;
- `direction.update`;
- `role.change`;
- `state.snapshot`;
- `render.chunk`;
- `latency.report`;
- `capture.to_project`;
- `session.end`.

Each session declares:

- input/output codecs;
- target round-trip latency;
- model look-ahead;
- leadership role;
- allowed harmonic/rhythmic drift;
- content/identity permissions;
- reconnect and state-replay policy.

# Provider capability registry

Every provider route should be probed and stored as:

```json
{
  "provider": "google",
  "model": "lyria-3-pro-preview",
  "snapshot_at": "2026-08-18T00:00:00Z",
  "inputs": ["text", "image"],
  "outputs": ["mixed_audio"],
  "limits": {"duration_seconds_max": 184},
  "bindings": {
    "prompt": "typed",
    "duration": "typed_or_enforced_by_route_probe",
    "sections": "prose_or_typed_by_probe",
    "seed": "unsupported_or_route_specific"
  },
  "probe_evidence": ["probe_id_..."],
  "pricing": {"unit": "count", "usd": 0.08, "as_of": "2026-08-18"},
  "deprecation": null
}
```

Never infer a field because a UI displays it. A route becomes `typed` only after official contract or measured request/response evidence.

# Error and refusal contract

Use stable product errors:

- `INVALID_PROJECT_STATE`;
- `AMBIGUOUS_INTENT_REQUIRES_CLARIFICATION`;
- `HARD_LOCK_CONFLICT`;
- `RIGHTS_PERMISSION_MISSING`;
- `IDENTITY_USE_REFUSED`;
- `REFERENCE_NOT_OWNED_OR_LICENSED`;
- `CULTURE_GRAMMAR_UNAVAILABLE`;
- `PROVIDER_CAPABILITY_CHANGED`;
- `PROVIDER_ROUTE_UNAVAILABLE`;
- `EVALUATION_GATE_FAILED`;
- `COST_APPROVAL_REQUIRED`;
- `DELIVERY_TARGET_UNSUPPORTED`;
- `PROJECT_VERSION_CONFLICT`.

A provider error is attached as evidence but never becomes the public API's only semantics.

# Idempotency, audit and security

- Require `Idempotency-Key` for every write/render.
- Content-address all immutable assets.
- Encrypt private voices, identity embeddings and reference assets separately.
- Default private project data to no-training; opt-in must be granular and revocable.
- Record provider, model, region, request hash, binding report, costs, outputs and evaluator versions per commit.
- Webhooks are signed and replay-protected.
- URLs are short-lived; rights metadata and hashes remain durable.
- Separate deletion of media, preference model and identity model.
- Store consent versions and revocation effects.

# Migration from the current endpoint

## Phase 1

Wrap current request/response in `RenderAdapterRequest` and preserve all 34 parameters. Create `MusicProject` and one graph commit around each existing job.

## Phase 2

Compile `structure`, `energy_curve`, `mood_orbit`, lyrics and references from graph nodes into the current endpoint. Return graph realization and evaluation reports.

## Phase 3

Add transaction planning, local adapters and candidate audition. The current endpoint remains one rendering route.

## Phase 4

Add native multitrack, score-native vocal and real-time adapters. No public client migration is required because the domain API stays stable.

# One committed API decision

The next backend milestone should be **`MusicProject + EditTransaction + EvaluationReport`**, not more fields on the generation request. This creates the stable control plane that can make the already-built hybrid renderer dramatically more valuable.
