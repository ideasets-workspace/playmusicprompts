# Standards ledger

- Governed by the owner covenant and the source register. This artifact covers frontier knowledge, algorithms, academic primaries, open models, exact limits, contradictory evidence, and application to PlayMusicPrompts.
- Source IDs refer to `_sources/2026-08-18-playmusicprompts-source-register.md`.
- The committed design does not assume that a vendor marketing claim is a scientifically proven control. Technical claims below are limited to opened papers or official model documentation.

# Outcome first

The scientific frontier is moving from **one-shot waveform generation** toward **planned, editable, persistent musical objects**. The strongest architecture for PlayMusicPrompts is therefore not “one bigger prompt into one model.” It is a hybrid system in which an intent/planning model compiles a persistent, human-readable **Music Intent Graph**, specialist renderers generate or revise only the required regions/layers, and evaluators verify preservation, structure, lyrics, musical constraints, provenance, and user preference.

The central unsolved product problem is **revision without destruction**: users must be able to keep the singer, melody, lyrics, groove, mix, or exact audio they love while changing only a named span or attribute. MusicWeaver demonstrates the architectural direction—typed plan operations plus exact preservation outside an edited region—while SegTune, MusiChat, ACE-Step, Stable Audio, Eleven Music and user studies independently support segment-level planning, persistent state, personalization and local iteration. [A01, A02, A03, A08, P08, P20]

# Frontier capability map

| Capability | Current frontier | Remaining gap | PlayMusicPrompts decision |
|---|---|---|---|
| Long-form structure | Section-conditioned generation; up to ~3–6+ minutes in leading systems; explicit plans in research | Motif/identity drift, weak causal form, opaque transitions | Store a persistent section/motif graph independent of any renderer |
| Exact local editing | Inpainting/section editing exists; MusicWeaver proves outside-mask preservation by construction | Most products do not expose preservation guarantees or constraint conflicts | “Conservation Locks” + diff preview + measured locality score |
| Global + local control | SegTune injects segment prompts into corresponding windows; commercial tools expose section prompts | Global coherence can collapse after repeated local revisions | Hierarchical global song identity + local section directives + regression tests |
| Personalization | User-owned LoRA/finetunes and voice models are emerging | Opaque memory, consent, overfitting, identity drift | Editable, permissioned Artist DNA with source-level provenance and revocation |
| Lyrics/vocals | Multilingual vocals, time-aligned lyrics, singing synthesis from MIDI/lyrics | Pronunciation, prosody, language coverage, vocal consistency, consent | Phoneme/prosody plan, pronunciation dictionary, voice consent token, PER gate |
| Multitrack/stems | Stem generation/separation and MIDI workflows are table stakes | Cross-stem phase/coherence, edit propagation, true generative stems | Track Agents coordinated by a conductor; each stem has role/constraints/origin |
| Preference alignment | RLHF/preference optimization and user reranking are active research | One average preference collapses diversity and culture | Per-user/per-project preference memory plus Pareto/diversity search, not one scalar “best” |
| Live co-performance | Lyria RealTime and 184-system research landscape demonstrate direction | Latency, anticipation, communication semantics, rights | Future real-time agent built around musical communication states, not static sliders |
| Evaluation | Prompt similarity, lyric alignment, quality and structural metrics exist | Metrics poorly match subjective intent; cultural and edit-locality evals remain weak | Product eval stack combines measured constraints, listener preference, preservation and calibrated uncertainty |

# Five-part academic and technical depth records

## A01 — MusicWeaver: programmable long-form generation and provably local editing

1. **Problem in the authors’ framing.** Text-to-music systems can generate audio but do not offer composer-style, repeated structural edits with a guarantee that unchanged content will remain unchanged.
2. **Method.** A multimodal prompt is compiled into a human-interpretable song program. Editing is formalized as typed operations over the plan—replace, insert, delete, motif retag and attribute change. Projected Diffusion Inpainting reprojects original latent content outside the affected footprint at every denoising step; the preservation property is therefore part of the sampler rather than a learned tendency.
3. **Numbers/evidence.** The paper reports minute-scale rendering and an exact-by-construction guarantee for content outside the dilated edit mask across arbitrarily many revisions. The load-bearing result here is the guarantee itself, not a marketing listening score.
4. **Limitations.** A guarantee outside a mask does not guarantee that the edited region is musically excellent, that boundary transitions are artifact-free, or that the induced plan captures every human intention. Public research status and production latency remain relevant.
5. **Application here.** Make every edit a typed operation against the Music Intent Graph. Require `change_mask`, `preserve_mask`, `lock_set`, `expected_diff`, `measured_locality`, and an audio regression check. Never represent “change only the chorus” as unstructured prose alone.

## A02 — SegTune: global plus segment-level song control

1. **Problem.** Global prompts inadequately represent temporal dynamics—emotion, rhythm, instrumentation and vocal attributes change across sections.
2. **Method.** A global prompt conditions the whole track while segment-level prompts are injected into their corresponding temporal windows. A fine-tuned language model predicts LRC-style sentence durations to align lyrics and segment boundaries.
3. **Numbers/evidence.** The backbone is approximately 1.1B parameters with 16 LLaMA-style decoder blocks. Its in-house training set is more than 90% Mandarin pop. It introduces segment-level MuLan similarity and singer-attribute-following measures.
4. **Limitations.** Heavy Mandarin-pop concentration limits generalization; learned duration predictions are not exact user guarantees; local prompt adherence can conflict with global identity.
5. **Application here.** Compile the existing Structure Builder and Energy Curve into per-section objects with explicit start/bar ranges, local mood/instrument/vocal directives and a separate global identity contract. Store predicted and user-locked timings separately.

## A03 — ACE-Step 1.5: planner-renderer separation, efficient local models and personalization

1. **Problem.** Open music systems often trade professional control and long-form capability for hardware accessibility.
2. **Method.** A language model acts as a planner that expands simple intent into a song blueprint; a diffusion transformer renders the audio. Progressive training, multi-task learning, preference optimization and distillation compress generation to few steps. LoRA personalization can be trained from a small personal corpus.
3. **Numbers/evidence.** The paper reports local operation below 4 GB VRAM, 4–8-step distilled generation, an initial 20M-sample pretraining stage and blueprints ranging to ten-minute compositions.
4. **Limitations.** The authors explicitly cite acoustic richness, language/style breadth and world knowledge as still constrained by consumer-scale parameter limits. Fast generation does not establish professional mix fidelity or rights provenance.
5. **Application here.** Preserve the current hybrid conductor but formalize the planner output as a renderer-independent contract. Add an optional private/local route for previews, user-owned LoRA training and enterprise isolation; reserve high-cost renderers for selected candidates.

## A04 — DiffRhythm 2: efficient long-form song generation and preference optimization

1. **Problem.** Autoregressive systems accumulate long-range errors; parallel vocal/accompaniment systems can produce harmonic inconsistency; preference alignment across multiple objectives can degrade after model merging.
2. **Method.** Block flow matching generates semi-autoregressively with bidirectional context within blocks. Stochastic block representation alignment supports training, while cross-pair preference optimization addresses multiple preference groups.
3. **Numbers/evidence.** The system reports full songs up to 210 seconds and releases inference code/checkpoints.
4. **Limitations.** The paper states that the low-frame-rate VAE caps reconstruction fidelity and that improving vocal modeling without reducing creativity remains difficult.
5. **Application here.** Do not collapse quality to one score. Maintain separate preference axes—musicality, lyric fidelity, vocal realism, novelty, cultural fit, edit locality—and select from a Pareto set. Treat codec/VAE artifacts as an explicit evaluator gate.

## A05 — Practising musicians co-design study

1. **Problem.** Music AI is often designed around technical novelty rather than how practising musicians retain ownership and integrate tools into real workflows.
2. **Method.** Two co-design workshops with practising musicians informed a variation tool, followed by a two-week ecological study in participants’ own environments.
3. **Numbers/evidence.** N=13. The resulting design added control over the level and type of variation, specific-bar selection and bar-level masking. Participants described filtering/refining as supporting ownership of the process.
4. **Limitations.** Small sample, difficulty recruiting practising professionals and an approximately 15-bar input guideline limit broad generalization.
5. **Application here.** Add a global and per-operation **Control ↔ Surprise** dial, bar/section selection, and explicit variation dimensions. Measure whether users initiate and refine rather than merely select whole songs.

## A06 — Text-to-music producer study

1. **Problem.** Generated material can inspire but often fails to align with a producer’s intended project or integrate with existing music.
2. **Method.** Seventeen producers used a text-to-music interface plus source separation and discussed their workflow through semi-structured interviews.
3. **Numbers/evidence.** N=17. Reported needs include exact BPM, key, beat/loop duration, multimodal prompting, iterative regeneration, richer editing and DAW integration.
4. **Limitations.** Qualitative sample and prototype context; findings identify patterns rather than population-wide effect sizes.
5. **Application here.** Make BPM/key/meter/duration measurable gates, not only prose. Support MIDI/audio/hum reference inputs, open stem/MIDI export, and region-level regeneration that preserves human material.

## A07 — VidTune: generation-review bottleneck

1. **Problem.** Once many tracks can be generated quickly, users struggle to construct diverse prompts, review options and judge music in video context. Sequential listening becomes the bottleneck.
2. **Method.** Video analysis expands prompts; contextual thumbnails and iterative refinement help users compare soundtrack candidates. The program includes formative, controlled and exploratory studies.
3. **Numbers/evidence.** Formative N=8, evaluation N=12, exploratory N=6; 22 participant records are reported across cohorts. Participants identified reviewing as a bottleneck and contextual representations reduced tedium.
4. **Limitations.** Visual proxies sometimes contradict titles, vary by culture and individual, and can bias users toward what looks right. They must augment rather than replace listening.
5. **Application here.** Build an **Audition Matrix**: clustered candidates, concise sonic/narrative descriptors, timeline fit, highlighted differences, instant A/B and bar-level comping. The dominant action remains listening; visualizations are optional.

## A08 — MusiChat: persistent conversation and hierarchical representation

1. **Problem.** Multi-turn prompt/regenerate loops lose state or force users to export to another tool for precise edits.
2. **Method.** A memory-augmented language model maintains active composition state and history. A hierarchical symbolic engine separates a stable lyric-aligned skeleton from expressive surface realization.
3. **Numbers/evidence.** The prototype reports 95.31% single-turn and 100% multi-turn feature-edit accuracy on its test set, plus a 35-person listening study. These numbers are prototype-specific and not assumed to transfer to audio generation.
4. **Limitations.** The evaluation covers bounded musical attributes and a hybrid symbolic engine, not all professional audio edits or long-form vocal production.
5. **Application here.** Conversation must mutate a persistent project graph rather than rewrite a prompt. Each command shows the state diff, affected nodes, inherited constraints and version branch.

## A14 — Cross-cultural prompting and describing

1. **Problem.** Text-conditioned music interfaces assume that users describe musical intent in the same vocabulary across cultures and that prompt language matches how people perceive music.
2. **Method.** Human coding, lexical analysis and semantic similarity compare real-world prompts with listening descriptions in English and Korean cohorts.
3. **Numbers/evidence.** 148 included participants produced 2,624 descriptions across 200 stimuli. Genre accounts for 38.8% of prompt vocabulary but 15.2% of descriptive vocabulary; listeners rely more on affective, narrative and functional language.
4. **Limitations.** Recruitment channels differ between language groups and the comparison covers English/Korean rather than the global universe.
5. **Application here.** The Intent Compiler must accept narrative, purpose, scene, bodily feeling, social setting and culture-specific concepts—not force users into Western genre tags. Build culturally governed music ontologies and local expert evaluation.

## A17 — Automation, psychological ownership and agency

1. **Problem.** High automation may reduce effort while also weakening the creator’s felt control and ownership.
2. **Method.** A 3×2 between-subjects experiment manipulated AI automation level and musical expertise, measuring task load, psychological ownership and state sense of agency.
3. **Numbers/evidence.** Final N=162. Agency fell as automation increased; the main effect on state agency was significant, F(2,156)=31.84, p<.001, partial η²=.29. The decline was more pronounced for experts.
4. **Limitations.** University sample aged 18–24, standardized tasks and self-report measures limit transfer to professional longitudinal practice.
5. **Application here.** One-click creation is an entry mode, not the entire product. Preserve meaningful choices, visible causality and contribution history. Let experts choose low-automation/direct-control modes while novices can delegate more.

## A18 — Professional workflow: speed versus control

1. **Problem.** Professional adoption depends on workflow speed, correct control depth, comfort and sound—not novelty alone.
2. **Method.** Ethnographic observation/interviews with portfolio professionals working across production, engineering and mixing.
3. **Numbers/evidence.** Five professionals; three observed for approximately two hours and two interviewed remotely. All prioritized efficient experience, appropriate control and sound; they favored automation for menial/session-prep tasks.
4. **Limitations.** Small professional sample; tools studied are broader than generative music; qualitative findings are directional.
5. **Application here.** Automate file preparation, routing, cleanup, alignment, stem labeling, versions, exports and technical QC. Do not automate away artistic decisions by default. Contextual controls beat a permanently visible wall of parameters.

## A19 — Ten-week novice co-creation study

1. **Problem.** Lowering generation barriers creates a new burden: selecting, validating and integrating large numbers of disconnected outputs.
2. **Method.** Nine students worked in groups for ten weeks to create and release three tracks, using multiple AI tools across ideation, music, lyrics, art and distribution.
3. **Numbers/evidence.** Teams sometimes generated 10–20 options per person or used a system roughly 50 times before choosing a melody. The authors identify a new collaging-and-refinement stage.
4. **Limitations.** Small course-based sample, deadlines and newly formed teams differ from professional production.
5. **Application here.** The studio must be a coherent project environment, not a generation gallery. Provide candidate clustering, comping, key/tempo reconciliation, asset lineage and cross-tool import.

# Algorithms and system design lineage

## 1. Persistent planning beats prompt concatenation

A project should be represented as a typed graph with global identity, sections, motifs, lyrics/prosody, harmony, rhythm, instruments, voices, mix, media events, rights and evaluation targets. Natural language becomes a compiler input; it is not the source of truth. [A01, A02, A08]

## 2. Local editing requires explicit masks and invariants

An edit operation needs:

- selected time/bars/stems;
- semantic target;
- hard preserve set;
- soft preserve set;
- permissible variation budget;
- boundary context;
- candidate count;
- evaluator thresholds;
- measured change and locality report.

The product should distinguish **exact audio preservation**, **feature preservation** (melody/key/groove/voice) and **semantic similarity**. These are not interchangeable.

## 3. Candidate search is a multi-objective optimization problem

A single hidden reward risks producing average, homogenized outputs. Candidate selection should optimize a vector such as:

`[intent_adherence, musicality, structural_coherence, lyric_accuracy, vocal_identity, edit_locality, audio_quality, novelty, cultural_fidelity, media_fit, user_preference]`

Use diversity-preserving search and present a Pareto set. A user can favor fidelity, surprise or novelty per project. [A04, A05, A11, A12]

## 4. Evaluation must become a product surface

The evaluator stack should include measured BPM/key/meter/duration; section and event alignment; lyric phoneme error rate; vocal identity consistency; spectral/artifact quality; stem leakage; loudness/true peak; local-edit preservation; motif recurrence; cultural-expert tests; reference similarity boundaries; and calibrated user preference. A number is shown only when its estimator and confidence pass.

## 5. Global music requires plural musical grammars

Western twelve-tone/key/meter controls are a subset. The schema must support tuning systems, pitch collections, ornamentation, rhythm cycles, culturally specific form, instrument technique and language prosody. Culture packs should be co-built with musicians and scholars, versioned and compensated, not generated from a label alone. [A14, A11]

# Open problems at the frontier

1. **Musical causality and long-range form.** Models can imitate sections yet often lack a persistent reason for recurrence, development and release.
2. **True multitrack generation.** Separated stems are not equivalent to independently editable, phase-coherent, causally coordinated tracks.
3. **Guaranteed semantic preservation.** Exact outside-mask preservation is possible; preserving “same singer,” “same groove,” or “same emotional identity” under local edits remains imperfect.
4. **Lyrics and vocal identity.** Pronunciation, prosody, breath, timbre continuity, expressive control and consent must all hold simultaneously.
5. **Preference without homogenization.** Personalization can overfit and global RLHF can collapse minority aesthetics.
6. **Cultural validity.** Automatic metrics rarely capture culturally situated form, performance practice or meaning.
7. **Attribution and human authorship.** Provenance can record actions, but legal authorship remains jurisdiction- and fact-specific.
8. **Real-time musical communication.** Low latency alone does not create a musical partner; systems need anticipation, turn-taking, leadership/following and communicative intent.
9. **Reliable success prediction.** “Hit probability” remains vulnerable to leakage, distribution shift and self-fulfilling optimization; any commercial forecast must be calibrated and separated from artistic quality.

# Synthesis — ADOPT / BUILD / AVOID

## ADOPT

- Hierarchical planning and segment-level conditioning.
- Typed local edits, masks and preservation constraints.
- Multi-turn memory that mutates persistent state.
- Private personalization from owned/consented material.
- Low-cost preview → evaluator/rerank → selected ultra render.
- Open stems/MIDI/project export and DAW interoperability.

## BUILD

- Music Intent Graph / Living Score.
- Conservation Locks and an edit-locality evaluator.
- Audition Matrix and bar-level comping.
- Cultural music grammar and expert evaluation framework.
- Human Contribution Passport with role/segment lineage.
- User-specific preference model with explicit memory controls and diversity preservation.

## AVOID

- Treating a longer prompt as a control system.
- A single “quality” score or false hit probability.
- Named-artist imitation without a licensed identity object.
- Replacing all human effort; high automation can erode ownership and expert agency.
- Showing unmeasured controls or claiming deterministic seed reproducibility when not proven.
- Building a generic DAW clone: by August 2026 generative DAWs already include MIDI, effects, chat and section generation.

# Committed scientific recommendation

Build **PlayMusicPrompts Music OS** around a renderer-independent **Music Intent Graph** and a non-destructive **semantic edit engine**. The current hybrid model becomes one set of render adapters inside that system. The first signature capability should be:

> Select any moment or track, describe the change, lock everything that must survive, preview the exact graph/audio diff, audition diverse alternatives, and commit only the chosen bars—without losing the rest of the song.

That capability attacks the deepest repeated failure across research and products: generation is abundant; trustworthy, intention-preserving revision is scarce.


# Second frontier sweep — hidden technical edges

## Native tracks require a shared clock, not post-hoc separation

Three independent lines now converge. SketchSong creates explicit vocal, bass, drum and other tracks from a structural sketch [A21]. Stemphonic shares an initial noise latent across a variable set of stems and reports 25–50% faster full-mix generation than sequential baselines while retaining stem-wise activity control [A22]. SyncTrack separates track-shared rhythm modules from track-specific timbre modules and introduces IRS, CBS and CBD to measure stability and synchronization [A28].

**Applied conclusion:** the long-term renderer should make `musical_clock`, `shared_context`, `track_role`, `activity_envelope` and `cross_track_constraints` first-class. Source separation stays useful, but it must be labeled `separated_from_mix`, never silently presented as a native track.

## Representation determines whether editing is possible

BeatEdit shows that edit-based methods impose structural requirements on the representation itself and reports nearly twice the exact-match correction of its strongest generative baseline on 192K piano pieces with single-pass inference below 100 ms [A27]. DuoTok similarly treats source-aware, time-aligned vocal/accompaniment tokenization as an interface for multi-track modeling [A48].

**Applied conclusion:** PlayMusicPrompts cannot bolt exact editing onto an arbitrary waveform-only model. The `MusicIntentGraph`, tokenization, stem clock, edit mask and evaluator must be co-designed.

## One quality score is scientifically indefensible

SongBench separates vocal, instrument, melody, structure, arrangement, mixing and musicality [A25]. CMI-RM uses more than 110,000 pseudo-labelled preference pairs plus 4,000 expert comparisons and reports that specialist music evaluators outperform general multimodal systems on nuanced judgments [A36]. MusicRL's 300,000 pairwise preferences show that text adherence and generic audio quality explain only part of what listeners prefer [A37]. MuQ-Eval adds a public per-sample metric but remains one measurement channel rather than a total musical verdict [A44].

**Applied conclusion:** expose a vector and hard gates. The product may summarize, but it must never hide irreversible decisions behind `quality: 92`.

## Cultural depth begins below the prompt layer

`Music for All` reports that only 5.7% of surveyed music-dataset hours represent non-Western genres and that small-data adaptation to Hindustani and Turkish makam remains non-trivial [A31]. Cross-cultural prompting research shows that users' generation prompts and listening descriptions use different vocabularies across cohorts [A14]. MazzikaAI and cross-cultural audio-front-end work further indicate that microtonal modal practice and even common mel representations require domain-specific treatment [A42, A43].

**Applied conclusion:** a Culture Grammar must control tuning, pitch trajectories, resting tones, seyir, usul, ornamentation, instrument technique, language prosody and evaluation. A genre chip is not cultural support.

## Watermarking, provenance and attribution solve different problems

MusicMark embeds a generative watermark and evaluates 20 attacks, including cover-song transformations [A29]. Aria decomposes training-data attribution by musical aspect and adds reliability diagnostics [A30]. C2PA records signed provenance and edits [S01-S03]. None of these systems by itself establishes ownership, non-infringement or copyrightability [S05-S07, S13].

**Applied conclusion:** deliver four separate outputs: provenance history, watermark/detection state, similarity/originality evidence, and legal/rights declarations. Never merge them into a green `safe` badge.

## Live music is a control-loop problem

Lyria RealTime exposes interactive generation [P35], while current co-performance research uses look-ahead windows and consistency distillation to trade latency against context and quality [A35]. The design-space review of 184 live music agents shows that interaction roles and ecosystem context matter alongside model latency [A15].

**Applied conclusion:** `Perform` mode requires explicit leader/follower/call-response roles, latency budgets, look-ahead, recoverable state and performance-aware controls—not merely a low-latency endpoint.

# Proposed formal design primitives

The following are **new design proposals**, not source-established formulas.

### Hard exact-locality gate

For editable region `Ω` and old/new waveforms `x_old`, `x_new`:

`L_exact = max(|x_new[t] - x_old[t]| for t outside Ω)`

Pass only if `L_exact <= epsilon_sample`, after identical sample-rate/channel alignment. A transition collar must be declared explicitly rather than hidden.

### Feature preservation vector

For feature extractors `phi_k` and bounded distances `d_k`:

`P_k = 1 - d_k(phi_k(x_new), phi_k(x_old))`

Use dedicated `k` for melody, harmony, groove, vocal identity, lyrics/phonemes, timbre, spatial position and dynamics. A single average must not override a failed hard lock.

### Pairwise preference model

For creator `u` and candidate utilities `r_u(i)`:

`Pr(i preferred to j | u) = sigmoid(r_u(i) - r_u(j))`

Use active pair selection to minimize listening burden; preserve diversity and allow a creator to reset/export/delete the preference model.

### Constraint-first candidate search

`maximize [intent, musicality, edit_fidelity, novelty, creator_preference, cultural_fidelity, media_fit]`

subject to all hard locks, rights constraints, duration/delivery constraints and safety gates. Return a Pareto set rather than forcing incomparable goals into one uncalibrated scalar.

# New frontier falsifiers

The architecture should be reconsidered if controlled experiments show any of the following:

- users complete more projects with opaque full regeneration than with a progressively disclosed edit graph;
- exact/feature locks fail often enough that the trust promise becomes misleading;
- native multi-track generation produces lower usable-track yield than source-separated masters at the same total cost;
- expert cultural review cannot distinguish a grammar-driven route from a well-prompted generic route;
- contribution/provenance capture creates enough friction to reduce owned-release completion without improving release acceptance or trust;
- the open `.pmp` format cannot retain sufficient semantics across at least two external DAW/tool adapters.
