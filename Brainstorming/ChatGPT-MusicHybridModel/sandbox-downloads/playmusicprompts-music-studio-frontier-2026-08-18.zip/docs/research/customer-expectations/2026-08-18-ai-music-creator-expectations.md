# Standards ledger

- Scope: evidence-backed needs across novices, musicians, producers, songwriters, media creators, game teams, agencies and enterprise users.
- Primary evidence includes practising-musician co-design, producer study, longitudinal novice work, professional workflow research, agency/ownership experiment and video-soundtrack research [A05-A07, A14, A17-A20].
- Commercial surveys are used only as bounded demand signals, not universal population estimates.

# Outcome first

People do not fundamentally want “more AI music.” They want to **turn an idea into something they recognize as theirs, change the exact part that is wrong without losing what is right, understand the consequences of AI actions, finish faster, and leave with assets they can actually use.**

The most powerful “wow” moment is not a lucky first song. It is the first time the user says a precise human sentence, sees the system understand it, and watches only the intended musical reality change while everything important survives.

# Universal expectations

## 1. Immediate first delight

A non-musician expects a credible result from one sentence, voice note, hum, image or video without learning prompt syntax. The system should infer a useful first project and ask no more than the few questions that materially change the result.

## 2. Preserve what already works

Across musician and producer evidence, users need control over the amount, type and location of change, especially when integrating an idea into existing work [A05, A06]. “Regenerate” must not erase the singer, hook, groove or mix they already chose.

## 3. Make the result feel authored, not merely obtained

Higher automation can lower workload but also psychological ownership and agency, particularly for more experienced users [A17]. Users need visible decisions, causal feedback, versions, contribution history and the ability to take the lead.

## 4. Reduce review burden

When systems generate many alternatives, listening and selection become the bottleneck [A07, A19]. Users expect the system to remove invalid/duplicate candidates, explain differences and help them comp—not simply produce more thumbnails.

## 5. Speak human intent

Users often describe music through scenes, emotions, function and narrative after listening, not only through genres and instruments; those vocabularies vary across cultures [A14]. The interface must understand “this should feel like forgiving someone without forgetting” as a real creative instruction.

## 6. Give professionals the correct depth

Professional workflow research prioritizes speed, sound quality and the correct control level while favoring automation for menial/session-prep work [A18]. Experts do not want a beginner form, but they also do not want AI to make hidden aesthetic decisions.

## 7. Deliver real production assets

Creators expect master, usable stems with origin, MIDI/score where relevant, lyrics/timing, alternate versions, project history and DAW interoperability—not only a compressed stereo file [A06, P01, P24, S10-S12].

## 8. Respect identity and rights

Users need to know whether a voice/reference is allowed, how AI was used, what commercial permission applies and what is still legally uncertain. Provenance is valuable only if it does not pretend to be a copyright guarantee [S01-S08].

## 9. Never trap the work

Udio's disabled downloads and Suno's plan-level download limits make portability an explicit trust expectation [P07, P39]. Users want confidence that a project will remain usable if a subscription, provider or partnership changes.

## 10. Remember without becoming creepy

Personalization should retain musical preferences, rejected clichés and project identity, but users need to inspect, edit, export, pause and delete that memory. Private inputs should not become training data by default.

# Segment-specific jobs and acceptance criteria

## A. First-time creator / non-musician

### Job

“Turn the sound in my head into a finished song without making me learn production.”

### Current pain

- Does not know genre, key, arrangement or mix vocabulary.
- Cannot diagnose why a result feels wrong.
- Gets lost in sliders and retries.
- May confuse commercial use with copyright ownership.

### Must-have

- one-field Spark creation;
- voice/hum/image/video intake;
- three meaningfully different directions;
- plain-language differences;
- guided local change;
- ready-to-share package.

### Wow

The system converts “more hope after the second chorus, but do not make it happy” into a visible emotional/structural change and preserves the favorite vocal.

## B. Musician / songwriter

### Job

“Help me explore and develop my ideas without taking authorship away.”

### Current pain

- Model ignores specific melody/rhythm intent.
- Generated material does not fit existing bars/key/BPM.
- Too much automation weakens ownership.
- Lyrics and prosody sound generic or unnatural.

### Must-have

- hum/MIDI/audio anchoring;
- motif and chord objects;
- exact bar/phrase editing;
- lyrics-to-melody and melody-to-lyrics workflows;
- low-automation Direct mode;
- contribution passport.

### Wow

The user plays a motif, locks it, asks for three transformations, and can see where the motif recurs and how it evolves across the song.

## C. Producer / engineer

### Job

“Give me material that fits the session and let me control or replace every production decision.”

### Current pain

- fake stems with bleed;
- BPM/key/loop mismatch;
- unpredictable rerendering;
- no proper gain staging, routing, versions or DAW round-trip;
- time wasted auditioning near-duplicates.

### Must-have

- native/separated stem origin;
- sample/bar-accurate regions;
- MIDI 2.0/ARA/CLAP-oriented interoperability;
- multitrack synchronization metrics;
- deterministic version and comp graph;
- transparent mastering and export.

### Wow

The producer replaces only the bass performance for bars 17–24, keeps every other sample exact, and receives a synchronized native track plus an evidence report.

## D. Singer / vocal producer

### Job

“Create a believable, editable performance whose identity and language are under control.”

### Current pain

- wrong pronunciation, stress, timing and breath;
- voice drift across sections;
- identity/consent ambiguity;
- generated vocal inseparable from the mix.

### Must-have

- score-native VocalScore;
- word/syllable/phoneme/note alignment;
- language dictionaries and verification;
- phrase-level performance direction;
- licensed identity object and revocation;
- alternate takes/comp lanes.

### Wow

A Turkish line is rendered with correct stress and melisma, the user edits one phoneme/note, and every other phrase remains intact.

## E. Video / film / advertising creator

### Job

“Make music that understands the story, cuts and dialogue, then deliver every required duration.”

### Current pain

- generic mood matching;
- soundtrack fights dialogue;
- repeated generation for each cutdown;
- motif continuity disappears between scenes.

### Must-have

- script/video/storyboard intake;
- narrative beat and dialogue-gap map;
- frame/timecode alignment;
- motif/character continuity;
- 6/15/30/60/90-second and full versions from one project;
- stem-safe editorial changes.

### Wow

Change the edit, and the music reflows around dialogue and cuts without losing the central theme.

## F. Game / interactive team

### Job

“Give us a musical world that responds to game state and still sounds composed.”

### Current pain

- static loops fatigue quickly;
- transitions are audible or musically incoherent;
- runtime licensing and performance are unclear;
- procedural systems lose identity.

### Must-have

- state graph and transition-safe segments;
- vertical/lateral re-orchestration;
- deterministic motif/state memory;
- runtime SDK, latency and CPU/GPU budgets;
- telemetry and version pinning;
- platform rights package.

### Wow

The score moves from stealth to discovery to combat in real time, with the same motif changing role rather than switching to unrelated tracks.

## G. Agency / brand / enterprise team

### Job

“Generate on-brand music at scale while preserving approvals, rights and consistency.”

### Current pain

- inconsistent sonic identity;
- client feedback gets lost in prompts;
- assets are scattered;
- unclear rights and auditability;
- bulk volume creates quality-control burden.

### Must-have

- Brand World Model and prohibited clichés;
- client approval/branch protection;
- reusable briefs and delivery templates;
- rights/provenance policies;
- evaluator gates and batch variance controls;
- API, SSO, regional/private deployment.

### Wow

A campaign produces 25 regional/duration variants that all pass the same brand, lyric, loudness, rights and motif constraints, with a single approval graph.

# The failure taxonomy users feel

| Failure | What the user experiences | Required product response |
|---|---|---|
| Intent failure | “It sounds good, but not like what I meant.” | Show interpretation, ambiguities and intent alignment by dimension. |
| Preservation failure | “It fixed one thing and ruined three.” | Locks, exact/feature reports, rollback and local routes. |
| Identity failure | “The singer/song no longer feels the same.” | Identity/motif continuity metrics and explicit thresholds. |
| Selection failure | “I cannot listen to all of these.” | Clustering, deduplication, difference lens and active pairwise questions. |
| Integration failure | “I cannot use it in my session/video/game.” | Open tracks/MIDI/timecode/runtime/package outputs. |
| Agency failure | “The AI made the important decisions.” | Agency modes, applyable diffs and contribution history. |
| Rights failure | “Can I release this?” | Separate permission, provenance, similarity, disclosure and uncertainty. |
| Cultural failure | “It used the stereotype, not the tradition.” | Grammar route, expert evaluation and refusal when support is unproven. |
| Trust failure | “The control did nothing.” | Binding report and `NOT_RUN`/refusal instead of decoration. |
| Portability failure | “My work is trapped.” | Open `.pmp`, asset export and provider-independent project state. |

# Product acceptance tests

A release candidate should pass user tests such as:

1. A novice creates and meaningfully revises a song without touching Deep mode.
2. A musician can lock an uploaded motif and identify every recurrence.
3. A producer changes one selected region and independently verifies outside-region preservation.
4. A vocalist corrects one word/phoneme without regenerating the performance wholesale.
5. A video creator re-cuts a scene and gets a musically coherent revision with motif continuity.
6. A collaborator branches, comments, proposes a diff and merges without overwriting the owner.
7. An enterprise reviewer can explain the rights/provenance state from evidence rather than a badge.
8. A user exports the complete project and reopens meaningful structure outside the product.
9. An expert can choose lower automation and retain direct control.
10. A Culture Grammar fails honestly when no validated route exists.

# One committed customer promise

**Say what you mean, keep what you love, change only what you choose, and leave with a project you own and can continue anywhere.**
