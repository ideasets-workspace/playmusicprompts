# Standards ledger

- Owner deep-research covenant: `/mnt/data/SKILL(20260818-090213).md`, SHA-256 `f19f5cb14319e09ec73fdf42feef2d3067ec8a5949a34657ed9e5c1104d5f9eb`. Governs current-first primary-source research, the source floor, contradiction preservation, six frontier axes, source-to-claim traceability, and completion evidence.
- Current Music Studio generated contract: `/mnt/data/Yapıştırılan markdown(20260818-090450).md`, SHA-256 `29a5b83e5cb69a773ae885cd8f1e0960035e883740a1a85c8334b1a5f7a07a1d`. Establishes the deployed 34-parameter/four-panel request surface and its honest binding classes.
- Current UI reference: `/mnt/data/BeforeTomorrow_MusicStudio_white.png`, SHA-256 `5c63bed06c8ddd56d43982e91e4419e512a1cb7071018d20b068716c581028a9`. Establishes the present white, three-column control-panel composition.
- Product context: `playmusicprompts.com` is an Ideasets product intended to become the world's most advanced prompt-to-music model and creation platform; BeforeTomorrow is an AI-native Creative Operating System rather than a model catalog.

# Scope plan / decision served / why / project context

## Exact decision served

Define the product system, interaction architecture, information architecture, studio controls, model/API extensions, evaluation stack, provenance system, growth loops, and phased build plan that can move PlayMusicPrompts / BeforeTomorrow Music Studio from an advanced prompt-to-song control surface into a category-defining AI-native music creation operating system for consumers, musicians, producers, agencies, filmmakers, game studios, brands, and enterprise teams.

## Why

Berk has completed a hybrid generation backend that already supports the current Music Studio. The research therefore must not re-specify an ordinary generator. It must find what lies materially beyond the existing backend and current interface: unmet human needs, scientific frontier capabilities, competitor parity and failure modes, professional workflow requirements, culturally global music systems, provenance/rights requirements, and experiences capable of producing a genuine “wow” response while preserving one-prompt simplicity.

## Project context and constraints

- Brand/product: `playmusicprompts.com`, within the Ideasets ecosystem and compatible with BeforeTomorrow's creative-production graph.
- Existing backend: conductor endpoint with route planning, parameter validation, model identity reporting, prompt compilation, per-control binding reports, generation, measurement, and planned heavy stages for conforming, mastering, stems, and lyric verification.
- Existing UI: Creative Brief + Composition Workspace + Generation & Output, with 34 documented parameters across four panels.
- Product doctrine: intent → finished work without requiring prompt engineering; domain engineering and creative intelligence rather than a generic model wrapper.
- Interaction doctrine: one-prompt simplicity for a first-time user; progressive disclosure, reversible control, explicit comparisons, references, model-diff visibility, and a complete advanced surface for experts.
- Honesty doctrine: every control must be typed, compiled, enforced, measured, client-side, response-only, or refused. Accepted-but-ignored controls are prohibited.
- Design doctrine: white, human, calm, high-information UI; no generic “AI dashboard,” no legacy-DAW clone, no invented capability disconnected from the backend contract.

# Complete topic and subquestions

1. What do current AI-music users, musicians, producers, agencies, filmmakers, game creators, brands, and non-musicians actually need, fear, and complain about?
2. What capabilities are now table stakes across Suno, Udio, Lyria, ElevenLabs Music, Adobe Firefly, Stability AI, Mureka, ACE Studio, open systems, modern DAWs, stem tools, vocal tools, and mastering/distribution products?
3. What remains scientifically difficult: long-form coherence; motif recurrence; structure; melody/harmony/rhythm control; vocal identity; lyric intelligibility and prosody; culturally specific music; exact local editing; reference conditioning; multitrack consistency; deterministic revision; preference alignment; and evaluation?
4. Which interaction primitives make advanced control natural: conversation, a living score, semantic regions, typed edits, conservation locks, audition matrices, version graphs, agentic self-critique, multimodal direction, and transparent model bindings?
5. What exact product modules, menus, screens, controls, output objects, versioning semantics, collaboration features, and API fields should exist?
6. What provenance, consent, rights, disclosure, human-authorship, voice-identity, and distribution safeguards are needed in 2026?
7. Which capabilities should be built now, next, and later around the completed hybrid backend?
8. Which loops create retention, collaboration, virality, catalog value, licensed marketplaces, enterprise defensibility, and cross-product advantage inside Ideasets?

# Reversal and falsification evidence

The committed recommendation changes if evidence shows that users consistently prefer a minimal generator over editable workflows; that advanced controls materially reduce completion or retention even when progressively disclosed; that reliable region-level editing or stem continuity is infeasible for the deployed model family and available adapters; that provenance/rights requirements prohibit the proposed personalization or voice features; or that an existing competitor already provides the same integrated workflow with demonstrably superior usability, edit locality, open export, creator ownership, and project memory.

# Inclusion / exclusion

Included: official product documentation, official model/API documentation, technical reports, academic primaries, standards, legislation and official guidance, first-party repositories, empirical user research, current product surfaces, and credible creator evidence used only for bounded discovery. Geography is global. Temporal priority is 2026 then 2025, retaining older foundational work when necessary.

Excluded as evidence: unsupported SEO listicles, fabricated or pattern-guessed product claims, unverified pricing, unauthorised artist/voice/style imitation, illegal training-data access, rights claims based only on vendor marketing, and controls that cannot be honestly bound or measured. Secondary sources may identify candidates but do not carry load-bearing claims when a primary exists.

# Evidence universes

- Academic: text-to-music, text-to-song, singing-voice synthesis, long-form planning, local editing/inpainting, multimodal conditioning, symbolic/audio hybrids, controllability, music information retrieval, human preference, evaluation, provenance, HCI/co-creation, cross-cultural interaction, live agents, and adaptive music.
- Frontier companies: Google/DeepMind, Suno, Udio, ElevenLabs, Adobe, Stability AI, Meta, NVIDIA, AWS, OpenAI when relevant, and every music-native company found during scoping.
- Professional tools: Logic Pro, Ableton Live, FL Studio, Cubase, RipX, BandLab, Splice, Moises, ACE Studio and adjacent tools.
- Open models/code: AudioCraft/MusicGen/JASCO, ACE-Step, DiffRhythm, MusicWeaver and current model/repository families discovered.
- Standards/legal/platform: C2PA, DDEX, U.S. Copyright Office, EU AI Act, distribution and streaming-platform policies.
- Users: novices, practising musicians, professional producers/engineers, songwriters, video creators, agencies, brands, filmmakers, game teams, collaborators, educators, accessibility users, and enterprise/API customers.

# Planned artifact tree

The original 17-item draft omitted two governance artifacts required by the governing covenant—the scope plan itself and the research index. They are explicitly counted here rather than hidden.

1. Scope plan.
2. Main frontier report.
3. Competitor pricing/access report.
4. Competitor functions/services report.
5. Competitor business-model report.
6. Competitor UI/menus report.
7. Scientific/SOTA report.
8. API/model-control report.
9. Customer-expectations report.
10. Future-needs report.
11. Growth/organic-loops report.
12. Source register.
13. Query/action ledger.
14. Claim/verification ledger.
15. Contradiction/risk ledger.
16. Product capability matrix and vNext parameter schema.
17. Research index.
18. Final completion/read-back manifest.
19. Research bundle archive.

Planned artifact count: **19**.

# Hard-law check

- Current-first, primary-first, no guessed locators: implemented through broad discovery searches followed by official pages and full academic primaries.
- Numerical floor: target ≥20 independent authoritative sources, ≥5 academic sources, and ≥5 academic full-text depth records.
- Load-bearing verification: recommendations must be supported by at least three independent evidence families or visibly marked as inference/single-source.
- Six frontier axes: competitor/capability, SOTA, APIs, customer expectations, future needs, and growth each receive a dedicated artifact.
- Owner-atom preservation: current 34-parameter surface and binding taxonomy remain preserved; the recommendation changes interaction architecture around them rather than silently deleting them.
- Honest incompleteness: dynamic pricing, unpublished model internals, private training corpora, and production feasibility not proven by public evidence remain dated or explicitly unverified.

# Completion semantics

The run reaches a reportable state only after the source floor is met; at least five academic primaries receive problem/method/numbers/limitations/application records; all six axes exist; current product parity is mapped; contradictions and technical limits remain visible; the recommendation is translated into UI/workflow/API changes; every produced artifact is reopened and hashed; produced count matches 19 including the archive; and the final manifest records counts, hashes, blind spots, and read-back state.
