# Standards ledger

- Scope: capabilities, policies and ecosystem needs likely to determine the 2026–2030 frontier.
- Evidence separates current capability from inference. Current technical seeds include explicit planning/editing, native multitrack, preference evaluation, live agents, culture bias, watermarking/provenance and open interoperability [A01, A21-A45, P35-P39, S01-S13].
- Dates and provider details are volatile; this report defines strategic direction rather than a deterministic forecast.

# Outcome first

The future of AI music will not be won by the model that produces the most songs. It will be won by the system that can maintain **musical identity through time**—across edits, versions, collaborators, media, live performance, rights changes, cultures and model upgrades.

The next frontier is a progression:

`generator → editable project → world model → licensed capability network → adaptive music runtime`.

PlayMusicPrompts should design for the final state now, while implementing the first reliable transaction on the existing backend.

# Future need 1 — Musical world models

A project needs hierarchical memory at universe, album, song, section, phrase, bar, beat and event scales. Current planning/world-model research shows the value of separating structure from surface [A01, A08, A21, A23, A26, A33].

Needed capabilities:

- motif identity and transformation lineage;
- narrative/emotional causality;
- style as learned decision boundaries, not tag averages;
- cross-song continuity;
- counterfactual simulation: “what changes if the chorus arrives earlier?”;
- model-independent rendering.

# Future need 2 — Guaranteed and explainable editing

Users will expect musical software to behave more like source control and less like a slot machine.

Needed capabilities:

- typed operations;
- exact and feature locks;
- declared transition collars;
- proof of locality;
- semantic diff;
- conflict detection before rendering;
- branch/merge/rollback;
- regression tests for a song.

Research demonstrates pieces of this, but no public evidence proves every semantic lock at production quality [A01, A13, A27].

# Future need 3 — Native multitrack causality

The master waveform will become a render, not the only truth. Native tracks need a shared musical clock, cross-track attention/context, role constraints, phase/beat synchronization and independent editability [A21, A22, A28, A34, A38, A39, A48].

Future outputs:

- native audio tracks;
- symbolic/performance layers;
- virtual-instrument state;
- mix automation;
- track dependencies;
- synchronized alternates;
- provenance by track and region.

# Future need 4 — Score-native and consent-native voices

Voice generation will move from “male/female/voice clone” to a first-class performance system:

- phoneme/note/duration/breath score;
- language- and dialect-aware prosody;
- register, articulation and ornamentation;
- identity continuity;
- consent, allowed uses, term and territory;
- revocation and model deletion;
- royalty/split reporting;
- live performance control.

VocalRender and ACE Studio illustrate technical/product pieces; Spotify's impersonation policy and licensed remix partnerships show the rights direction [A24, P24, P38, S08].

# Future need 5 — Plural preference and anti-homogenization

A universal reward model will optimize toward majority averages. Future systems need layered preference:

- technical validity;
- creator taste;
- project intent;
- audience/use context;
- cultural grammar;
- novelty and anti-copying;
- brand/label policy;
- accessibility.

MusicRL, CMI-RM, SongBench and cross-cultural studies support the need for domain-specific and human-in-the-loop evaluation [A14, A25, A31, A36, A37, A44].

# Future need 6 — Cultural operating systems

Global music cannot be represented as Western key/meter plus genre labels. The evidence points to underrepresented data, non-trivial adaptation and potential bias in the audio representation itself [A31-A32, A42-A43].

A culture system must include:

- tuning/pitch ontology;
- phrase trajectory and resting-tone rules;
- rhythmic cycles and additive meters;
- form and improvisation grammar;
- instrument technique and articulation;
- language/poetry/prosody;
- context and prohibited stereotypes;
- expert evaluation and governance;
- compensation and attribution.

Turkey can be the first deep grammar: makam, seyir, koma/microtonal pitch, usul/aksak, Turkish phonology and regional performance practice.

# Future need 7 — Real-time musical relationships

Lyria RealTime and current research show that continuous generation is becoming available [P35, A35]. The real need is interaction design:

- follow/lead/trade/challenge roles;
- anticipatory look-ahead;
- latency budgets and graceful degradation;
- recoverable state;
- gesture, MIDI 2.0, audio and semantic control;
- rehearsal memory;
- shared authorship record;
- capture from performance into the editable project.

# Future need 8 — Cross-media and adaptive composition

Music will be generated against scripts, video, games, dialogue, user state and live events. Video-Robin and Adobe/Google product directions establish current movement [A33, P14, P18-P19].

The next system should support:

- narrative beat graphs;
- character/brand motifs;
- dialogue-aware density;
- frame/timecode and game-state triggers;
- transition-safe vertical/lateral layers;
- automatic duration/cutdown families;
- audience-personalized but identity-consistent renderings.

# Future need 9 — Provenance, attribution and originality as a stack

The ecosystem will need four distinct systems:

1. **Provenance** — signed history of generation and edits [S01-S03].
2. **AI disclosure/credits** — standardized role/component metadata [S04, S08].
3. **Watermark/detection** — model/output traceability under transformation [A29].
4. **Attribution/similarity** — evidence about training influence or output resemblance [A30].

None alone proves copyrightability or non-infringement [S05-S07, S13]. Product UX must preserve the distinction.

# Future need 10 — Distribution readiness and anti-spam

As generation volume rises, platforms will strengthen identity, spam, disclosure and rights gates. Spotify already targets spam and unauthorized impersonation and is developing granular AI credits with DDEX [S08].

Future creation products therefore need:

- verified creator/identity state;
- release-rate and duplicate controls;
- provenance completeness;
- rights/similarity preflight;
- quality and metadata validation;
- no incentive for mass low-value uploads;
- catalogue health and takedown response.

# Future need 11 — Open semantic portability

Audio and stems do not preserve intention. A durable project format should combine:

- graph and versions;
- media assets and hashes;
- tracks/stems and origin;
- MIDI 2.0/score/tuning;
- lyrics/phonemes;
- automation and plug-in state references;
- evaluation evidence;
- rights, consent and contribution;
- provider/model route history.

MIDI 2.0, ARA and CLAP are ingredients, not the complete project standard [S10-S12]. The proposed `.pmp` should interoperate with them rather than compete with every lower-level format.

# Future need 12 — Private and on-device intelligence

Stable Audio 3 demonstrates complete-music on-device/open-weight direction [P20]. Privacy-sensitive creators and enterprises will increasingly require:

- local idea capture;
- private reference analysis;
- on-device preview or editing;
- self-hosted/region-pinned renderers;
- encrypted identity models;
- zero-retention provider routes;
- exportable preference and world memories.

# Future need 13 — Evaluation as continuous governance

A model benchmark at launch is insufficient. Every provider/model/version can drift. The product needs:

- per-route regression suites;
- culture/language controls;
- hard-lock tests;
- professional listening panels;
- release-target QC;
- calibrated uncertainty;
- watchdogs for pricing, limits, policy and model changes;
- historical reproducibility where providers permit it.

# Strategic scenarios

## Scenario A — Models converge in quality

Winning layer: project graph, editing, evaluator, rights network and runtime. This is the base strategy.

## Scenario B — One provider makes a major quality leap

Winning response: add it as a renderer through the capability registry. Do not migrate user projects or lose history.

## Scenario C — Licensing becomes tightly controlled

Winning layer: authenticated opt-in identities, rights-aware transformations, private models and transparent splits.

## Scenario D — Open weights become good enough for most work

Winning layer: orchestration, private deployment, tooling, evaluation and world-model data. Margin shifts from provider inference to service value.

## Scenario E — Platforms penalize fully synthetic or undisclosed catalogues

Winning response: optimize for meaningful human decisions, contribution evidence and release readiness—not generation volume.

## Scenario F — Real-time/adaptive music becomes the largest market

Winning layer: stateful runtime, live SDK and persistent musical worlds already built from the same graph.

# Watchlist and invalidators

Track monthly:

- Suno/UMG/BMG/Warner product and export terms;
- Udio portability and licensed ecosystem changes;
- Lyria 3/3.5/RealTime API fields, pricing and regions;
- Eleven Music editing/stem/finetune limits;
- Stable Audio open releases and license conditions;
- DDEX AI metadata implementation;
- C2PA audio tooling and survival through post-production;
- Spotify/other DSP identity, disclosure and spam rules;
- MIDI 2.0, ARA and CLAP host adoption;
- MusicWeaver/native-track/score-native-vocal reproducibility;
- Turkish makam/cross-cultural benchmarks and datasets.

Invalidate the roadmap if reliable user tests show that persistent graph/edit workflows reduce completion even under progressive disclosure, or if model constraints make lock guarantees too unreliable to sell honestly.

# One committed future bet

Build the **persistent musical world and transaction layer now**. It is the one investment that becomes more valuable whether the future is closed-model, open-model, licensed, on-device, live, cinematic, game-driven or culturally specialized.
