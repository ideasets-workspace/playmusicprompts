# PlayMusicPrompts — Complete Web UX/UI Blueprint

**Product category:** Living Music Engine  
**Tagline:** Say what you want to hear.  
**Domain:** playmusicprompts.com  
**Canonical desktop canvas:** 1600 × 1000 px  
**Canonical screen count:** 49  

## 1. Product definition

PlayMusicPrompts is not designed as a prompt marketplace, a one-shot song generator, or a conventional DAW with an AI chat panel. The web product treats the prompt as the easiest doorway into a persistent computational music project. The canonical project is a Music Intent Graph rendered through a Living Score, with visible intent, sections, motifs, lyrics, performance identity, production identity, tracks, rights, contributors, locks, versions and delivery outputs.

The interface therefore supports four progressive experience modes:

- **Spark:** express an idea through text, speech, humming, media or an existing project.
- **Direct:** co-create through an AI Producer, Living Score, contextual inspector, Audition Deck and version graph.
- **Deep:** expose the complete professional Music Studio control surface and the real binding state of every control.
- **Perform:** collaborate with a low-latency musical agent under an explicit human/AI role contract.

## 2. Core UX laws

1. **Intent before parameters.** Users can begin with the effect, story, memory or scene they want to create.
2. **Agency before automation.** The system proposes; the human can inspect, reject, branch, comp, commit or revert.
3. **No regeneration roulette.** Every edit declares selection, allowed change, invariants, candidate policy and verification.
4. **A lock must execute.** Exact, feature and meaning locks expose evaluator, tolerance and evidence.
5. **No accepted-but-ignored controls.** Typed, compiled, prose, enforced, refused, response-only and client-side states remain distinguishable.
6. **Selection is a first-class creative stage.** Candidates are clustered, filtered and compared by meaningful differences.
7. **Human contribution is a graph of decisions.** It is not reduced to a fictional AI percentage.
8. **Culture is governed architecture.** Cultural systems include theory, performance, language, expert review and known limitations.
9. **Rights travel with the work.** Identity authority, source, permission, provenance and delivery evidence remain connected.
10. **Portability is a creator contract.** The open `.pmp` project survives model, vendor and platform change.

## 3. Visual system

- White and warm-neutral workspace with premium editorial clarity.
- Violet-to-magenta sonic accent reserved for active intelligence, selected states and creative energy.
- Green communicates verified evidence, active rights or passing hard gates; amber indicates human review or semantic uncertainty; red indicates blocked or failed authority.
- Dense professional screens use small, highly structured typography; public and onboarding surfaces use large human-centered statements.
- Rounded 11–22 px geometry, hairline borders and low-contrast shadows preserve calmness under high information density.
- Dark styling is used selectively for authentication atmosphere, live performance and developer code—not as generic “AI” decoration.

## 4. Canonical information architecture

### Public navigation
Product · For Artists · Film & Games · Trust · Pricing · Discover

### Post-login navigation
Home · Create · Projects · Music Worlds · Identity & Voices · Culture Grammars · Rights Exchange · Library · Collaborate · Releases · Developer · Settings

### Cross-product command layer
Global search / command palette · notifications · workspace switcher · usage state · account / collaborators

## 5. Screen catalog

### Public website

#### 01. Landing / Home

**Purpose.** Category-defining first impression and direct path into creation.

**Primary action.** Start a first project or watch the category demo.

**Key UI objects.** Category statement; Living Score preview; Proof pillars; Creator trust signals.

**Related system objects.** `Public product shell`, `Demo project state`.

**Critical trust/state rule.** ['Never imply that a decorative control is operational.']

**Image.** `../screens/01-landing-home.png`

#### 02. How It Works

**Purpose.** Explain the end-to-end creation loop without reducing the product to prompt-to-song.

**Primary action.** Understand the complete intent-to-release loop.

**Key UI objects.** Six-stage workflow; Visible action receipts; Capability cards.

**Related system objects.** `Intent compiler`, `Planner`, `Renderer`, `Evaluator`, `Version graph`, `Delivery engine`.

**Critical trust/state rule.** ['Show generation as one stage, not the product.']

**Image.** `../screens/02-how-it-works.png`

#### 03. Living Music Engine

**Purpose.** Explain the persistent Music Intent Graph and why it is the category core.

**Primary action.** Understand the Music Intent Graph as the canonical project.

**Key UI objects.** Identity graph; Persistent nodes; Typed edit explanation.

**Related system objects.** `MusicProject`, `MusicIntentGraph`, `CompositionIdentity`, `PerformanceIdentity`, `ProductionIdentity`.

**Critical trust/state rule.** ['Distinguish waveform rendering from persistent project identity.']

**Image.** `../screens/03-living-music-engine.png`

#### 04. For Artists & Producers

**Purpose.** Show artist-owned memory, identity and album continuity.

**Primary action.** Create or inspect an Artist World.

**Key UI objects.** Artist World card; Taste memory; Album continuity; Identity controls.

**Related system objects.** `MusicWorld`, `TasteConstitution`, `IdentityObject`.

**Critical trust/state rule.** ['Memory must be visible, editable, exportable and deletable.']

**Image.** `../screens/04-for-artists.png`

#### 05. Film, Games & Brands

**Purpose.** Position scene-aware scoring, adaptive runtime and brand sonic worlds.

**Primary action.** Begin a scene score, adaptive runtime or brand world.

**Key UI objects.** Scene timeline; Narrative beats; Adaptive-state summary.

**Related system objects.** `SceneGraph`, `RuntimeStateGraph`, `BrandWorld`.

**Critical trust/state rule.** ['Dialogue, state transition and motif continuity must be testable.']

**Image.** `../screens/05-film-games-brands.png`

#### 06. Rights & Trust

**Purpose.** Communicate provenance, identity authority, contribution and portability.

**Primary action.** Inspect how rights, contribution and provenance travel.

**Key UI objects.** Contribution Passport; Consent status; C2PA/DDEX evidence; Origin labels.

**Related system objects.** `RightsGraph`, `ContributionEvent`, `ProvenanceManifest`.

**Critical trust/state rule.** ['Commercial-use terms must not be presented as a copyright warranty.']

**Image.** `../screens/06-rights-trust.png`

#### 07. Pricing

**Purpose.** Present transparent project-value pricing rather than retry-credit economics.

**Primary action.** Select the plan that fits project value and team needs.

**Key UI objects.** Plan cards; Transparent usage statement; Portability promise.

**Related system objects.** `Plan`, `UsagePolicy`, `WorkspaceEntitlement`.

**Critical trust/state rule.** ['Avoid failed-generation credit roulette and hidden downgrade.']

**Image.** `../screens/07-pricing.png`

#### 08. Discover / Community

**Purpose.** Showcase living projects, governed worlds and remixable works.

**Primary action.** Explore living projects and governed creative worlds.

**Key UI objects.** Featured project grid; World type filters; Fork/remix signals.

**Related system objects.** `PublishedProject`, `MusicWorld`, `RemixPolicy`.

**Critical trust/state rule.** ['Respect publication scope and remix authorization.']

**Image.** `../screens/08-discover.png`

### Authentication

#### 09. Sign In

**Purpose.** Return users to their persistent creative workspace.

**Primary action.** Authenticate and return to the persistent workspace.

**Key UI objects.** Social sign-in; Email/password; Recovery link.

**Related system objects.** `UserSession`, `WorkspaceMembership`.

**Critical trust/state rule.** ['Session security and private asset protection.']

**Image.** `../screens/09-sign-in.png`

#### 10. Create Account

**Purpose.** Create an account with transparent rights language.

**Primary action.** Create an account with transparent rights language.

**Key UI objects.** Identity fields; Terms disclosure; Account CTA.

**Related system objects.** `User`, `ConsentRecord`.

**Critical trust/state rule.** ['Do not overstate authorship or rights at account creation.']

**Image.** `../screens/10-sign-up.png`

#### 11. Email Verification

**Purpose.** Verify identity before onboarding and workspace creation.

**Primary action.** Verify the account email.

**Key UI objects.** Verification state; Expiry; Resend flow.

**Related system objects.** `EmailVerificationToken`.

**Critical trust/state rule.** ['Secure expiry and idempotent resend.']

**Image.** `../screens/11-email-verification.png`

#### 12. Forgot Password

**Purpose.** Initiate secure password recovery.

**Primary action.** Request a one-time recovery link.

**Key UI objects.** Email field; Recovery action; SSO note.

**Related system objects.** `PasswordResetRequest`.

**Critical trust/state rule.** ['Do not reveal whether an account exists.']

**Image.** `../screens/12-forgot-password.png`

#### 13. Reset Password

**Purpose.** Set a strong new credential with clear security feedback.

**Primary action.** Set a new secure password.

**Key UI objects.** Strength feedback; Confirmation; Policy hints.

**Related system objects.** `CredentialUpdate`.

**Critical trust/state rule.** ['Invalidate old sessions according to policy.']

**Image.** `../screens/13-reset-password.png`

### Onboarding

#### 14. Workspace Setup

**Purpose.** Create the workspace and select the default creative context.

**Primary action.** Create the first workspace and choose default context.

**Key UI objects.** Workspace name; Creator type; Default experience.

**Related system objects.** `Workspace`, `AgencyModePolicy`.

**Critical trust/state rule.** ['Defaults remain editable and must not silently narrow capability.']

**Image.** `../screens/14-workspace-setup.png`

#### 15. Taste Constitution Onboarding

**Purpose.** Establish user-owned creative preferences and negative rules.

**Primary action.** Define protected preferences, negative rules and surprise range.

**Key UI objects.** Protected traits; Forbidden clichés; Surprise dial; Memory consent.

**Related system objects.** `TasteConstitution`, `PreferenceEvidence`.

**Critical trust/state rule.** ['No global or workspace learning without explicit approval.']

**Image.** `../screens/15-taste-constitution-onboarding.png`

### Post-login

#### 16. Home Dashboard

**Purpose.** Orient the user around intent, active projects and release state.

**Primary action.** Start new work and see what needs attention.

**Key UI objects.** Intent launcher; Recent projects; Activity; Release readiness.

**Related system objects.** `WorkspaceDashboard`, `ProjectSummary`, `DecisionQueue`.

**Critical trust/state rule.** ['Use completion and readiness signals, not raw generation counts.']

**Image.** `../screens/16-home-dashboard.png`

#### 17. Create / Spark Mode

**Purpose.** Capture multimodal intent with minimum initial complexity.

**Primary action.** Capture multimodal intent with minimal complexity.

**Key UI objects.** Intent field; Voice/hum/media inputs; Suggested directions; Render policy.

**Related system objects.** `IntentDraft`, `NoRenderPolicy`, `ProjectMemory`.

**Critical trust/state rule.** ['Ask high-value questions before expensive rendering.']

**Image.** `../screens/17-create-spark.png`

#### 18. Direction Selection

**Purpose.** Select among strategically different causal plans before full rendering.

**Primary action.** Choose among causally different musical plans.

**Key UI objects.** Direction cards; Intent/surprise metrics; Transparent ranking.

**Related system objects.** `MusicPlan`, `CandidateStrategy`.

**Critical trust/state rule.** ['Alternatives must be meaningfully diverse, not cosmetic variants.']

**Image.** `../screens/18-direction-selection.png`

#### 19. Projects

**Purpose.** Browse persistent projects by type, state and intent integrity.

**Primary action.** Browse and filter all persistent projects.

**Key UI objects.** Search/filter; Project cards; State and integrity.

**Related system objects.** `MusicProject`, `ProjectIndex`.

**Critical trust/state rule.** ['Project state and portability should remain visible.']

**Image.** `../screens/19-projects.png`

#### 20. Project Overview

**Purpose.** Summarize creative intent, versions, locks, team and release state.

**Primary action.** Understand intent, branch state, activity and release progress.

**Key UI objects.** Project hero; Intent summary; Latest events; Readiness.

**Related system objects.** `MusicProject`, `VersionHead`, `ReleaseReadiness`.

**Critical trust/state rule.** ['Surface unresolved meaning locks and rights issues.']

**Image.** `../screens/20-project-overview.png`

#### 21. Direct Workspace / Living Score

**Purpose.** Primary co-creation surface with typed producer, Living Score and contextual controls.

**Primary action.** Co-create through typed actions, Living Score and contextual controls.

**Key UI objects.** AI Producer; Living Score layers; Contextual inspector; Audition deck; Version graph.

**Related system objects.** `EditTransaction`, `ConservationLock`, `CandidateSet`, `VersionDAG`.

**Critical trust/state rule.** ['Every action shows understood intent, change scope, locks and evidence.']

**Image.** `../screens/21-direct-workspace.png`

#### 22. Deep Inspector / Music Studio

**Purpose.** Expose the full 34-control surface as an honest contextual professional inspector.

**Primary action.** Control the complete production surface.

**Key UI objects.** 34-control inspector; Structure; Energy; Instruments; Vocals; Mastering; Stems.

**Related system objects.** `HybridMusicRequest`, `BindingReport`, `RenderPlan`.

**Critical trust/state rule.** ['Typed, prose, compiled, enforced, refused and response-only states remain explicit.']

**Image.** `../screens/22-deep-inspector.png`

#### 23. Perform Mode

**Purpose.** Support low-latency human-led co-performance with explicit role and capture policy.

**Primary action.** Play and sing with a negotiated real-time musical partner.

**Key UI objects.** Live waveform; Role contract; Inputs; Branch-only capture.

**Related system objects.** `LiveSession`, `PerformanceEvent`, `RealtimeAgentContract`.

**Critical trust/state rule.** ['Human authority, latency and auto-commit policy must be explicit.']

**Image.** `../screens/23-perform-mode.png`

#### 24. Edit Preflight

**Purpose.** Show understood intent, authorized changes, locks, conflicts and verification before compute.

**Primary action.** Review the edit contract before rendering.

**Key UI objects.** Understood intent; Allowed changes; Locks; Conflict analysis; Route plan.

**Related system objects.** `EditTransaction`, `LockEvaluationPlan`, `RouteDecision`.

**Critical trust/state rule.** ['Hard constraints cannot become silent best-effort suggestions.']

**Image.** `../screens/24-edit-preflight.png`

#### 25. Audition Deck

**Purpose.** Cluster candidates, hide failed outputs and explain meaningful trade-offs.

**Primary action.** Review clustered, high-value candidates.

**Key UI objects.** Clusters; Candidate cards; Failure filtering; Preference signal.

**Related system objects.** `CandidateSet`, `EvaluatorCouncil`, `PreferenceEvent`.

**Critical trust/state rule.** ['Hide failed outputs with disclosed reasons, not without trace.']

**Image.** `../screens/25-audition-deck.png`

#### 26. Candidate Compare / A-B

**Purpose.** Perform synchronized, blind, difference-aware candidate comparison.

**Primary action.** Make a synchronized, difference-aware A/B decision.

**Key UI objects.** Blind playback; Metric deltas; What-you-will-hear summary.

**Related system objects.** `PairwiseComparison`, `PreferenceEvent`.

**Critical trust/state rule.** ['Metrics inform, but do not replace human listening.']

**Image.** `../screens/26-candidate-compare.png`

#### 27. Comp Editor

**Purpose.** Combine bars from candidates non-destructively and re-verify locks.

**Primary action.** Assemble a version from selected bars and revalidate it.

**Key UI objects.** Source lanes; Comp lane; Transition collar; Verification receipt.

**Related system objects.** `CompTransaction`, `AssetReference`, `ContributionEvent`.

**Critical trust/state rule.** ['Re-run locality, voice and lyric checks after comping.']

**Image.** `../screens/27-comp-editor.png`

#### 28. Version Graph

**Purpose.** Visualize immutable branches, commits, comparisons, merges and reverts.

**Primary action.** Branch, compare, merge and revert without destructive edits.

**Key UI objects.** Version DAG; Commit history; Selected commit actions.

**Related system objects.** `VersionDAG`, `Commit`, `Branch`, `Merge`.

**Critical trust/state rule.** ['Revert and round-trip behavior must be deterministic.']

**Image.** `../screens/28-version-graph.png`

#### 29. Music Worlds

**Purpose.** Browse persistent artist, album, film, game and brand worlds.

**Primary action.** Browse artist, album, film, game and brand worlds.

**Key UI objects.** World cards; Type/state metadata; Create/import actions.

**Related system objects.** `MusicWorldIndex`.

**Critical trust/state rule.** ['World memory and permissions must remain isolated by scope.']

**Image.** `../screens/29-music-worlds.png`

#### 30. Music World Detail

**Purpose.** Inspect identity, motifs, taste rules, authorized assets and evolution.

**Primary action.** Inspect a world’s constitution, motifs and learning history.

**Key UI objects.** Identity hero; World rules; Motifs; Health; Learning.

**Related system objects.** `MusicWorld`, `MotifObject`, `TasteConstitution`.

**Critical trust/state rule.** ['Learned rules require evidence and user review.']

**Image.** `../screens/30-music-world-detail.png`

#### 31. Identity & Voices

**Purpose.** Manage authorized voice, performer, artist and brand identities.

**Primary action.** Manage authorized identities.

**Key UI objects.** Identity cards; Consent status; Scope; Usage.

**Related system objects.** `IdentityObject`, `AuthorityRecord`.

**Critical trust/state rule.** ['No identity can be generated outside active authority.']

**Image.** `../screens/31-identity-voices.png`

#### 32. Voice Identity Detail

**Purpose.** Inspect performance contract, consent scope, model version and audit usage.

**Primary action.** Audit a voice identity’s range, consent and use.

**Key UI objects.** Performance contract; Consent scope; Identity health; Audit log.

**Related system objects.** `VoiceIdentity`, `ConsentRecord`, `UsageAudit`.

**Critical trust/state rule.** ['Revocation and expiry must propagate to future generation.']

**Image.** `../screens/32-voice-identity-detail.png`

#### 33. Culture Grammars

**Purpose.** Browse governed, executable cultural music systems.

**Primary action.** Browse governed cultural systems.

**Key UI objects.** Grammar cards; Version/review state; Expert council.

**Related system objects.** `CultureGrammar`, `GovernanceRecord`.

**Critical trust/state rule.** ['Culture cannot be reduced to aesthetic tags.']

**Image.** `../screens/33-culture-grammars.png`

#### 34. Turkish Culture Grammar Detail

**Purpose.** Show versioned cultural rules, expert governance and honest renderer support.

**Primary action.** Inspect Turkish makam/usul rules and renderer support.

**Key UI objects.** Pitch/melody/rhythm components; Project preview; Governance; Support matrix.

**Related system objects.** `CultureGrammar`, `AdapterCapability`, `ExpertReview`.

**Critical trust/state rule.** ['Unsupported exact koma or articulation features are visibly limited.']

**Image.** `../screens/34-turkish-culture-grammar.png`

#### 35. Rights Exchange

**Purpose.** Discover licensed identities, instruments, catalogs and expert services.

**Primary action.** License voices, instruments, catalogs and expertise.

**Key UI objects.** Marketplace cards; Scope/price; Controller/approval.

**Related system objects.** `LicenseOffer`, `AuthorityRecord`, `CompensationPolicy`.

**Critical trust/state rule.** ['Rights scope, controller and approval must be explicit before use.']

**Image.** `../screens/35-rights-exchange.png`

#### 36. Library

**Purpose.** Manage assets with origin, rights, project and contribution metadata.

**Primary action.** Find and manage assets with origin and rights metadata.

**Key UI objects.** Filters; Asset cards; Origin labels; Rights states.

**Related system objects.** `Asset`, `AssetOrigin`, `RightsReference`.

**Critical trust/state rule.** ['Native tracks, separated stems and uploads remain distinguishable.']

**Image.** `../screens/36-library.png`

#### 37. Collaborate / Review Queue

**Purpose.** Unify comments, decisions, expert review and live sessions around project objects.

**Primary action.** Resolve reviews, comments and decisions in project context.

**Key UI objects.** Review queue; Live sessions; Threaded comments.

**Related system objects.** `ReviewItem`, `Comment`, `DecisionEvent`.

**Critical trust/state rule.** ['Comments attach to specific bars, versions, locks or evidence.']

**Image.** `../screens/37-collaborate.png`

#### 38. Team Workspace

**Purpose.** Manage members, roles, guests, identity access and workspace policies.

**Primary action.** Manage members, roles and access policies.

**Key UI objects.** Member table; Role cards; Activity; Access policies.

**Related system objects.** `WorkspaceMembership`, `RolePolicy`.

**Critical trust/state rule.** ['Voice, download and external-share access are scoped.']

**Image.** `../screens/38-team-workspace.png`

#### 39. Releases

**Purpose.** Manage multi-format releases and their readiness states.

**Primary action.** Manage static, adaptive and multi-format releases.

**Key UI objects.** Release cards; Readiness; Destinations; Versions.

**Related system objects.** `Release`, `DeliveryTarget`.

**Critical trust/state rule.** ['Release state derives from evidence, not a decorative progress bar.']

**Image.** `../screens/39-releases.png`

#### 40. Release Readiness

**Purpose.** Gate a release on rights, quality, provenance, originality and portability evidence.

**Primary action.** Resolve quality, rights, provenance and originality gates.

**Key UI objects.** Readiness checks; Evidence package; Open human review.

**Related system objects.** `ReleaseReadiness`, `OriginalityReview`, `ProvenanceManifest`.

**Critical trust/state rule.** ['Originality analysis is not presented as legal clearance.']

**Image.** `../screens/40-release-readiness.png`

#### 41. Export / Delivery Package

**Purpose.** Assemble masters, tracks, score, runtime and evidence into portable delivery bundles.

**Primary action.** Assemble portable masters, tracks, score, runtime and proof.

**Key UI objects.** Package groups; Selection state; Summary; Signed build action.

**Related system objects.** `DeliveryPackage`, `PMPArchive`, `Manifest`.

**Critical trust/state rule.** ['Every artifact is rendered, read back and origin-labelled.']

**Image.** `../screens/41-export-package.png`

#### 42. Developer Hub

**Purpose.** Present project-native APIs, SDKs and integration surfaces.

**Primary action.** Discover project-native APIs and SDKs.

**Key UI objects.** API hero; Capability cards; Endpoints; SDK grid.

**Related system objects.** `DeveloperApp`, `APIContract`.

**Critical trust/state rule.** ['Provider/model adapters are replaceable; project semantics remain stable.']

**Image.** `../screens/42-developer-hub.png`

#### 43. API Keys & Webhooks

**Purpose.** Manage scoped credentials, event delivery and transparent request inspection.

**Primary action.** Manage scoped credentials and event delivery.

**Key UI objects.** Key table; Webhook table; Request inspector.

**Related system objects.** `APIKey`, `Webhook`, `RequestReceipt`.

**Critical trust/state rule.** ['Secrets are shown once; routes and actual workers are inspectable.']

**Image.** `../screens/43-api-keys-webhooks.png`

#### 44. Billing & Usage

**Purpose.** Show plan, compute, storage, savings and transparent cost controls.

**Primary action.** Understand plan, usage, savings and cost controls.

**Key UI objects.** Usage chart; Metrics; Invoices; Caps.

**Related system objects.** `UsageRecord`, `Invoice`, `BudgetPolicy`.

**Critical trust/state rule.** ['Preflight savings and compute charges must be traceable.']

**Image.** `../screens/44-billing-usage.png`

#### 45. Notifications

**Purpose.** Centralize decision, rights, release, project and security events.

**Primary action.** Review project, rights, release and security events.

**Key UI objects.** Notification stream; Preferences; Quiet hours.

**Related system objects.** `Notification`, `DeliveryPreference`.

**Critical trust/state rule.** ['Critical rights/security events can override quiet hours.']

**Image.** `../screens/45-notifications.png`

#### 46. Settings / Profile

**Purpose.** Manage personal identity used in collaboration and contribution evidence.

**Primary action.** Manage personal contribution identity.

**Key UI objects.** Profile fields; Verified email; Contribution identity.

**Related system objects.** `UserProfile`, `ContributorIdentity`.

**Critical trust/state rule.** ['Public display choices do not erase private audit evidence.']

**Image.** `../screens/46-settings-profile.png`

#### 47. Workspace Settings

**Purpose.** Configure agency, portability, training, lock, guest and retention defaults.

**Primary action.** Set workspace-wide project and access defaults.

**Key UI objects.** Agency default; Portability/training policy; Guest policy; Retention.

**Related system objects.** `WorkspacePolicy`.

**Critical trust/state rule.** ['Workspace defaults may guide but not silently rewrite project intent.']

**Image.** `../screens/47-workspace-settings.png`

#### 48. Security & Privacy

**Purpose.** Control authentication, sessions, training permission, isolation and data export.

**Primary action.** Control authentication, sessions, data use and isolation.

**Key UI objects.** Auth status; Sessions; Training controls; Encryption.

**Related system objects.** `SecurityPolicy`, `DataConsent`, `Session`.

**Critical trust/state rule.** ['Global training remains off unless explicitly enabled.']

**Image.** `../screens/48-security-privacy.png`

#### 49. Help & Learning Center

**Purpose.** Provide task-based learning, conceptual guidance and specialist support.

**Primary action.** Learn workflows and reach specialist support.

**Key UI objects.** Search; Topic cards; Human support.

**Related system objects.** `KnowledgeArticle`, `SupportRequest`.

**Critical trust/state rule.** ['Help content must distinguish product capability from legal or creative guarantees.']

**Image.** `../screens/49-help-learning-center.png`

## 6. Shared component inventory

### Navigation and orientation
- Public navigation, post-login sidebar, global search, workspace selector, active project strip, mode switcher, breadcrumb and context title.

### Intent and creation
- Multimodal intent composer, high-value clarification prompt, direction cards, NoRender policy, project memory receipt, surprise/agency controls.

### Living Score
- Section timeline, motif layer, lyrics layer, harmony layer, rhythm layer, energy/narrative layer, scene layer, contribution layer and lock overlay.

### Edit and evaluation
- Edit Transaction receipt, selection object, hard/soft/meaning locks, conflict analysis, route receipt, candidate clusters, A/B compare, comp lane, failure trace and evaluator evidence.

### Project continuity
- Project overview, immutable version DAG, branch/merge/revert, Music World constitution, motif registry, Taste Constitution, learned-rule review and project health.

### Identity, culture and rights
- Identity Object, consent scope, voice range, expiry/revocation, Culture Grammar version, expert council, adapter support matrix, Rights Exchange offer and controller/approval status.

### Release and delivery
- Release Readiness gates, originality review boundary, Human Contribution Passport, C2PA/DDEX state, master/native/separated origin, signed delivery manifest and open `.pmp` archive.

### Developer and operations
- Project-native APIs, scoped keys, webhooks, actual route/model/worker receipt, usage attribution, render approval, budget caps, security and training consent.

## 7. Backend-to-interface mapping

The current hybrid music endpoint remains the professional rendering conductor inside the broader product. Its 34-parameter machine-readable contract maps to the Deep Inspector. The higher product layer adds persistent project objects, typed edit transactions, candidate search, executable conservation locks, evaluator reports, branches, comping, identity authority, Culture Grammars, contribution evidence and release packages.

The recommended object hierarchy is:

```text
Workspace
└── MusicProject
    ├── MusicIntentGraph / LivingScore
    ├── SourceAssets (immutable)
    ├── CompositionIdentity
    ├── PerformanceIdentity
    ├── ProductionIdentity
    ├── EditTransactions
    │   ├── Selection
    │   ├── AllowedChange
    │   ├── ConservationLocks
    │   ├── CandidateSet
    │   └── EvaluatorEvidence
    ├── VersionDAG
    ├── RightsGraph
    ├── HumanContributionPassport
    ├── MusicWorld references
    └── DeliveryPackages / open .pmp
```

## 8. Responsive behavior

- Desktop is the canonical professional surface.
- Tablet preserves Living Score and inspector side-by-side where possible; Producer and version panes become drawers.
- Mobile is task-oriented rather than a shrunken DAW: Spark, audition, compare, comment, approve, release check and notification flows remain native; full Deep editing can hand off to desktop.
- Every dense table supports card conversion, semantic grouping and persistent filter state.

## 9. Accessibility and internationalization

- Minimum WCAG AA contrast for functional text and state indicators.
- Every status uses text plus color; no critical meaning depends on color alone.
- Full keyboard operation for timeline selection, compare, branching, comp and commit.
- Screen-reader labels describe object type, section range, lock level and verification state.
- Interface supports bidirectional text, non-Latin lyrics and culture-specific notation extensions.
- Reduced-motion mode removes decorative waveform animation without disabling audio feedback.

## 10. Implementation priority

### Phase 1 — Category demo
Landing, sign-in, onboarding, Home, Spark, Direction Selection, Projects, Project Overview, Direct Workspace, Edit Preflight, Audition Deck, Candidate Compare, Comp Editor and Version Graph.

### Phase 2 — Professional system
Deep Inspector, Library, Collaborate, Team, Releases, Release Readiness, Export Package, Billing, Notifications and settings.

### Phase 3 — Defensible ecosystem
Music Worlds, Identity & Voices, Culture Grammars, Rights Exchange, Perform, Developer APIs and adaptive runtime.

## 11. Package contents

- `screens/` — 49 individual 1600×1000 PNG screens.
- `docs/PlayMusicPrompts-Complete-UX-UI-Blueprint.pdf` — visual screen-by-screen documentation.
- `docs/PlayMusicPrompts-Complete-UX-UI-Blueprint.md` — searchable design and implementation specification.
- `docs/PlayMusicPrompts-All-Screens-Contact-Sheet.png` — overview sheet.
- `docs/PlayMusicPrompts-Information-Architecture.png` — screen map.
- `docs/screen-specs.json` — machine-readable screen inventory.
- `design-system/design-tokens.json` — portable visual and product principles.
- `references/ai-generated-visual-direction.png` — generated visual exploration used as a reference, not as the final UI source.