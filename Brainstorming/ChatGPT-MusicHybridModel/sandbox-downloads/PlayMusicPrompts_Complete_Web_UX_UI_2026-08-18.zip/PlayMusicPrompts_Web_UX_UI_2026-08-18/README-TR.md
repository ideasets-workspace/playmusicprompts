# PlayMusicPrompts — Web UX/UI Paketi

Bu paket, **playmusicprompts.com** için hazırlanan toplam **49 ayrı 1600×1000 masaüstü ekranı** içerir.

## Nereden başlamalısın?

1. `docs/PlayMusicPrompts-All-Screens-Contact-Sheet.png` — bütün ekranları tek bakışta gör.
2. `docs/PlayMusicPrompts-Complete-UX-UI-Blueprint.pdf` — ekranların görselleri ve amaçlarıyla tam dokümantasyon.
3. `screens/` — her ekranın ayrı PNG dosyası.
4. `docs/PlayMusicPrompts-Information-Architecture.png` — public, login/onboarding ve login sonrası bütün bilgi mimarisi.
5. `docs/screen-specs.json` — agent ve frontend ekibine verilebilecek makine-okunur ekran tanımları.

## Ana ürün kararı

PlayMusicPrompts bir prompt sitesi veya yalnızca şarkı üreten generator olarak tasarlanmadı. Prompt, en kolay giriş kapısıdır. Ürünün merkezi yaşayan ve sürüm kontrollü **Music Intent Graph / Living Score** yapısıdır.

Dört deneyim seviyesi:

- **Spark:** tek fikir, konuşma, hum, image/video veya brief ile başlama.
- **Direct:** AI Producer + Living Score + Contextual Inspector + Audition Deck.
- **Deep:** mevcut hybrid modelini destekleyen 34 kontrollü profesyonel Music Studio.
- **Perform:** insanın yönettiği canlı müzikal partner.

Tüm tasarım; typed edit, conservation lock, candidate comparison, comp, version graph, Music Worlds, Identity & Voices, Culture Grammars, Rights Exchange, Human Contribution Passport ve açık `.pmp` projesi etrafında kuruldu.
