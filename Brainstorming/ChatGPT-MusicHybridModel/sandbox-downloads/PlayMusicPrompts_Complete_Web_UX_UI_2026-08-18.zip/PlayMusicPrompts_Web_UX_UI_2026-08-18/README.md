# PlayMusicPrompts Complete Web UX/UI Package

This package contains **49 individual 1600×1000 desktop screen designs** for `playmusicprompts.com`.

## Start here

- `index.html` — browsable visual gallery
- `docs/PlayMusicPrompts-Complete-UX-UI-Blueprint.pdf` — screen-by-screen visual documentation
- `docs/PlayMusicPrompts-Complete-UX-UI-Blueprint.md` — detailed product and implementation blueprint
- `docs/PlayMusicPrompts-All-Screens-Contact-Sheet.png` — all screens at a glance
- `docs/PlayMusicPrompts-Information-Architecture.png` — full sitemap
- `docs/screen-specs.json` — machine-readable screen inventory
- `screens/` — 49 individual PNG files
- `design-system/design-tokens.json` — design and product tokens

## Product contract

PlayMusicPrompts is designed as a **Living Music Engine**, not a one-shot prompt-to-song generator. The prompt is the easiest entry point; the persistent project is a Music Intent Graph / Living Score.

Experience modes:

1. Spark
2. Direct
3. Deep
4. Perform

The product system includes typed edits, executable conservation locks, auditions, A/B comparison, comping, immutable versions, Music Worlds, Identity & Voices, Culture Grammars, Rights Exchange, Human Contribution Passport and open `.pmp` delivery.
