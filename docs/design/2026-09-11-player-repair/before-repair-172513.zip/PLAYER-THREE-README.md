# The Listening Room — expanded Three.js player

Open **http://127.0.0.1:4173/player-three.html** while the local preview is running. Otherwise open **START-PLAYER.cmd**. Node.js is required to serve the folder. The separate player preserves the five approved website pages and the original player layout.

Share the HTTP preview link as the playable entry. Opening `player-three.html` directly from a folder now leads to `player-launch.html`, with the preview link and launcher instructions; it does not run the 3D player under `file://`. The browser needs HTTP for the module graph and WebGL texture loading. The launcher opens the browser after the preview has started listening. Keep using the same browser and local address to retain your imported library and settings.

Choose **Bring your music**, or drop audio files into the room. Imported audio stays on this device and restores in the same browser and local address. No demonstration songs are bundled. If browser storage cannot save a file, the player explains that it is available for the current visit only.

## Four scenes, nine worlds and motion

Open **Scene** above the stage to choose between four visual instruments:

- **Record** keeps the approved turntable, with Resonance, Orbit and Flow detail modes plus the record-only rotation controls.
- **Aurora Veil** uses four folded light curtains and suspended filaments that respond to bass, mid and treble energy.
- **Orbital** uses segmented chrome gimbals, inset light tracks, a faceted crystal core and six moving satellites.
- **Liquid Chrome** uses a continuous asymmetrical chrome body, live contour seams and orbiting droplets that deform with the sound.

Switching scenes is immediate and does not replace the audio element or interrupt the current session. The selected scene is saved in the local room preference and restored on reload. Shared light intensity, Motion, Orbit camera, Sound response, rendering quality and all audio/session controls remain available across the collection. When Record is selected, its detail and turntable controls return automatically; they are hidden for the three alternative sculptures so controls always describe the visible scene.

**Explore all 9 worlds** opens Nightfall, Deep water, Afterglow, Aurora, Rainroom, Desert bloom, Lunar tide, Ember and Cloud nine. Each world changes the record artwork, lighting and surrounding color. Rainroom has falling particles; Ember has rising particles. The six new illustrations are native 512 × 512 panels in one local 1536 × 1024 atlas. This is atmosphere artwork, not imported cover metadata.

The record face, grooves, center and visible marker rotate during playback, including quiet passages. Pause gently slows the record to rest. **Visuals → Rotation speed** sets 0–45 RPM; **Orbit camera** adds a slow camera journey while playing. Drag to adjust the view, scroll to zoom, or choose Reset view.

**Sound response** adjusts actual audio-driven movement. Separate channel analysis preserves visual energy for right-only and opposite-phase stereo tracks. Resonance, Orbit and Flow sculpture modes, reflective floor, particles, bloom, light intensity, rendering quality, Cinema and full screen remain available. Motion initially follows the system reduced-motion preference. An explicit on/off choice is saved separately, survives reload and takes precedence over later system changes. When off, the stage offers Enable motion. Legacy computed booleans migrate to system-following mode because they did not distinguish manual choices from defaults. Audio remains usable if WebGL cannot initialize or loses its context.

Idle particles are ambient animation. The frequency display reads real audio; silence and pause settle its energy.

## Your sound

The **Sound** panel has four tabs with volume, mute and real left/right meters above them.

| Tab | Controls |
| --- | --- |
| Tone | Ten-band EQ at 31, 63, 125, 250, 500 Hz and 1, 2, 4, 8, 16 kHz; ±12 dB per band; response curve; preamp; automatic headroom |
| Space | Stereo width from mono to 200%; conventional left/right balance; mono listening; Studio, Hall and Space convolution ambience |
| Dynamics | Original dynamics, Gentle glue, Hold the punch and Late-night listening; actual gain reduction; 0.5–1.5× playback speed with browser pitch preservation; A–B passage loop |
| My presets | Save, restore and delete up to 32 named combinations of EQ, stereo, ambience, dynamics and effect settings |

Eight built-in EQ profiles: Original, Warm & full, Vocal clarity, Deep bass, Electronic, Acoustic, Cinematic and Soft focus. Built-in profiles change tone; named custom presets restore combined sound settings. Preferences persist locally. The effect switch bypasses sound processing while preserving volume and session controls. Reset all sound settings restores original processing settings.

Automatic headroom compensates combined EQ boost, stereo expansion and an ambience allowance. Transitions reserve headroom before moving filter gains. Dynamics profiles separately compensate the native compressor's automatic makeup gain using output trims that preserve attack shape; compressed profiles can sound quieter. This is native dynamic compression, not a true-peak limiter or a guarantee against clipping for every source and manual gain combination.

## Session tools

- **Sleep timer:** 15, 30, 45, 60 or 90 minutes, a custom duration, or After this song. Timed stops offer no fade or 5 / 15 / 30-second fades; very short timers cap the fade at half the duration. The fade is independent of volume. Timers count wall-clock time, can be cancelled, and restore their deadline after reload.
- **After this song** lets the song finish naturally, then stops before automatic next or repeat. The timed fade selector is disabled for this choice.
- **Keep the best moments:** name and save the current position, jump back to it, or delete it. Up to 50 bookmarks per song persist locally and appear on the waveform. Press **B** to save a moment without opening the panel.
- **Queue:** search titles, select, reorder and remove songs. Search changes the visible list without changing playback order. Clear queue keeps stored audio; Bring back saved music restores available tracks.

Waveform seeking, favorites, shuffle, repeat, backward history, keyboard shortcuts and OS media controls remain connected to actual playback. Shortcuts are listed under **Keys**. Settings panels contain keyboard focus and return it to their opener when closed.

## Files and integration

| File | Purpose |
| --- | --- |
| `player-three.html` | Separate English entry and semantic controls |
| `player-three-entry.js`, `player-launch.html` | Protocol-aware entry and static local launch guide |
| `player-three.css`, `player-three-ultra.css` | Preserved base design and expanded responsive controls |
| `player-three.js` | Playback, queue, storage, waveform and integration |
| `player-three-audio.js` | Ten-band processing, stereo matrix, convolution, dynamics and channel analysis |
| `player-three-sound-ui.js` | Sound controls, presets, response display and meters |
| `player-three-session.js` | Sleep timer, independent fade and bookmarks |
| `player-three-motion.js` | System-following defaults and explicit motion preferences |
| `player-three-worlds.js` | Shared world definitions and atlas coordinates |
| `player-three-scene.js` | Shared Three.js room, camera, palettes, audio bands and model visibility |
| `player-three-collection.js`, `player-three-collection.css` | Accessible four-scene selector and stage control styling |
| `player-three-models.js` | Lazy scene creation, palette propagation, update routing and disposal |
| `player-three-aurora.js` | Aurora Veil procedural curtain asset |
| `player-three-orbital.js` | Orbital chrome gimbal and crystal asset |
| `player-three-liquid.js` | Liquid Chrome deformed-surface asset |
| `assets/worlds-six-atlas.png` | Six new illustrations; provenance manifest alongside |
| `vendor/three/` | Pinned Three.js 0.185.1, required addons, MIT license and hashes |

All runtime dependencies, fonts and artwork are local. Serve over HTTP: ES modules do not reliably run through a double-clicked `file:` URL. No build or external CDN is required.

Playable `PMP_CONFIG.catalog` entries and browser-local `pmp.creations` remain integration points. Audio shares IndexedDB `pmp-local-audio`, version 1, store `tracks`, with the HTML suite. Favorites share `pmp.saved`; room preferences use `pmp.room`; sound, presets, timer and bookmarks use dedicated `pmp.room.*` keys. Navigation from another player starts a separate playback session. Reload restores selection without autoplay.

Remote audio must allow anonymous CORS access. No account or music-generation service is called. Maximum file size is 256 MB; codec support depends on the browser. Large files retain seeking when waveform decoding is skipped.

Audio path: one media source → explicit stereo input → headroom → ten filters → dry/convolution mix → stereo width/balance matrix → latency-aligned dry/dynamics paths → volume → independent sleep fade → output. Two channel analysers read final output. Original dynamics uses a delay matched to the native compressor's roughly 6 ms lookahead; it does not pass through the compressor. Convolution responses are generated DSP decay buffers, not generated music. The context starts from a user gesture.

## Verification — 2026-09-11

165 automated checks passed with actual Web Audio processing and isolated browser playback:

| Report | Passing checks |
| --- | ---: |
| `verification/ultra-audio-checks.json` | 15 |
| `verification/ultra-world-checks.json` | 17 |
| `verification/ultra-session-checks.json` | 12 |
| `verification/ultra-regression-checks.json` | 44 |
| `verification/ultra-final-checks.json` | 25 |
| `../docs/design/2026-09-11-player-ultra-assets/audio-review-checks.json` | 52 |

Independent audio review exercised Original startup, matched delays, impulses and bursts, 25 rapid dynamics reversals, boosted EQ reversals, malformed presets and right-only waveforms at 44.1, 48 and 96 kHz. Tested 0.95-amplitude transient sources remained below full scale after the dynamics correction. Production source hashes remained unchanged during review. Reproducible tests and primary-source calculations are beside the independent report.

Parent and independent reviewer inspected desktop/mobile surfaces and keyboard navigation. Clean final screenshots use `verification/ultra-final-*.png`, from 320 to 1920 px. Early `ultra-player-mobile-first.png` was captured before a visible scene and is superseded by settled final captures. Other test screenshots may contain test-track labels or transient feedback.

Execution used local Chrome 152, actual Web Audio and WebGL including software rendering, plus responsive viewport emulation. Physical-device performance and other browser engines are not established by these checks. Test signals exist only in isolated verification sessions, not as shipped music. Approved v1 source is preserved in `../docs/design/2026-09-11-player-ultra-assets/approved-player-v1-source.zip`.

## Primary references

- [Three.js documentation](https://threejs.org/docs/) and locally pinned source, addons, license and hashes.
- [W3C Web Audio API](https://webaudio.github.io/web-audio-api/) for audio processing and compressor behavior.
- [MDN ConvolverNode](https://developer.mozilla.org/en-US/docs/Web/API/ConvolverNode), [DynamicsCompressorNode](https://developer.mozilla.org/en-US/docs/Web/API/DynamicsCompressorNode) and [filter frequency response](https://developer.mozilla.org/en-US/docs/Web/API/BiquadFilterNode/getFrequencyResponse).
- [Chromium native dynamics processor](https://chromium.googlesource.com/chromium/src/+/main/third_party/blink/renderer/platform/audio/dynamics_compressor.cc) for makeup gain and lookahead, checked against measured production output.
- [W3C slider interaction pattern](https://www.w3.org/WAI/ARIA/apg/patterns/slider/).

Playback-motion correction: 11 additional preference cases passed in verification/motion-preference-checks.json. Actual in-app browser checks covered explicit enable/reload, explicit disable/reload and rendered WAV playback/pause on a separate 4174 test origin. Distinct playback frames showed rotating artwork and active spectral bars. Existing user player tabs were updated with motion enabled. See memory/lanes/three-player-20260911/evidence/MOTION-02.json for exact scope.

Scene expansion verification: parent asset checks cover audio/motion response, exact Motion-off freezing and finite geometry for Aurora, Orbital and Liquid Chrome (10 checks, including Liquid local-clock resume). In-app browser review covered the four-way selector, Record-only control visibility, all nine atmosphere palette selections, reload and two-tab persistence, Cinema mode naming, distinct integrated renders and zero page errors. Motion-on and Motion-off were compared from actual rendered frames on the integrated Liquid scene; the first changed across 500 ms and the second remained byte-identical across 500 ms. Mobile-specific selector styles are present in `player-three-collection.css`; the existing responsive player layout remains unchanged.
