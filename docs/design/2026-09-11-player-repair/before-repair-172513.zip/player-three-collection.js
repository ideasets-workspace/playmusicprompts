export const SCENES = [
 {id:'record',name:'Record',short:'Record',line:'Your world, on rotation.',icon:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm0 6a3 3 0 1 1 0 6 3 3 0 0 1 0-6Zm0-3a6 6 0 0 1 6 6'},
 {id:'aurora',name:'Aurora Veil',short:'Aurora',line:'Let the light carry you.',icon:'M4 19C2 11 8 14 7 5m3 15c-2-9 5-7 4-17m3 17c-1-7 5-6 4-14M3 11c6-4 12 5 19-1'},
 {id:'orbital',name:'Orbital',short:'Orbital',line:'Everything moves around sound.',icon:'M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6ZM3 6c3-5 23 6 18 12S0 11 3 6ZM6 21C0 18 11-2 18 3S11 24 6 21Z'},
 {id:'liquid',name:'Liquid Chrome',short:'Liquid',line:'Feel every shape of sound.',icon:'M7 4c6-4 5 4 10 3s8 9 2 11-4 6-10 3S0 9 7 4Zm0 5c-2 4 0 7 3 8'}
];
export const getScene=id=>SCENES.find(scene=>scene.id===id)||SCENES[0];

export function createSceneSelection({getCurrent,onSelect,open,close}){
 const grid=document.querySelector('#scene-collection');
 grid.innerHTML=SCENES.map((scene,index)=>`<button class="model-card" data-model="${scene.id}" aria-pressed="false"><span class="model-card-top"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="${scene.icon}"/></svg><span class="model-number">0${index+1}</span></span><strong>${scene.name}</strong><small>${scene.line}</small><span class="model-check" aria-hidden="true">✓</span></button>`).join('');
 function synchronize(){const selected=getScene(getCurrent());for(const button of grid.querySelectorAll('[data-model]'))button.setAttribute('aria-pressed',String(button.dataset.model===selected.id));document.querySelector('#scene-choice-name').textContent=selected.short;document.querySelector('#scene-choice').setAttribute('aria-label',`Change 3D scene. Current scene: ${selected.name}`);document.querySelector('#record-form-controls').hidden=selected.id!=='record';document.querySelector('#record-spin-controls').hidden=selected.id!=='record';}
 grid.onclick=event=>{const button=event.target.closest('[data-model]');if(!button)return;onSelect(button.dataset.model);synchronize();close();};
 document.querySelector('#scene-choice').onclick=()=>{open();grid.querySelector(`[data-model="${getScene(getCurrent()).id}"]`)?.focus();};
 synchronize();return{synchronize};
}
